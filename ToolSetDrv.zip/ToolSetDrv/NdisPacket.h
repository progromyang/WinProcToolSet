#pragma once

#define NDIS51
#define NDIS51_MINIPORT
#define NDIS_MINIPORT_DRIVER

#ifdef NDIS51
#define PASSTHRU_PROT_MAJOR_NDIS_VERSION	5
#define PASSTHRU_PROT_MINOR_NDIS_VERSION	0
#else
#define PASSTHRU_PROT_MAJOR_NIDS_VERSION	4
#define PASSTHRU_PROT_MINOR_NDIS_VERSION	0
#endif

#ifdef NDIS51_MINIPORT
#define PASSTHRU_MAJOR_NDIS_VERSION		5
#define PASSTHRU_MINOR_NDIS_VERSION		1
#else
#define PASSTHRU_MAJOR_NDIS_VERSION		4
#define PASSTHRU_MINOR_NDIS_VERSION		0
#endif

#pragma warning(disable:4127)   // conditional expression is constant
#pragma warning(disable:4201)   // nameless struct/union

#define	MIN_PACKET_POOL_SIZE		0xFF
#define MAX_PACKET_POOL_SIZE		0xFFFF
#define TAG		'NDIS'
#define	NTDEVICE_STRING		L"\\Device\\NdisPacket"
#define	LINKNAME_STRING		L"\\DosDevices\\NdisPacket"

#define NDIS_SYS_VERSION_51       0x00050001


#define IP_OFFSET		0x0E	//֡��MAC�ͻ�������ƫ��
//Ip Protocol Types
#define	PROT_ICMP		0x01
#define PROT_TCP		0x06
#define PROT_UDP		0x11


//����ļ�ͷ��Ҫ��Ԥ����֮�� MINIPORT_CHARACTERISITCS�ṹ�ſ���ʹ��
#include<ndis.h>
#include<inaddr.h>
#define ADAPT_DECR_PENDING_SENDS(_pAdapt)	\
								{\
				NdisAcquireSpinLock(&(_pAdapt)->Lock);\
				(_pAdapt)->OutstandingSends--;\
				NdisReleaseSpinLock(&(_pAdapt)->Lock);\
}

#define IsIMDeviceStateOn(_pP)	\
	((_pP)->MPDeviceState==NdisDeviceStateD0&&(_pP)->PTDeviceState==NdisDeviceStateD0)

//AddDevice�д����豸����  ��ControlDeviceObject ֻ�ô���һ������
static PDEVICE_OBJECT	g_NdisDeviceObject = NULL;

//MPinitialize��ʼ��С�˿�ʱ�������豸����  �豸���ƶ���
static PDEVICE_OBJECT	ControlDeviceObject = NULL;
//���������豸����ʱ���صľ�� ������δʹ��
static NDIS_HANDLE		NdisDeviceHandle;
static NDIS_SPIN_LOCK GlobalLock;

static NDIS_MEDIUM		MediumArray[4];
//MiniPort Object
static NDIS_HANDLE	DriverHandle = NULL;
//Э����
static NDIS_HANDLE ProtHandle = NULL;

//RegisterDevice Conut
static ULONG MiniportConut = 0;




typedef enum
{
	STATUS_PASS,
	STATUS_DROP,
	STATUS_REDIRECT
}FILTER_STATUS;

static enum _DEIVCE_STATE
{
	PS_DEVICE_STATE_READY = 0,	//ready for create/delete
	PS_DEVICE_STATE_CREATING,	//create operation in progress
	PS_DEVICE_STATE_DELETING	//delete operation in progress
}ControlDeviceState = PS_DEVICE_STATE_READY;

typedef struct _SEND_RSVD
{
	PNDIS_PACKET OriginalPkt;
}SEND_RSVD, *PSEND_RSVD;

typedef struct _RECV_RSVD
{
	PNDIS_PACKET OriginalPkt;
}RECV_RSVD,*PRECV_RSVD;

typedef struct _ADAPT
{
	struct _ADAPT* Next;

	NDIS_HANDLE		BindingHandle;	//To the lower miniport,�м��Э����²�miniport
	NDIS_HANDLE		MiniportHandle;	//NDIS Handle to for miniport��MPinitialize������,�о����ϲ�prot
	NDIS_HANDLE		SendPacketPoolHandle;
	NDIS_HANDLE		RecvPacketPoolHandle;
	NDIS_STATUS		Status;			//Open Status
	NDIS_EVENT		Event;			//Used by bind/halt for open/close adapt synch
	NDIS_MEDIUM		Medium;
	NDIS_REQUEST	Request;		//����������װ���͸����ǵ�����
	PULONG			BytesNeeded;
	PULONG			BytesReadOrWritten;

	//�����־����˵����������NdisMXxxIndicateReceiveϵ�к���,��ɺ��������ж�
	BOOLEAN			ReceivedIndicationFlags[32];
	BOOLEAN			OutstandingRequests;		//TRUE if a Request Pending at the miniport below
	BOOLEAN			QueuedRequest;				//TRUE if a request is queued at this IM miniport
	BOOLEAN			StandingBy;					//True����΢�Ͷ˿ڻ�Э���D0ת����������>D0��״̬ʱ
	BOOLEAN			UnBindingInProcess;
	NDIS_SPIN_LOCK	Lock;
	
	//False-����������ʱ�䣬-Flag��ת����D0�����
	NDIS_DEVICE_POWER_STATE	MPDeviceState;		//Miniport's Device State
	NDIS_DEVICE_POWER_STATE	PTDeviceState;		//Protocol's Device State
	NDIS_STRING				DeviceName;			//For initializeing the miniport edge
	NDIS_EVENT				MiniportInitEvet;	//For blocking UnbindAdapter whle
	BOOLEAN					MiniportInitPending;	//TRUE if IMInit in progress
	NDIS_STATUS				LastIndicatedStatus;	//The last indicated media status
	NDIS_STATUS				LatestUnIndicateStatus;	//The latest suppressed media status
	ULONG					OutstandingSends;
	LONG					RefCount;
	BOOLEAN					MiniportIsHalted;
}ADAPT, *PADAPT;


static PADAPT pAdaptList = NULL;

/**************************************/
/**************���ݰ�ͷ�ṹ************/
/**************************************/

/*********802��ַ********/
/********IEEE ����*******/
/*[ǰ��7][SFD1][֡]*/
/***********֡***********/
						 /*��******************MAC�ͻ�������********************��*/
/*[DST6][SRC6][���Ȼ�����][��ǩ0/2][������ǩ][�ϲ�Э����Ч�غ�(ͨ��Ϊ1500)][���]*/

/*1
typedef struct in_addr{
	union{
		struct{ UCHAR s_b1, s_b2, s_b3, s_b4; }S_un_b;
		struct{ USHORT s_w1, s_s2; }S_un_w;
		ULONG S_addr;
	}s_un;
}IN_ADDR, *PIN_ADDR, FAR *LPIN_ADDR;
1*/

typedef struct _IP_HEADER
{
	unsigned char	VIHL;		//Version and IHL
	unsigned char	TOS;		//Type of service
	short			Totlen;		//Total Length
	short			ID;			//Identification
	short			FlagOff;	//Flags and fragment offset
	unsigned char	TTL;		//Time to live
	unsigned char	Protocol;	//Protocol;
	unsigned short	Checksum;	//Checksum;
	struct in_addr	iaSrc;		//internet Address - source
	struct in_addr	idDst;		//internet Address - destination 
}IP_HEADER,*PIP_HEADER;


/***********Hook********/

typedef NTSTATUS(*AddDeviceFunc)(
	IN PDRIVER_OBJECT DriverObject,
	IN PDEVICE_OBJECT PhysicalDeviceObject);//����AddDevice����ָ���������

typedef NTSTATUS(*DispatchFunc)(
	IN PDEVICE_OBJECT DeviceObject,
	IN PIRP Irp);	//����ַ�����ָ���������

//����һ������ָ�����������Ndis���е�AddDeviceʵ��
static AddDeviceFunc SystemAddDevice = NULL;

//����4������ָ���������������ϵͳ�����IRP�Ĵ���
static DispatchFunc SystemCreate = NULL;
static DispatchFunc SystemClose = NULL;
static DispatchFunc SystemWrite = NULL;
static DispatchFunc SystemRead = NULL;
static DispatchFunc SystemDeviceControl = NULL;

NTSTATUS MyAddDevice(
	IN PDRIVER_OBJECT DriverObject,
	IN PDEVICE_OBJECT PhysicalDeviceObject);
NTSTATUS DrvCreateAndClose(IN PDEVICE_OBJECT Dev, IN PIRP irp);
NTSTATUS DrvControlIoDevice(IN PDEVICE_OBJECT Dev, IN PIRP irp);
NTSTATUS DrvWrite(IN PDEVICE_OBJECT Dev, IN PIRP irp);
NTSTATUS DrvRead(IN PDEVICE_OBJECT Dev, IN PIRP irp);

NTSTATUS MainNdis(IN PDRIVER_OBJECT DriverObject, IN PUNICODE_STRING RegisterPath);


NDIS_STATUS MPInitialize(
	OUT PNDIS_STATUS	OpenErrorStatus,
	OUT PUINT			SelectedMediumIndex,
	IN PNDIS_MEDIUM		MediumArray,
	IN UINT				MediumArraySize,
	IN NDIS_HANDLE		MiniportAdapterHandle,
	IN NDIS_HANDLE		WrapperConfigurationContext);


NDIS_STATUS MPQueryInformation(
	IN NDIS_HANDLE	MiniportAdapterContext,
	IN NDIS_OID		Oid,
	IN PVOID		InformationBuffer,
	IN ULONG		InformationBufferLength,
	OUT PULONG		BytesWritten,
	OUT PULONG		BytesNeeded);


VOID
MPReturnPacket(
IN NDIS_HANDLE             MiniportAdapterContext,
IN PNDIS_PACKET            Packet
);

NDIS_STATUS
MPSetInformation(
IN NDIS_HANDLE                                  MiniportAdapterContext,
IN NDIS_OID                                     Oid,
__in_bcount(InformationBufferLength) IN PVOID   InformationBuffer,
IN ULONG                                        InformationBufferLength,
OUT PULONG                                      BytesRead,
OUT PULONG                                      BytesNeeded
);

VOID
MPProcessSetPowerOid(
IN OUT PNDIS_STATUS                             pNdisStatus,
IN PADAPT                                       pAdapt,
__in_bcount(InformationBufferLength) IN PVOID   InformationBuffer,
IN ULONG                                        InformationBufferLength,
OUT PULONG                                      BytesRead,
OUT PULONG                                      BytesNeeded
);


NDIS_STATUS
MPTransferData(
OUT PNDIS_PACKET            Packet,
OUT PUINT                   BytesTransferred,
IN NDIS_HANDLE              MiniportAdapterContext,
IN NDIS_HANDLE              MiniportReceiveContext,
IN UINT                     ByteOffset,
IN UINT                     BytesToTransfer
);

VOID
MPDevicePnPEvent(
IN NDIS_HANDLE              MiniportAdapterContext,
IN NDIS_DEVICE_PNP_EVENT    DevicePnPEvent,
IN PVOID                    InformationBuffer,
IN ULONG                    InformationBufferLength
);

VOID
MPCancelSendPackets(
IN NDIS_HANDLE            MiniportAdapterContext,
IN PVOID                  CancelId
);

VOID
MPAdapterShutdown(
IN NDIS_HANDLE                MiniportAdapterContext
);



//�м��Э����²�miniport
VOID PtBindAdapter
(
OUT PNDIS_STATUS	Status,
IN NDIS_HANDLE		BindContext,
IN PNDIS_STRING		DeviceName,
IN PVOID			SystemSpecific1,
IN PVOID			SystemSpecific2
);

//�м�� vitrual miniport
VOID MPSendPackets(
	IN NDIS_HANDLE		MiniportAdapterContext,
	IN PPNDIS_PACKET	PacketArray,
	IN UINT				NumberkOfPackets);

//��virtrul miniport �������ݰ���NICʵ��ʱ �첽�ķ�ʽ�ش���ɺ������м��Э��
VOID
PtSendComplete(
IN  NDIS_HANDLE            ProtocolBindingContext,
IN  PNDIS_PACKET           Packet,
IN  NDIS_STATUS            Status
);

NDIS_STATUS
PtReceive(
IN NDIS_HANDLE	ProtocolBindingContext,
IN NDIS_HANDLE	MacReceiveContext,
IN PVOID		HeaderBuffer,
IN UINT			HeaderBufferSize,
IN PVOID		LookAheadBuffer,
IN UINT			LookAheadBufferSize,
IN UINT			PacketSize
);

VOID
PtRequestComplete(
IN  NDIS_HANDLE            ProtocolBindingContext,
IN  PNDIS_REQUEST          NdisRequest,
IN  NDIS_STATUS            Status
);


//������˵���²��첽�����Ѿ����
VOID
PtTransferDataComplete(
IN  NDIS_HANDLE         ProtocolBindingContext,
IN  PNDIS_PACKET        Packet,
IN  NDIS_STATUS         Status,
IN  UINT                BytesTransferred
);

VOID MPQueryPNPCapabilities(
	IN OUT PADAPT pAdapt,
	OUT PNDIS_STATUS pStatus);


VOID MPFreeAllPacketPools(
	IN PADAPT pAdapt);

//�����������ݰ�
VOID
PtReceiveComplete(
IN NDIS_HANDLE        ProtocolBindingContext
);


VOID
PtUnload(
IN PDRIVER_OBJECT        DriverObject
);

VOID PtReferenceAdapt(IN PADAPT pAdapt);

BOOLEAN PtDereferenceAdapt(IN PADAPT pAdapt);

NDIS_STATUS PtRegisterDevice(
	VOID);


VOID
PtUnload(
IN PDRIVER_OBJECT        DriverObject
);

VOID
MPHalt(
IN NDIS_HANDLE                MiniportAdapterContext
);

static NDIS_STATUS
PtDeregisterDevice(
VOID
);

FILTER_STATUS AnalysisPacket(PNDIS_PACKET Packet, BOOLEAN bRecOrSend);

INT PtReceivePacket(IN NDIS_HANDLE  ProtocolBindingContext, IN PNDIS_PACKET Packet);

VOID PtUnloadProtocol(VOID);

//Э������
VOID PtUnbindAdapter(
	OUT PNDIS_STATUS	Status,
	IN NDIS_HANDLE		ProtocolBindingContext,
	IN NDIS_HANDLE		UnBindContext);


VOID
PtOpenAdapterComplete(
IN  NDIS_HANDLE             ProtocolBindingContext,
IN  NDIS_STATUS             Status,
IN  NDIS_STATUS             OpenErrorStatus
);

VOID
PtCloseAdapterComplete(
IN    NDIS_HANDLE            ProtocolBindingContext,
IN    NDIS_STATUS            Status
);

VOID
PtResetComplete(
IN  NDIS_HANDLE            ProtocolBindingContext,
IN  NDIS_STATUS            Status
);


VOID
PtStatusComplete(
IN NDIS_HANDLE            ProtocolBindingContext
);

VOID
PtStatus(
IN  NDIS_HANDLE         ProtocolBindingContext,
IN  NDIS_STATUS         GeneralStatus,
IN  PVOID               StatusBuffer,
IN  UINT                StatusBufferSize
);

NDIS_STATUS
PtPNPHandler(
IN NDIS_HANDLE		ProtocolBindingContext,
IN PNET_PNP_EVENT	pNetPnPEvent);

NDIS_STATUS
PtPnPNetEventSetPower(
IN PADAPT            pAdapt,
IN PNET_PNP_EVENT    pNetPnPEvent
);

NDIS_STATUS
PtPnPNetEventReconfigure(
IN PADAPT            pAdapt,
IN PNET_PNP_EVENT    pNetPnPEvent
);

//����AddDevice����ָ���������
typedef NTSTATUS(*AddDeviceFunc)(
	IN PDRIVER_OBJECT DriverObject,
	IN PDEVICE_OBJECT PhysicalDeviceObject);
