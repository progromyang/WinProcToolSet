#pragma once
#ifndef _KEYBOARDFILTER_H_
#define _KEYBOARDFILTER_H_
#include<ntddk.h>
#include<ntddkbd.h>

#define OBUFFER_FULL 0x02
#define IBUFFER_FULL 0x01
#define DELAY_ONE_MICROSECOND (-10)
#define DELAY_ONE_MILLISECOND (DELAY_ONE_MICROSECOND*1000)
static BOOLEAN bKeyBoardFilter=FALSE;
ULONG g_c2pCount;
PDEVICE_OBJECT CopyDevice;
PIRP pCopyIrp;
BOOLEAN bWhile;
UCHAR ScanCode;

//Ӧ����Ϊ������ĵ�ַָ�룬�����Ǵ���
extern POBJECT_TYPE * IoDriverObjectType;		//������
//kbdClass��������
#define KB_DRIVER_NAME		L"\\Driver\\Kbdclass"
NTSTATUS DispatchGeneral(IN PDEVICE_OBJECT DevceObject, IN PIRP Irp);
NTSTATUS c2pPower(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp);
NTSTATUS c2pPnp(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp);
NTSTATUS c2pRead(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp);
NTSTATUS c2pReadCompalte(PDEVICE_OBJECT DeviceObject, IN PIRP Irp, IN PVOID context);
VOID c2pUnload(PDRIVER_OBJECT DeviceObject);
NTSTATUS c2pAttachDevices(
	IN PDRIVER_OBJECT DriverObject,
	IN PUNICODE_STRING RegisterPath);
HANDLE hKeyBoard;
//����ѭ�������̵߳ȴ��¼�
KEVENT hKeyBoradEvent;
void KeyBoardThread(void * a);

NTSTATUS ObReferenceObjectByName(
	PUNICODE_STRING ObjectName,
	ULONG Attributes,
	PACCESS_STATE AccessState,
	ACCESS_MASK DesiredAccess,
	POBJECT_TYPE ObjectType,
	KPROCESSOR_MODE AccessMode,
	PVOID ParseContext,
	PVOID *Object
	);

typedef struct _C2P_DEV_EXT
{
	//����ṹ��С
	ULONG NodeSize;
	//�����豸����
	PDEVICE_OBJECT pFilterDeviceObject;
	//ͬʱ����ʱ�ı�����
	KSPIN_LOCK IoRequestSpinLock;
	//���̼�ͬ������
	KEVENT IoInProgressEvent;
	//�󶨵��豸����
	PDEVICE_OBJECT TargetDeivceObject;
	//��ǰ�ײ��豸����
	PDEVICE_OBJECT LowerDeviceObject;
}C2P_DEV_EXT,*PC2P_DEV_EXT;


typedef struct _KEYBOARD
{
	USHORT Id;
	USHORT DelayTime;
}KEYBOARD, *PKEYBOARD;


typedef VOID(__stdcall *pfnKeyboardClassServiceCallback)(
	_In_     PDEVICE_OBJECT DeviceObject,
	_In_     PKEYBOARD_INPUT_DATA InputDataStart,
	_In_     PKEYBOARD_INPUT_DATA InputDataEnd,
	_Inout_  PULONG InputDataConsumed
	);

typedef unsigned char P2C_U8;

BOOLEAN WritePort();
pfnKeyboardClassServiceCallback KeyboardClassServiceCallback;

#endif

