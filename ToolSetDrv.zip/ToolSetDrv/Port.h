#pragma once
#include<ntifs.h>
#include<ntddk.h>
#include<netioddk.h>


#include"typedef.h"
#define PORT	'POR'
#define IOCTL_NSI_GETALLPARAM 0x12001B
#define UK_QURYPORTINFO	\
	CTL_CODE(FILE_DEVICE_UNKNOWN,0xA00,METHOD_BUFFERED,FILE_ANY_ACCESS)
#define ntohs(s) (((s>>8)&0x00FF)|((s<<8)&0xFF00))

typedef struct _MIB_TCPROW_OWNER_PID
{
	ULONG dwState;
	ULONG dwLocalAddr;
	ULONG dwLocalPort;
	ULONG dwRemoteAddr;
	ULONG dwRemotePort;
	ULONG dwOwningPid;
}MIB_TCPROW_OWNER_PID,*PMIB_TCPROW_OWNER_PID;

typedef struct _MIB_UDPROW_OWNER_PID
{
	ULONG dwLocalAddr;
	ULONG dwLocalPort;
	ULONG dwOwningPid;
}MIB_UDPROW_OWNER_PID,*PMIB_UDPROW_OWNER_PID;

typedef struct _INTERNAL_TCP_TABLE_SUBENTRY
{
	char bytesfill0[2];
	USHORT Port;
	ULONG dwIp;
	char bytesfill[20];
}INTERNAL_TCP_TABLE_SUBENTRY,*PINTERNAL_TCP_TABLE_SUBENTRY;

typedef struct _INTERNAL_TCP_TABLE_ENTRY
{
	INTERNAL_TCP_TABLE_SUBENTRY localEntry;
	INTERNAL_TCP_TABLE_SUBENTRY remoteEntry;
}INTERNAL_TCP_TABLE_ENTRY, *PINTERNAL_TCP_TABLE_ENTRY;

typedef struct _NSI_STATUS_ENTRY
{
	ULONG dwState;
	char bytesfill[8];
}NSI_STATUS_ENTRY,*PNSI_STATUS_ENTRY;

typedef struct _NSI_PROCESSID_INFO
{
	ULONG dwUdpProId;
	ULONG UnknownParam2;
	ULONG UnknownParam3;
	ULONG dwProcessId;
	ULONG UnknownParam5;
	ULONG UnknownParam6;
	ULONG UnkonwnParam7;
	ULONG UnkonwnParam8;
}NSI_PROCESSID_INFO,*PNSI_PROCESS_INFO;

typedef struct _NSI_PARAM
{
	ULONG_PTR	UnknownParam1;
	SIZE_T		UnknownParam2;
	PVOID		UnknownParam3;
	SIZE_T		UnknownParam4;
	ULONG		UnknownParam5;
	ULONG		UnknownParam6;
	PVOID		UnknownParam7;
	SIZE_T		UnknownParam8;
	PVOID		UnknownParam9;
	SIZE_T		UnknownParam10;
	PVOID		UnknownParam11;
	SIZE_T		UnknownParam12;
	PVOID		UnknownParam13;
	SIZE_T		UnknownParam14;
	SIZE_T		ConnCount;
}NSI_PARAM, *PNSI_PARAM;

typedef enum _PORT_TYPE
{
	enumTcp,
	enumUdp,
}PORT_TYPE;

typedef struct _PORT_INFO
{
	PORT_TYPE nPorttype;
	ULONG nConnectState;
	ULONG nLocalAddress;
	ULONG nLocalPort;
	ULONG nRemoteAddress;
	ULONG nRemotePort;
	ULONG nPid;
}PORT_INFO, *PPORT_INFO;

typedef struct _COMMUNICATE_PORT
{
	ULONG nCnt;
	PORT_INFO Ports[1];
}COMMUNICATE_PORT, *PCOMMUNICATE_PORT;


NTSTATUS EnumPort(PVOID pInBuffer, ULONG uInSie, PVOID pOutBuffer, ULONG uOutSize, ULONG* dwRet);
NTSTATUS GetWin7NetstatInfo(PPORT_INFO, ULONG, PULONG);
NTSTATUS EnumTcpPortInfoWin7(PMIB_TCPROW_OWNER_PID*, ULONG_PTR*);
NTSTATUS EnumUdpPortInfoWin7(PMIB_UDPROW_OWNER_PID*, ULONG_PTR*);
NTSTATUS GetObjectByName(HANDLE* pFileHandle, OUT PFILE_OBJECT* FileObject, IN WCHAR* DeviceName);
