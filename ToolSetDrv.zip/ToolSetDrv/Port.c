#include"Port.h"

//Ӧ�ò����
NTSTATUS EnumPort(PVOID pInBuffer, ULONG uInSie, PVOID pOutBuffer, ULONG uOutSize, ULONG* dwRet)
{
	UNREFERENCED_PARAMETER(pInBuffer);
	UNREFERENCED_PARAMETER(uInSie);
	NTSTATUS Ntstatus = STATUS_UNSUCCESSFUL;
	PCOMMUNICATE_PORT pCpt = (PCOMMUNICATE_PORT)pOutBuffer;
	PPORT_INFO pPortInfos = pCpt->Ports;
	ULONG nCanStore = (uOutSize - sizeof(ULONG)) / sizeof(PORT_INFO);

	KdPrint(("EnumPort->nCanStore: %d\n", nCanStore));

	__try
	{
		GetWin7NetstatInfo(pPortInfos, nCanStore, &(pCpt->nCnt));

		if (pCpt->nCnt <= nCanStore)
			Ntstatus = STATUS_SUCCESS;
		*dwRet = pCpt->nCnt*sizeof(PORT_INFO) + sizeof(ULONG);
	}
	__except (1)
	{
		Ntstatus = STATUS_UNSUCCESSFUL;
	}

	return Ntstatus;
}

NTSTATUS GetObjectByName(HANDLE* pFileHandle, OUT PFILE_OBJECT* FileObject, IN WCHAR* DeviceName)
{
	UNICODE_STRING DeviceNameUnicode;
	OBJECT_ATTRIBUTES Oa;
	NTSTATUS Status=STATUS_UNSUCCESSFUL;
	HANDLE FileHandle;
	IO_STATUS_BLOCK Io_Status;
	if (!FileObject || !DeviceName )
		return Status;

	RtlInitUnicodeString(&DeviceNameUnicode, DeviceName);
	InitializeObjectAttributes(&Oa,
		&DeviceNameUnicode,
		OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE,
		0, 0);
	Status = ZwCreateFile(
		&FileHandle,
		GENERIC_READ | GENERIC_WRITE | SYNCHRONIZE,
		&Oa,
		&Io_Status,
		0,
		FILE_ATTRIBUTE_NORMAL,
		FILE_SHARE_READ,
		FILE_OPEN,
		0, 0, 0);

	if (!NT_SUCCESS(Status))
	{
		KdPrint(("Failed to Open"));
		return Status;
	}
	Status = ObReferenceObjectByHandle(
		FileHandle,
		FILE_ANY_ACCESS,
		*IoFileObjectType,
		KernelMode,
		(PVOID*)FileObject,
		NULL);

	if (pFileHandle)
	{
		*pFileHandle = FileHandle;
	}
	return Status;
}


NTSTATUS GetWin7NetstatInfo(PPORT_INFO pPortInfos, ULONG nCanStore, PULONG nRetCnt)
{
	PMIB_TCPROW_OWNER_PID TcpRow = NULL;
	PMIB_UDPROW_OWNER_PID UdpRow = NULL;
	ULONG uLocalPort, uRemotePort;

	NTSTATUS Status = STATUS_UNSUCCESSFUL;
	ULONG_PTR num = 0;
	ULONG uTotal = 0;

	if (!pPortInfos || !nCanStore || !nRetCnt)
		return Status;
	*nRetCnt = 0;

	Status = EnumTcpPortInfoWin7(&TcpRow, &num);

	if (NT_SUCCESS(Status) && num > 0 && TcpRow != NULL)
	{
		for (ULONG i = 0; MmIsAddressValid(TcpRow + i)&&i<(ULONG)num; i++)
		{
			uLocalPort = ntohs(TcpRow[i].dwLocalPort);
			//if (TcpRow[i].dwRemoteAddr != 0)
			uRemotePort = ntohs(TcpRow[i].dwRemotePort);

			//filter
			if (TcpRow[i].dwState > 20 || uLocalPort > 0xFFFF)
				continue;

			
			if (nCanStore > uTotal)
			{
				pPortInfos[uTotal].nPorttype = enumTcp;
				pPortInfos[uTotal].nConnectState = TcpRow[i].dwState;
				pPortInfos[uTotal].nLocalAddress = TcpRow[i].dwLocalAddr;
				pPortInfos[uTotal].nLocalPort = uLocalPort;
				pPortInfos[uTotal].nRemoteAddress = TcpRow[i].dwRemoteAddr;
				pPortInfos[uTotal].nRemotePort = uRemotePort;
				pPortInfos[uTotal].nPid = TcpRow[i].dwOwningPid;
			}
			uTotal++;
		}
	}
	if (TcpRow)
	{
		ExFreePool(TcpRow);
		TcpRow = NULL;
	}

	Status = EnumUdpPortInfoWin7(&UdpRow, &num);
	if (NT_SUCCESS(Status) && UdpRow != NULL && (ULONG)num > 0)
	{
		for (ULONG i = 0; MmIsAddressValid(UdpRow + i) && i < (ULONG)num; i++)
		{
			uLocalPort = ntohs(UdpRow[i].dwLocalPort);
			
			//filter
			if (UdpRow[i].dwOwningPid <= 0 || uLocalPort > 0xffff)
				continue;
			KdPrint(("UDP-> Pid:%d, Port:%d\n", UdpRow[i].dwOwningPid, uLocalPort));

			if (nCanStore > uTotal)
			{
				pPortInfos[uTotal].nPorttype = enumUdp;
				pPortInfos[uTotal].nConnectState = 1;
				pPortInfos[uTotal].nLocalAddress = UdpRow[i].dwLocalAddr;
				pPortInfos[uTotal].nLocalPort = uLocalPort;
				pPortInfos[uTotal].nRemoteAddress = 0;
				pPortInfos[uTotal].nRemotePort = 0;
				pPortInfos[uTotal].nPid = UdpRow[i].dwOwningPid;
			}
			uTotal++;
		}
	}
	if (UdpRow)
	{
		ExFreePool(UdpRow);
		UdpRow = NULL;
	}

	*nRetCnt = uTotal;
	return Status;
}

NTSTATUS EnumTcpPortInfoWin7(PMIB_TCPROW_OWNER_PID* TcpRow, ULONG_PTR* len)
{
	PINTERNAL_TCP_TABLE_ENTRY	pBuf1 = NULL;
	PNSI_STATUS_ENTRY			pBuf2 = NULL;
	PNSI_PROCESS_INFO			pBuf3 = NULL;
	PMIB_TCPROW_OWNER_PID		pOutputBuff = NULL;

	NTSTATUS			Status = STATUS_UNSUCCESSFUL;
	KEVENT				Event;
	IO_STATUS_BLOCK		StatusBlock;
	PIRP				pIrp = NULL;
	PIO_STACK_LOCATION	StackLocation = NULL;
	ULONG_PTR			Retlen=0;
	ULONG				i = 0;
	NSI_PARAM			nsiStruct = { 0 };
	WCHAR				szNsi[] = { L"\\Device\\nsi\0" };
	HANDLE				hFile = NULL;
	PFILE_OBJECT		pFileObject = NULL;
	PDEVICE_OBJECT		pDeviceObject = NULL;
	NPI_MODULEID		NPI_MS_TCP_MODULEID=
	{
		/*
		�̶�GUID �Լ����ɵĻ�ʧ�ܣ�Ӧ�����豸����GUID
		*/
		sizeof(NPI_MODULEID),
		MIT_GUID,
		{ 0xEB004A03, 0x9B1A, 0x11D4,
		{ 0x91, 0x23, 0x00, 0x50, 0x04, 0x77, 0x59, 0xBC } }
	};

	if (!TcpRow || !len)
		return Status;
	*len = 0;
	*TcpRow = NULL;

	nsiStruct.UnknownParam3 = &NPI_MS_TCP_MODULEID;
	nsiStruct.UnknownParam4 = 3;
	nsiStruct.UnknownParam5 = 1;
	nsiStruct.UnknownParam6 = 1;

	Status = GetObjectByName(&hFile, &pFileObject, szNsi);

	if (!NT_SUCCESS(Status))
	{
		KdPrint(("��ȡ�ļ�����ʧ��\r\n"));
		goto End;
	}
	//ObReferceObjectByHandle; Ҳ�ǿ��Ի�ȡ���豸����
	pDeviceObject = IoGetRelatedDeviceObject(pFileObject);
	if (!pDeviceObject)
	{
		KdPrint(("��ȡ�豸����ʧ��\r\n"));
		Status = STATUS_UNSUCCESSFUL;
		goto End;
	}

	KdPrint(("nsi Irp_MJ_DEVICE_CONTROL:%08lX\n", pDeviceObject->DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL]));
	KeInitializeEvent(&Event, NotificationEvent, FALSE);
	
	pIrp = IoBuildDeviceIoControlRequest(
		IOCTL_NSI_GETALLPARAM,
		pDeviceObject,
		&nsiStruct,
		sizeof(NSI_PARAM),
		&nsiStruct,
		sizeof(NSI_PARAM),
		FALSE,
		&Event,
		&StatusBlock);
	if (!pIrp)
	{
		Status = STATUS_INSUFFICIENT_RESOURCES;
		KdPrint(("IRP����ʧ��\n"));
		goto End;
	}
	StackLocation = IoGetNextIrpStackLocation(pIrp);
	StackLocation->FileObject = pFileObject;
	StackLocation->DeviceObject = pDeviceObject;
	pIrp->RequestorMode = KernelMode;

	Status = IoCallDriver(pDeviceObject, pIrp);
	KdPrint(("Status:x0x%8lX\r\n", Status));

	if (STATUS_PENDING == Status)
		Status = KeWaitForSingleObject(&Event, Executive, KernelMode, TRUE, 0);

	if (STATUS_SUCCESS != Status)
		goto End;

	Retlen = nsiStruct.ConnCount;
	Retlen += 2;

	pBuf1 = (PINTERNAL_TCP_TABLE_ENTRY)ExAllocatePoolWithTag(
		NonPagedPool,
		sizeof(INTERNAL_TCP_TABLE_ENTRY)*Retlen,
		PORT);

	if (!pBuf1)
	{
		Status = STATUS_INSUFFICIENT_RESOURCES;
		goto End;
	}
	RtlZeroMemory(pBuf1, sizeof(INTERNAL_TCP_TABLE_ENTRY)*Retlen);
	KdPrint(("pBuf1: 0x%08x\n", pBuf1));

	pBuf2 = (PNSI_STATUS_ENTRY)ExAllocatePoolWithTag(
		NonPagedPool, 
		16*Retlen,
		PORT);
	if (!pBuf2)
	{
		Status = STATUS_INSUFFICIENT_RESOURCES;
		goto End;
	}
	RtlZeroMemory(pBuf2, 16 * Retlen);
	KdPrint(("pBuf2: 0x%08X\r\n", pBuf2));

	pBuf3 = (PNSI_PROCESS_INFO)ExAllocatePoolWithTag(
		NonPagedPool, 
		sizeof(NSI_PROCESSID_INFO)*Retlen,
		PORT);
	RtlZeroMemory(pBuf3, sizeof(NSI_PROCESSID_INFO)*Retlen);
	KdPrint(("pBuf3: 0x%08X\r\n", pBuf3));

	pOutputBuff = (PMIB_TCPROW_OWNER_PID)ExAllocatePoolWithTag(
		NonPagedPool, 
		sizeof(MIB_TCPROW_OWNER_PID)*Retlen,
		PORT);
	if (!pOutputBuff)
	{
		Status = STATUS_INSUFFICIENT_RESOURCES;
		goto End;
	}
	RtlZeroMemory(pOutputBuff, Retlen*sizeof(MIB_TCPROW_OWNER_PID));
	KdPrint(("pOutputBuff: 0x%08X\r\n", pOutputBuff));

	nsiStruct.UnknownParam7 = pBuf1;
	nsiStruct.UnknownParam8 = sizeof(INTERNAL_TCP_TABLE_ENTRY);
	nsiStruct.UnknownParam11 = pBuf2;
	nsiStruct.UnknownParam12 = 16;
	nsiStruct.UnknownParam13 = pBuf3;
	nsiStruct.UnknownParam14 = sizeof(NSI_PROCESSID_INFO);

	pIrp = IoBuildDeviceIoControlRequest(
		IOCTL_NSI_GETALLPARAM,
		pDeviceObject,
		&nsiStruct,
		sizeof(NSI_PARAM),
		&nsiStruct,
		sizeof(NSI_PARAM),
		FALSE,
		&Event,
		&StatusBlock);

	if (!pIrp)
	{
		Status = STATUS_INSUFFICIENT_RESOURCES;
		goto End;
	}

	StackLocation = IoGetNextIrpStackLocation(pIrp);
	StackLocation->FileObject = pFileObject;
	StackLocation->DeviceObject = pDeviceObject;
	pIrp->RequestorMode = KernelMode;

	Status = IoCallDriver(pDeviceObject, pIrp);
	KdPrint(("Status: %08lX-%d\r\n", Status, RtlNtStatusToDosError(Status)));

	if (Status == STATUS_PENDING)
		Status = KeWaitForSingleObject(&Event, Executive, KernelMode, TRUE, 0);

	for (i = 0; i < nsiStruct.ConnCount;i++)
	{
		KdPrint(("Status %d\r\n", pBuf2[i].dwState));
		pOutputBuff[i].dwState = pBuf2[i].dwState;

		pOutputBuff[i].dwLocalAddr = pBuf1[i].localEntry.dwIp;
		pOutputBuff[i].dwLocalPort = pBuf1[i].localEntry.Port;
		pOutputBuff[i].dwRemoteAddr = pBuf1[i].remoteEntry.dwIp;
		pOutputBuff[i].dwRemotePort = pBuf1[i].remoteEntry.Port;

		pOutputBuff[i].dwOwningPid = pBuf3[i].dwProcessId;
	}
	*TcpRow = pOutputBuff;
	*len = nsiStruct.ConnCount;
	Status = STATUS_SUCCESS;
End:
	if (NULL != pBuf1)
	{
		ExFreePool(pBuf1);
		pBuf1 = NULL;
	}

	if (NULL != pBuf2)
	{
		ExFreePool(pBuf2);
		pBuf2 = NULL;
	}
	if (NULL != pBuf3)
	{
		ExFreePool(pBuf3);
		pBuf3 = NULL;
	}

	if (NULL != pFileObject)
		ObDereferenceObject(pFileObject);

	if (hFile != NULL)
	{
		ZwClose(hFile);
		hFile = NULL;
	}

	if (!NT_SUCCESS(Status))
	{
		if (pOutputBuff)
		{
			ExFreePool(pOutputBuff);
			pOutputBuff = NULL;
		}
		*TcpRow = NULL;
		*len = 0;
	}
	return Status;
}

NTSTATUS EnumUdpPortInfoWin7(PMIB_UDPROW_OWNER_PID* UdpRow, ULONG_PTR* len)
{
	PINTERNAL_TCP_TABLE_SUBENTRY pBuf1 = NULL;
	PNSI_PROCESS_INFO pBuf2 = NULL;
	PMIB_UDPROW_OWNER_PID pOutputBuff = NULL;
	NTSTATUS status = STATUS_UNSUCCESSFUL;
	PFILE_OBJECT pFileObject = NULL;
	PDEVICE_OBJECT pDeviceObject = NULL;
	KEVENT Event;
	IO_STATUS_BLOCK IoStatusBlock;
	PIRP pIrp = NULL;
	PIO_STACK_LOCATION StackLocation = NULL;
	ULONG_PTR retLen = 0;
	NSI_PARAM nsiStruct = { 0 };
	ULONG i = 0;
	HANDLE hFile = NULL;
	WCHAR szNsi[] = { L"\\Device\\nsi\0" };
	NPI_MODULEID NPI_MS_UDP_MODULEID =
	{
		sizeof(NPI_MODULEID),
		MIT_GUID,
		{ 0xEB004A02, 0x9B1A, 0x11D4,
		{ 0x91, 0x23, 0x00, 0x50, 0x04, 0x77, 0x59, 0xBC } }
	};

	if (!UdpRow || !len)
		return status;

	*len = 0;
	*UdpRow = NULL;

	nsiStruct.UnknownParam3 = &NPI_MS_UDP_MODULEID;
	nsiStruct.UnknownParam4 = 1;
	nsiStruct.UnknownParam5 = 1;
	nsiStruct.UnknownParam6 = 1;

	status = GetObjectByName(&hFile, &pFileObject, szNsi);

	if (!NT_SUCCESS(status))
	{
		KdPrint(("�豸������\r\n"));
		goto _End;
	}

	pDeviceObject = IoGetRelatedDeviceObject(pFileObject);

	if (!pDeviceObject)
	{
		KdPrint(("��ȡ�豸������ļ�����ʧ��\r\n"));
		status = STATUS_UNSUCCESSFUL;
		goto _End;
	}

	KdPrint(("nsi IRP_MJ_DEVICE_CONTROL:%08lx\r\n",
		pDeviceObject->DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL]));
	KeInitializeEvent(&Event, NotificationEvent, FALSE);

	pIrp = IoBuildDeviceIoControlRequest(
		IOCTL_NSI_GETALLPARAM,
		pDeviceObject,
		&nsiStruct,
		sizeof(NSI_PARAM),
		&nsiStruct,
		sizeof(NSI_PARAM),
		FALSE,
		&Event,
		&IoStatusBlock);

	if (pIrp == NULL)
	{
		status = STATUS_INSUFFICIENT_RESOURCES;
		KdPrint(("IRP����ʧ��\r\n"));
		goto _End;
	}
	StackLocation = IoGetNextIrpStackLocation(pIrp);
	StackLocation->FileObject = pFileObject;
	StackLocation->DeviceObject = pDeviceObject;
	pIrp->RequestorMode = KernelMode;

	status = IoCallDriver(pDeviceObject, pIrp);
	KdPrint(("Status:%08lx\r\n", status));

	if (STATUS_PENDING == status)
		status = KeWaitForSingleObject(&Event, Executive, KernelMode, TRUE, 0);

	if (!NT_SUCCESS(status))
		goto _End;

	retLen = nsiStruct.ConnCount;
	retLen += 2;

	//����TCP��UDP �ṹ��һ��
	pBuf1 = (PINTERNAL_TCP_TABLE_SUBENTRY)ExAllocatePoolWithTag(
		NonPagedPool,
		sizeof(INTERNAL_TCP_TABLE_SUBENTRY)*retLen,
		PORT);
	if (pBuf1 == NULL)
	{
		status = STATUS_INSUFFICIENT_RESOURCES;
		goto _End;
	}

	RtlZeroMemory(pBuf1, sizeof(INTERNAL_TCP_TABLE_SUBENTRY)*retLen);
	pBuf2 = (PNSI_PROCESS_INFO)ExAllocatePoolWithTag(
		NonPagedPool, 
		sizeof(NSI_PROCESSID_INFO)*retLen, 
		PORT);
	if (NULL == pBuf2)
	{
		status = STATUS_INSUFFICIENT_RESOURCES;
		goto _End;
	}
	RtlZeroMemory(pBuf2, sizeof(NSI_PROCESSID_INFO)*retLen);

	pOutputBuff = (PMIB_UDPROW_OWNER_PID)ExAllocatePoolWithTag(
		NonPagedPool,
		sizeof(MIB_UDPROW_OWNER_PID)*retLen,
		PORT);
	if (NULL == pOutputBuff)
	{
		status = STATUS_INSUFFICIENT_RESOURCES;
		goto _End;
	}
	RtlZeroMemory(pOutputBuff, retLen*sizeof(MIB_UDPROW_OWNER_PID));

	nsiStruct.UnknownParam7 = pBuf1;
	nsiStruct.UnknownParam8 = sizeof(INTERNAL_TCP_TABLE_SUBENTRY);
	nsiStruct.UnknownParam13 = pBuf2;
	nsiStruct.UnknownParam14 = sizeof(NSI_PROCESSID_INFO);

	pIrp = IoBuildDeviceIoControlRequest(
		IOCTL_NSI_GETALLPARAM,
		pDeviceObject,
		&nsiStruct,
		sizeof(NSI_PARAM),
		&nsiStruct,
		sizeof(NSI_PARAM),
		FALSE,
		&Event,
		&IoStatusBlock);

	if (NULL == pIrp)
	{
		status = STATUS_INSUFFICIENT_RESOURCES;
		KdPrint(("IRP����ʧ��\r\n"));
		goto _End;
	}

	StackLocation = IoGetNextIrpStackLocation(pIrp);
	StackLocation->FileObject = pFileObject;
	StackLocation->DeviceObject = pDeviceObject;
	pIrp->RequestorMode = KernelMode;
	
	status = IoCallDriver(pDeviceObject, pIrp);
	KdPrint(("Status: %08lX\n", status));

	if (STATUS_PENDING == status)
		KeWaitForSingleObject(&Event, Executive, KernelMode, TRUE, 0);

	if (!NT_SUCCESS(status))
		goto _End;

	for (i = 0; i < nsiStruct.ConnCount; i++)
	{
		pOutputBuff[i].dwLocalAddr = pBuf1[i].dwIp;
		pOutputBuff[i].dwLocalPort = pBuf1[i].Port;
		pOutputBuff[i].dwOwningPid = pBuf2[i].dwUdpProId;
	}
	*UdpRow = pOutputBuff;
	*len = nsiStruct.ConnCount;
	status = STATUS_SUCCESS;

_End:
	if (NULL != pBuf1&&MmIsAddressValid(pBuf1))
	{
		ExFreePool(pBuf1);
		pBuf1 = NULL;
	}

	if (NULL != pBuf2&&MmIsAddressValid(pBuf2))
	{
		ExFreePool(pBuf2);
		pBuf2 = NULL;
	}
	if (NULL != pFileObject)
		ObDereferenceObject(pFileObject);

	if (hFile)
	{
		ZwClose(hFile);
		hFile = NULL;
	}

	if (!NT_SUCCESS(status))
	{
		if (pOutputBuff&&MmIsAddressValid(pOutputBuff))
		{
			ExFreePool(pOutputBuff);
			pOutputBuff = NULL;
		}
		*UdpRow = NULL;
		*len = 0;
	}
	return status;
}