
#include"StructAlgorithm.h"



void ProcPidSort()
{

	ULONG* TempNode;
	PDefProcessStruct TempProc;
	ULONG i;
	PAGED_CODE();
	if (BigPid)
	{
		//�Դ�Pid����
	}
	else
	{
		//��СPid����

		KeAcquireSpinLock(&g_LockProcessLisk, &OldIrql);
		TempNode = (ULONG*)ExAllocatePoolWithTag(NonPagedPool, ActiveProcessLinksNumber*sizeof(ULONG), 'Node');
		TempProc = (PDefProcessStruct)g_ProcessSingleHead.Next;
		for (i = 0; i < ActiveProcessLinksNumber; i++)
		{
			if (!TempProc)
				break;

				TempNode[i] = (ULONG)TempProc;
				TempProc = TempProc->NextList;
			
		}
		TempProc = (PDefProcessStruct)g_ProcessSingleHead.Next;


		//���ֿ���
		BinaryQuickSort(TempNode, 0, ActiveProcessLinksNumber - 1);
		g_ProcessSingleHead.Next = (PSINGLE_LIST_ENTRY)TempNode[0];
		TempProc = (PDefProcessStruct)TempNode[0];
		for (i = 1; i < ActiveProcessLinksNumber; i++)
		{
			if (!TempProc)
				break;

			TempProc->NextList = (PDefProcessStruct)TempNode[i];
			TempProc = TempProc->NextList;
		}
		TempProc->NextList = NULL;
		ExFreePool(TempNode);
		KeReleaseSpinLock(&g_LockProcessLisk, OldIrql);
	}
	return;
}

void BinaryQuickSort(ULONG* Array, ULONG Head,ULONG Tail)
{
	PDefProcessStruct ProcHead, ProcTail,TempProc;
	if (Head == Tail)
		return;

	TempProc = (PDefProcessStruct)Array[Head];
	ULONG tempHead, tempTail;
	tempHead = Head;
	tempTail = Tail;
	BOOLEAN Next = TRUE;

	while (tempHead != tempTail)
	{
		ProcHead = (PDefProcessStruct)Array[tempHead];
		ProcTail = (PDefProcessStruct)Array[tempTail];
		if (!ProcHead || !ProcTail)
			break;

		if (Next)
		{
			if (TempProc->Pid > ProcTail->Pid)
			{
				Array[tempHead] = Array[tempTail];
				Next = !Next;
			}
			else
			{
				tempTail--;

				//����Ӧ���Ƕ���ģ�ѭ����ͷ���¸�ֵ��
				ProcTail = (PDefProcessStruct)Array[tempTail];
			}
		}
		else
		{
			if (TempProc->Pid < ProcHead->Pid)
			{
				Array[tempTail] = Array[tempHead];
				Next = !Next;
			}
			else
			{
				tempHead++;

				//����Ӧ���Ƕ���ģ�ѭ����ͷ���¸�ֵ��
				ProcHead = (PDefProcessStruct)Array[tempHead];
			}
		}
	}

	Array[tempHead] = (ULONG)TempProc;
	if (Head == tempHead)
	{
		tempHead++;
		BinaryQuickSort(Array, tempHead, Tail);
		return;
	}
	else
	{
		while (Head<tempHead)
		{
			/* ����֮ǰû�б�ע�͵������Ǹо�û��
			if (Array[tempHead - 1] < Array[tempHead])
			{
				tempHead--;
				continue;
			}
			*/
			BinaryQuickSort(Array, Head, tempTail - 1);
			break;
		}
	}

	tempHead = tempTail;
	if (tempTail == Tail)
	{
		tempTail--;
		BinaryQuickSort(Array, Head, tempTail);
		return;
	}
	else
	{
		while (tempTail < Tail)
		{
			/*1 ����о�û������ע�͵���
			if (Array[tempTail] < Array[tempTail + 1])
			{
				tempTail++;
				continue;
			}
			1*/
			//����֮ǰhead û��+1
			BinaryQuickSort(Array, tempHead - 1, Tail);
			break;
		}
	}
	return;
}
