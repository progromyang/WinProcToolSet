#include"GetHnadle.h"
#include<malloc.h>

NTSTATUS GetProcessHandleList(IN ULONG Pid,OUT PLIST_ENTRY HandleList,OUT PULONG num)
{
	NTSTATUS Status = STATUS_UNSUCCESSFUL;
	CLIENT_ID Id;	
	HANDLE hProcess = NULL;
	HANDLE hDuplicate=NULL;
	PVOID pHandle = NULL;
	SIZE_T ulsize;
	PHANDLE_OBJ_INFO TempHandleList = NULL;
	PSYSTEM_HANDLE_INFORMATION pHandleInfo;
	POBJECT_NAME_INFORMATION ObjName=NULL;
	PKOBJECT_TYPE_INFORMATION ObjType=NULL;
	PKOBJECT_BASIC_INFORMATION ObjBasic=NULL;
	ULONG rnum = 0;
	OBJECT_ATTRIBUTES Os;


	ulsize = 0x4000;	//1000Ϊһҳ
	PAGED_CODE();
	//��ֹ��������
#pragma warning (disable:4127)
	while (1)
	{
		//��Ϊ�Ǵ��û������ NtQuerySystemInformation����ǰһ���̵߳�mode

		//����ı�ǰһ���̵߳�mode
		__asm{
			push ebx
			xor	 ebx,ebx
			mov  eax, dword ptr fs : [00000124h]
			mov  byte ptr[eax + 13Ah],bl
			pop  ebx
		}
		pHandle = ExAllocatePoolWithTag(NonPagedPool, ulsize, GetH);

		if (pHandle == NULL)
		{
			KdPrint(("ExAllocatePool fail phandle"));
			return Status;
		}
		
		memset(pHandle, 0, ulsize);
		Status = NtQuerySystemInformation(SystemHandleInformation, pHandle, ulsize, &rnum);
		if (!NT_SUCCESS(Status))
		{
			KdPrint(("QuerySystemInformation fail %x, ulsize=%x\r\n", Status, ulsize));
			ExFreePool(pHandle);
			ulsize *= 2;
			if (ulsize > 0x8000000)
			{
				KdPrint(("alloc memory greater 128MB"));
				break;
			}

			continue;
		}

		break;
	}
	if (!NT_SUCCESS(Status))
		return Status;

	Id.UniqueProcess = (HANDLE)Pid;
	Id.UniqueThread = 0;

	InitializeObjectAttributes(&Os, NULL, 0, NULL, NULL);
	Status = NtOpenProcess(&hProcess, PROCESS_ALL_ACCESS, &Os, &Id);
	if (!NT_SUCCESS(Status))
	{
		ExFreePool(pHandle);
		KdPrint(("OpenProcess fail Pid=%d, status=%x", Pid, Status));
		return Status;
	}

	pHandleInfo = (PSYSTEM_HANDLE_INFORMATION)pHandle;
	ObjName = (POBJECT_NAME_INFORMATION)ExAllocatePoolWithTag(
		NonPagedPool, 
		512, 
		GetH);
	if (ObjName == NULL)
	{
		KdPrint(("ExAllocatepoolWithTag fail ObjName"));
		Status = STATUS_UNSUCCESSFUL;
		goto End;
	}

	ObjType = (PKOBJECT_TYPE_INFORMATION)ExAllocatePoolWithTag(
		NonPagedPool, 
		512, 
		GetH);
	if (ObjType == NULL)
	{
		KdPrint(("ExAllocatepoolWithTag fail ObjType "));
		Status = STATUS_UNSUCCESSFUL;
		goto End;
	}

	ObjBasic = (PKOBJECT_BASIC_INFORMATION)ExAllocatePoolWithTag(
		NonPagedPool, 
		sizeof(KOBJECT_BASIC_INFORMATION),
		GetH);
	if (ObjBasic == NULL)
	{
		KdPrint(("ExAllocatepoolWithTag fail ObjBasic"));
		Status = STATUS_UNSUCCESSFUL;
		goto End;
	}

	rnum = 0;
	for (ULONG i = 0; i < pHandleInfo->NumberOfHandles; i++)
	{
		if (Pid != pHandleInfo->Handles[i].ProcessId||pHandleInfo->Handles[i].Handle==0)
			continue;

		Status = kZwDuplicateObject(hProcess,
			(HANDLE)pHandleInfo->Handles[i].Handle,
			NtCurrentProcess(),
			&hDuplicate,
			0,
			0,
			DUPLICATE_SAME_ACCESS);

		if (NT_SUCCESS(Status))
		{
			memset(ObjType, 0, 512);
			memset(ObjName, 0, 512);
			memset(ObjBasic, 0, sizeof(KOBJECT_BASIC_INFORMATION));

			
			Status = kZwQueryObject(
				hDuplicate, 
				kObjectTypeInformation,
				ObjType, 
				512, NULL);
			if (!NT_SUCCESS(Status))
			{
				KdPrint(("ZwQueryObject ObjectTypeInformation fail,Status=%x\r\n", Status));
			}
			
			Status = kZwQueryObject(
				hDuplicate,
				kObjectNameInformation,
				ObjName,
				512, NULL);
			
			if (!NT_SUCCESS(Status))
			{
				if (ObjName->Name.Buffer==NULL)
					KdPrint(("ZwQueryObject ObjectNameInformation fail,Status=%x ,Name=NULL\r\n", Status));
				else
					KdPrint(("ZwQueryObject ObjectNameInformation fail,Status=%x ,Name=%ws\r\n", Status,ObjName->Name.Buffer));
			}

			Status = kZwQueryObject(
				hDuplicate,
				kObjectBasicInformation,
				ObjBasic,
				sizeof(KOBJECT_BASIC_INFORMATION), NULL);

			if (!NT_SUCCESS(Status))
			{
				KdPrint(("ZwQueryObject ObjectBasicInformation fail,Status=%x\r\n", Status));
			}

			TempHandleList = (PHANDLE_OBJ_INFO)ExAllocatePoolWithTag(
				NonPagedPool, 
				sizeof(HANDLE_OBJ_INFO), 
				GetH);

			//��ȫ�Լ���ֹ�ڴ����
			ASSERT(ObjName->Name.MaximumLength < 0x200 || ObjType->TypeName.MaximumLength < 0x40);

			memset(TempHandleList, 0, sizeof(HANDLE_OBJ_INFO));
			TempHandleList->Handle = pHandleInfo->Handles[i].Handle;
			TempHandleList->Flags = pHandleInfo->Handles[i].Flags;
			TempHandleList->Object = pHandleInfo->Handles[i].Object;
			TempHandleList->TypeIndex = pHandleInfo->Handles[i].ObjectTypeNumber;
	
			//��Ҫ�İ�ȫ�Լ��
			if (ObjName->Name.Length>0)
				wcsncpy(TempHandleList->Name, ObjName->Name.Buffer,ObjName->Name.Length);
			if (ObjType->TypeName.Length>0)
				wcsncpy(TempHandleList->TypeName, ObjType->TypeName.Buffer, ObjType->TypeName.Length);
			
			TempHandleList->NonPagedPoolUsage = ObjBasic->NonPagedPoolUsage;
			TempHandleList->PagedPoolUsage = ObjBasic->PagedPoolUsage;
			TempHandleList->ReferenceCount = ObjBasic->ReferenceCount;
			TempHandleList->HandleCount = ObjBasic->HandleCount;
			rnum++;

			ZwClose(hDuplicate);
			InsertTailList(HandleList, &TempHandleList->List);
		}
		/*1
		else
		{
			ULONG Error;
			Error=kRtlNtStatusToDosError(Status);
			if (Error == 0x32)
			{
				TempHandleList = (PHANDLE_OBJ_INFO)ExAllocatePoolWithTag(
					NonPagedPool,
					sizeof(HANDLE_OBJ_INFO),
					GetH);

				memset(TempHandleList, 0, sizeof(PHANDLE_OBJ_INFO));
				TempHandleList->Handle = pHandleInfo->Handles[i].Handle;
				TempHandleList->Flags = pHandleInfo->Handles[i].Flags;
				TempHandleList->Object = pHandleInfo->Handles[i].Object;
				TempHandleList->TypeIndex = 0;
				wcscpy(TempHandleList->TypeName, L"Error:0x32\0");
				wcscpy(TempHandleList->Name, L"Handle can't duplicate.\0");
				rnum++;
			}
			else
				KdPrint(("Duplicate Handle Fail Status=%x", Status));
		} 
		1*/
	}

	End:
	PAGED_CODE();
	*num = rnum;
	if (hProcess == NULL)
		ZwClose(hProcess);
	if (pHandle==NULL)
		ExFreePool(pHandle);
	if (ObjName==NULL)
		ExFreePool(ObjName);
	if (ObjBasic==NULL)
		ExFreePool(ObjBasic);
	if (ObjType==NULL)
		ExFreePool(ObjType);

	return Status;
}