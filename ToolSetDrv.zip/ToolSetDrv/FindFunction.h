#ifndef _FINDFUNCTION_H_
#define _FINDFUNCTION_H_

#include<ntifs.h>
#include<ntddk.h>
#include<wdm.h>
#include"typedef.h"

WCHAR g_DosPath[26][0x35];			//�̷����ձ�
extern SINGLE_LIST_ENTRY		g_ProcessSingleHead;
extern unsigned int				dwProcLinkOffer;					//�������ڵ�ƫ��

//����ȫ������ͷ
NTSTATUS FindPsActiveProcessHead(PLIST_ENTRY* pPsActiveProcessHead);
//��������Ϣ��
BOOLEAN InitFullProcInfo(PEPROCESS ProcBlock);
void FreeProcInfo(PSINGLE_LIST_ENTRY);
void InitDosPath();
void InitProcOffset();
BOOLEAN TransformName(PUNICODE_STRING,PWCH);
BOOLEAN IsEmptyUnicode(PUNICODE_STRING);
BOOLEAN IsEmptyWchar(WCHAR* String);
void ProcessNotifyEvent(PEPROCESS, HANDLE, PPS_CREATE_NOTIFY_INFO);
pfnNtQueryInformationProcess	NtQueryInformationProcess;
void GetCpuRateThread(void *x);
unsigned int InitProcessList();
#pragma alloc_text(INIT,InitProcessList)
#pragma alloc_text(INIT,FindPsActiveProcessHead)
#pragma alloc_text(INIT,InitDosPath)
#endif