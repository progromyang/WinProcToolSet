#pragma once
#pragma warning (disable:4201) // �ṹ���� SYSTEM_INFO

#include"EnumInfoClass.h"
//Io���� δ֪�豸����������(���ɹ��ܺ�0x7ff-0xfff),���淽ʽ������Ȩ��
#define UK_PROCESSINFORMATION	\
	(ULONG)CTL_CODE(FILE_DEVICE_UNKNOWN,0x900,METHOD_BUFFERED,FILE_WRITE_DATA|FILE_READ_DATA)
//������������
#define UK_KEYBOARD		\
	(ULONG)CTL_CODE(FILE_DEVICE_UNKNOWN,0x901,METHOD_BUFFERED,FILE_ANY_ACCESS)
//��pid��СΪ�����¼�
#define UK_PROCPIDLIST\
	(ULONG)CTL_CODE(FILE_DEVICE_UNKNOWN,0x902,METHOD_BUFFERED,FILE_WRITE_DATA|FILE_READ_DATA)

#define UK_PACKET\
	(ULONG)CTL_CODE(FILE_DEVICE_UNKNOWN,0x903,METHOD_BUFFERED,FILE_WRITE_DATA|FILE_READ_DATA)

//�����WMware
#define UK_HOOKWMWARE	\
	CTL_CODE(FILE_DEVICE_UNKNOWN,0x904,METHOD_BUFFERED,FILE_WRITE_DATA|FILE_READ_DATA)

//��ѯHandle�¼�
#define UK_QQUERYHANDLE	\
	CTL_CODE(FILE_DEVICE_UNKNOWN,0xA01,METHOD_BUFFERED,FILE_ANY_ACCESS)

#define IDOK 1
#define IDCANCEL 2
#define DELAY_ONE_MICROSECOND (-10)
#define DELAY_ONE_MILLISECOND (DELAY_ONE_MICROSECOND*1000)

//Filter Packet flag
#define PACKET_START	1
#define PACKET_STOP		2
typedef struct _BalanceTree
{
	struct _BalanceTree *Left;
	struct _BalanceTree *Right;
}BalanceTree,*PBalanceTree;

typedef struct _DefProcessStruct
{

	struct _DefProcessStruct	*NextList;
	PVOID				eProcess;
	unsigned int		Pid;	//_EPROCESS+0xB4
	struct _Cpu
	{
		float			CpuRate;
		//��һ�ε�ʱ��
		__int64 last_runtime_time;
		__int64 last_system_time;
	}Cpu;
	ULONG				NameOffsets;  //Path+NameOffsets=Name;
	WCHAR				Path[256];
}DefProcessStruct, *PDefProcessStruct;


typedef NTSTATUS(__stdcall *pfnPsSetCreateProcessNotifyRoutineEx)(
	_In_  PCREATE_PROCESS_NOTIFY_ROUTINE_EX,
	_In_  BOOLEAN);



typedef struct _SYSTEM_INFO {
	union {
		ULONG  dwOemId;
		struct {
			unsigned short wProcessorArchitecture;
			unsigned short wReserved;
		};
	};
	ULONG     dwPageSize;
	void*    lpMinimumApplicationAddress;
	void*    lpMaximumApplicationAddress;
	DWORD_PTR dwActiveProcessorMask;
	ULONG     dwNumberOfProcessors;
	ULONG     dwProcessorType;
	ULONG     dwAllocationGranularity;
	unsigned short     wProcessorLevel;
	unsigned short     wProcessorRevision;
} SYSTEM_INFO;



typedef struct _FILETIME
{
	ULONG lowTime;
	ULONG highTime;
}FILETIME;


typedef struct _NODETAIL
{
	PSINGLE_LIST_ENTRY Previous;
	PDefProcessStruct Proc;
}NODETAIL;



typedef NTSTATUS(__stdcall *pfnNtQuerySystemInformation)(
	_In_       SYSTEM_INFORMATION_CLASS SystemInformationClass,
	_Inout_    PVOID SystemInformation,
	_In_       ULONG SystemInformationLength,
	_Out_opt_  PULONG ReturnLength
	);


typedef NTSTATUS (__stdcall *pfnNtQueryInformationProcess)(
	_In_       HANDLE ProcessHandle,
	_In_       PROCESSINFOCLASS ProcessInformationClass,
	_Out_      PVOID ProcessInformation,
	_In_       ULONG ProcessInformationLength,
	_Out_opt_  PULONG ReturnLength
	);

typedef PEPROCESS(__stdcall *pfnPsGetNextProcess)(PEPROCESS Process);