
#include"KeyBoardFilter.h"

NTSTATUS DispatchGeneral(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp)
{
	if (NULL == DeviceObject->DeviceExtension)
	{
		Irp->IoStatus.Information = 0;
		Irp->IoStatus.Status = STATUS_SUCCESS;
		IoCompleteRequest(Irp, IO_NO_INCREMENT);
		return STATUS_SUCCESS;
	}
	IoSkipCurrentIrpStackLocation(Irp);
	return IoCallDriver(((PC2P_DEV_EXT)DeviceObject->DeviceExtension)->LowerDeviceObject, Irp);
}

NTSTATUS c2pPower(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp)
{
	PC2P_DEV_EXT devExt;
	devExt = (PC2P_DEV_EXT)DeviceObject->DeviceExtension;
	PoStartNextPowerIrp(Irp);
	IoSkipCurrentIrpStackLocation(Irp);
	return PoCallDriver(devExt->LowerDeviceObject, Irp);
}

NTSTATUS c2pPnp(IN PDEVICE_OBJECT DeviceObject, IN PIRP Irp)
{
	PC2P_DEV_EXT devExt;
	PIO_STACK_LOCATION Ioisp;
	NTSTATUS Status;
	devExt = (PC2P_DEV_EXT)DeviceObject->DeviceExtension;
	Ioisp = IoGetCurrentIrpStackLocation(Irp);
	switch (Ioisp->MinorFunction)
	{
	case IRP_MN_REMOVE_DEVICE:
		KdPrint(("IRP_MN_REMOVE_DEVICE\n"));

		//�Ȱ�������ȥ
		IoSkipCurrentIrpStackLocation(Irp);
		IoCallDriver(devExt->LowerDeviceObject, Irp);

		//Ȼ������
		IoDetachDevice(devExt->LowerDeviceObject);
		//ɾ�������豸
		IoDeleteDevice(DeviceObject);
		Status = STATUS_SUCCESS;
		break;

	default:
		//�����������͵�IRP ֱ���·�
		IoSkipCurrentIrpStackLocation(Irp);
		Status = IoCallDriver(devExt->LowerDeviceObject, Irp);
	}
	return Status;
}

NTSTATUS c2pRead(IN PDEVICE_OBJECT DeviceObject, PIRP Irp)
{
	NTSTATUS Status = STATUS_SUCCESS;
	PC2P_DEV_EXT devExt;
	if (Irp->CurrentLocation == 1)
	{
		Irp->IoStatus.Status = Status;
		Irp->IoStatus.Information = 0;
		IoCompleteRequest(Irp, IO_NO_INCREMENT);
		return Status;
	}
	devExt = (PC2P_DEV_EXT)DeviceObject->DeviceExtension;
	

	g_c2pCount++;
	IoCopyCurrentIrpStackLocationToNext(Irp);
	IoSetCompletionRoutine(Irp, c2pReadCompalte, DeviceObject, TRUE, TRUE, TRUE);
	return IoCallDriver(devExt->LowerDeviceObject, Irp);

}
NTSTATUS c2pDevExtInit(
	IN PC2P_DEV_EXT DevExt,
	IN PDEVICE_OBJECT pFilterDeviceObject,
	IN PDEVICE_OBJECT pTargetDeviceObject,
	IN PDEVICE_OBJECT pLowerDeviceObject)
{
	memset(DevExt, 0, sizeof(C2P_DEV_EXT));
	DevExt->NodeSize = sizeof(C2P_DEV_EXT);
	DevExt->pFilterDeviceObject = pFilterDeviceObject;
	DevExt->LowerDeviceObject = pLowerDeviceObject;
	DevExt->TargetDeivceObject = pTargetDeviceObject;
	KeInitializeSpinLock(&(DevExt->IoRequestSpinLock));
	KeInitializeEvent(&DevExt->IoInProgressEvent, NotificationEvent, FALSE);
	return STATUS_SUCCESS;
}

NTSTATUS c2pAttachDevices(
	IN PDRIVER_OBJECT DriverObject,
	IN PUNICODE_STRING RegisterPath)
{
	UNREFERENCED_PARAMETER(RegisterPath);
	NTSTATUS Status = 0;
	UNICODE_STRING uniNtNameString;
	PC2P_DEV_EXT dexExt;
	PDEVICE_OBJECT pFilterDeviceObject = NULL;
	PDEVICE_OBJECT pTargetDeviceObject = NULL;
	PDEVICE_OBJECT LowerDeviceObject = NULL;
	
	PDRIVER_OBJECT kbdDriverObject = NULL;
	RtlInitUnicodeString(&uniNtNameString, KB_DRIVER_NAME);
	Status=ObReferenceObjectByName(
		&uniNtNameString,
		OBJ_CASE_INSENSITIVE,
		NULL,
		0,
		*IoDriverObjectType,
		KernelMode,
		NULL,
		(PVOID *)&kbdDriverObject);

	if (NT_SUCCESS(Status))
	{
		ObDereferenceObject(kbdDriverObject);
	}
	else
	{
		DbgPrint("ObReferenceObjectByName =%ws, Status=%x", uniNtNameString.Buffer,Status);
		return Status;
	}
	
	pTargetDeviceObject = kbdDriverObject->DeviceObject;
	//�����豸��
	while (pTargetDeviceObject)
	{
		Status = IoCreateDevice(
			DriverObject,
			sizeof(C2P_DEV_EXT),
			NULL,
			pTargetDeviceObject->DeviceType,
			pTargetDeviceObject->Characteristics,
			FALSE,
			&pFilterDeviceObject);

		if (!NT_SUCCESS(Status))
		{
			DbgPrint("IoCreateDevce fail");
			return Status;
		}

		LowerDeviceObject = IoAttachDeviceToDeviceStack(pFilterDeviceObject, pTargetDeviceObject);
		if (!LowerDeviceObject)
		{
			DbgPrint("IoAttachDeviceToDeviceStack fail");
			IoDeleteDevice(pFilterDeviceObject);
			pFilterDeviceObject = NULL;
			return Status;
		}

		//�豸��չ
		dexExt = (PC2P_DEV_EXT)(pFilterDeviceObject->DeviceExtension);
		c2pDevExtInit(dexExt, pFilterDeviceObject, pTargetDeviceObject, LowerDeviceObject);

		pFilterDeviceObject->DeviceType = LowerDeviceObject->DeviceType;
		pFilterDeviceObject->Characteristics = LowerDeviceObject->Characteristics;
		pFilterDeviceObject->StackSize = LowerDeviceObject->StackSize + 1;
		pFilterDeviceObject->Flags |= LowerDeviceObject->Flags&(DO_BUFFERED_IO | DO_DIRECT_IO | DO_POWER_PAGABLE);

		pTargetDeviceObject = pTargetDeviceObject->NextDevice;
	}
	return Status;
}

NTSTATUS InitIrpComplateRoutine(PDEVICE_OBJECT Device, PIRP irp, PVOID context)
{
	UNREFERENCED_PARAMETER(context);
	IoInitializeIrp(pCopyIrp, sizeof(IRP), Device->StackSize);
	if (irp->PendingReturned)
	{
		IoMarkIrpPending(pCopyIrp);
	}
	KeSetEvent(irp->UserEvent, 0, TRUE);
	return irp->IoStatus.Status;
}

void KeyBoardThread(void * a)
{
	int Time;
	Time = *(int*)a;
	LARGE_INTEGER Delay;
	Delay.QuadPart = DELAY_ONE_MILLISECOND*Time;
	KeInitializeEvent(&hKeyBoradEvent, SynchronizationEvent, FALSE);
	KeWaitForSingleObject(&hKeyBoradEvent, Executive, KernelMode, FALSE, 0);

	while (bWhile)
	{
		_asm mov al,0xd2
		_asm out 0x64,al
		if (WritePort())
		{
			_asm mov al,ScanCode
			_asm out 0x60,al
		}
		KeDelayExecutionThread(KernelMode,FALSE, &Delay);
	}
	PsTerminateSystemThread(STATUS_SUCCESS);
	return;
}

NTSTATUS c2pReadCompalte(PDEVICE_OBJECT DeviceObject, IN PIRP Irp, IN PVOID context)
{
	UNREFERENCED_PARAMETER(DeviceObject);
	UNREFERENCED_PARAMETER(context);
	g_c2pCount--;
	//�����ȡ������Ϣ ScanCode
	if (!bWhile)
	{
		PKEYBOARD_INPUT_DATA TempKeyboard;
		TempKeyboard = Irp->AssociatedIrp.SystemBuffer;
		if (!TempKeyboard->Flags)		//����
		{
			ScanCode = (UCHAR)TempKeyboard->MakeCode;
			bWhile = TRUE;
			KeSetEvent(&hKeyBoradEvent, 0, TRUE);
		}
	}
	if (Irp->PendingReturned)
	{
		IoMarkIrpPending(Irp);
	}
	return Irp->IoStatus.Status;
}

VOID c2pUnload(PDRIVER_OBJECT DriverObject)
{
//	KeSetBasePriorityThread(NtCurrentThread(), LOW_REALTIME_PRIORITY);
	PDEVICE_OBJECT DeviceObject;
	PC2P_DEV_EXT devExt;
	LARGE_INTEGER Time;
	DeviceObject = DriverObject->DeviceObject;
End:
	while (DeviceObject)
	{
		devExt = (PC2P_DEV_EXT)DeviceObject->DeviceExtension;
		if (DeviceObject->DeviceExtension == NULL)
		{
			DeviceObject = DeviceObject->NextDevice;
			goto End;
		}
		IoDetachDevice(devExt->LowerDeviceObject);
		IoDeleteDevice(DeviceObject);
		DeviceObject = DeviceObject->NextDevice;
	}

	Time.QuadPart = DELAY_ONE_MILLISECOND * 300;
	while (g_c2pCount)
	{
		KeDelayExecutionThread(KernelMode, FALSE, &Time);
	}
	return;
}

BOOLEAN WritePort()
{
	int i = 100;
	P2C_U8 mychar;
	do
	{
		_asm in al,0x64
		_asm mov mychar,al
		if (!(mychar&IBUFFER_FULL))
			break;
		KeStallExecutionProcessor(50);
	} while (i--);
	if (i)
		return TRUE;
	return FALSE;
}
