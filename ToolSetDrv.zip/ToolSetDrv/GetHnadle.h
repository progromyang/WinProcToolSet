#pragma once
#include<ntddk.h>
#include"typedef.h"

extern SINGLE_LIST_ENTRY	g_ProcessSingleHead;
pfnNtQuerySystemInformation		NtQuerySystemInformation;
#define GetH	'GetH'


typedef struct _KSYSTEM_HANDLE_TABLE_ENTRY_INFO
{
	ULONG ProcessId;
	UCHAR ObjectTypeNumber;
	UCHAR Flags;
	USHORT Handle;
	PVOID Object;		//�����Ӧ��EPROCESS
	ACCESS_MASK GrantedAccess;
}KSYSTEM_HANDLE_TABLE_ENTRY_INFO, *PKSYSTEM_HANDLE_TABLE_ENTRY_INFO;

typedef struct _SYSTEM_HANDLE_INFORMATION
{
	ULONG NumberOfHandles;
	KSYSTEM_HANDLE_TABLE_ENTRY_INFO Handles[1];
}SYSTEM_HANDLE_INFORMATION, *PSYSTEM_HANDLE_INFORMATION;


typedef enum _KOBJECT_INFORMATION_CLASS{
	kObjectBasicInformation,
	kObjectNameInformation,
	kObjectTypeInformation,
	kObjectAllInformation,
	kObjectDataInforamtion
}KOBJECT_INFORMATION_CLASS;


typedef struct _KOBJECT_TYPE_INFORMATION
{
	UNICODE_STRING TypeName;
	ULONG TotalNumberOfObject;
	ULONG TotalNumberOfHandle;
	ULONG TotalPagedPoolUsage;
	ULONG TotalNonPagedPoolUsage;
	ULONG TotalNamePoolUsage;
	ULONG TotalHandleTableUsage;
	ULONG HighWaterNumberkOfObjects;
	ULONG HigWaterNumberkOfHandles;
	ULONG HighWaterPagedPoolUsage;
	ULONG HighWaterNonPagedPoolUsage;
	ULONG HighWaterNamePoolUsage;
	ULONG HighWaterHandleTableUsage;
	ULONG InvalidAttributes;
	GENERIC_MAPPING GenericMapping;
	ULONG ValidaAccessMask;
	BOOLEAN SecurityRequired;
	BOOLEAN MaintainHandleCount;
	ULONG PoolType;
	ULONG DefaultPagedPoolCharge;
	ULONG DefaultNonPagedPoolCharge;
}KOBJECT_TYPE_INFORMATION, *PKOBJECT_TYPE_INFORMATION;

typedef struct _KOBJECT_BASIC_INFORMATION
{
	ULONG	Attributes;
	ACCESS_MASK DesiredAccess;
	ULONG	HandleCount;
	ULONG	ReferenceCount;
	ULONG	PagedPoolUsage;
	ULONG	NonPagedPoolUsage;
	ULONG	Reserved[3];
	ULONG	NameInformationLength;
	ULONG	TypeInformationLength;
	ULONG	SecurityDescriptorLength;
	LARGE_INTEGER	CreationTime;
}KOBJECT_BASIC_INFORMATION, *PKOBJECT_BASIC_INFORMATION;


typedef struct _HANDLE_OBJ_INFO
{
	LIST_ENTRY List;
	PVOID	Object;
	USHORT	Handle;
	UCHAR	Flags;
	UCHAR	TypeIndex;
	ULONG	HandleCount;
	ULONG	ReferenceCount;
	ULONG	PagedPoolUsage;
	ULONG	NonPagedPoolUsage;
	WCHAR	TypeName[0x40];
	WCHAR	Name[0x200];
}HANDLE_OBJ_INFO, *PHANDLE_OBJ_INFO;

typedef NTSTATUS (__stdcall *pfnZwQueryObject)(
	_In_opt_   HANDLE Handle,
	_In_       KOBJECT_INFORMATION_CLASS ObjectInformationClass,
	_Out_opt_  PVOID ObjectInformation,
	_In_       ULONG ObjectInformationLength,
	_Out_opt_  PULONG ReturnLength
	);

typedef NTSTATUS (__stdcall *pfnZwDuplicateObject)(
	_In_       HANDLE SourceProcessHandle,
	_In_       HANDLE SourceHandle,
	_In_opt_   HANDLE TargetProcessHandle,
	_Out_opt_  PHANDLE TargetHandle,
	_In_       ACCESS_MASK DesiredAccess,
	_In_       ULONG HandleAttributes,
	_In_       ULONG Options
	);

typedef ULONG (__stdcall *pfnRtlNtStatusToDosError)(
	_In_  NTSTATUS Status
	);


pfnZwQueryObject kZwQueryObject;
pfnZwDuplicateObject kZwDuplicateObject;
pfnRtlNtStatusToDosError kRtlNtStatusToDosError;
pfnZwQueryObject kabc;


NTSTATUS GetProcessHandleList(IN ULONG , IN PLIST_ENTRY, OUT PULONG);


typedef struct _SYSTEM_BASIC_INFORMATION {
	CHAR Reserved1[24];
	PVOID Reserved2[4];
	CCHAR NumberOfProcessors;
} SYSTEM_BASIC_INFORMATION;
