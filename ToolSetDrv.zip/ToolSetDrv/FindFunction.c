
#include"FindFunction.h"

extern PLIST_ENTRY			PsActiveProcessHead;				//Processȫ������ͷ


#pragma warning (disable:4055)		// ������ת����: ������ָ�롰PVOID��  MmGetSystemRoutineAddress
#pragma warning (disable:4127)		//warning C4127: ��������ʽ�ǳ���
extern KSPIN_LOCK	g_LockProcessLisk;
extern KEVENT		ProcstructUpdateEvent;
extern ULONG		ActiveProcessLinksNumber;
extern BOOLEAN		bGetCpuRateThreadSwitch;
#define MEM_PROC 'Proc'

ULONG ProcessorNumber = 0;
BOOLEAN IsEmptyUnicode(PUNICODE_STRING Us)
{
	if (Us == NULL)
	{
		DbgPrint("Pointer NULL");
	//	ASSERT(Us);
		return 1;
	}

	if (Us->Buffer == NULL)
	{
		DbgPrint("Empry Address");
		return 1;
	}

	if (Us->Buffer[0] == '\0')
	{
		DbgPrint("Empty String");
		return 1;
	}

	return 0;
}

BOOLEAN IsEmptyWchar(WCHAR* String)
{
	if (String == NULL)
	{
		DbgPrint("Empty Pointer");
		return 1;
	}
	if (String[0] == '\0')
	{
		DbgPrint("Empty String");
		return 1;
	}
	return 0;
}

//����ȫ������ͷ
NTSTATUS FindPsActiveProcessHead(PLIST_ENTRY* pPsActiveProcessHead)
{
	PEPROCESS Process;
	PLIST_ENTRY pList = NULL;
	NTSTATUS status = PsLookupProcessByProcessId((HANDLE)4, &Process);
	if (!NT_SUCCESS(status))
	{
		DbgPrint("psLookupProcessByProcessId =%x", status);
		return status;
	}
	pList = (PLIST_ENTRY)((PUCHAR)Process + dwProcLinkOffer);
	*pPsActiveProcessHead = pList->Blink;
	
	ObDereferenceObject(Process);
	return status;
}


//��ʼ������·��
void InitDosPath()
{
	WCHAR A = 'A';
	OBJECT_ATTRIBUTES Oa;
	HANDLE LinkHanlde;
	HANDLE DirectoryHandle;
	UNICODE_STRING tempPath,DosPath;
	ULONG Ret;
	NTSTATUS status;

	RtlInitUnicodeString(&tempPath, L"\\??");
	Oa.Attributes = OBJ_CASE_INSENSITIVE;
	Oa.Length = sizeof(OBJECT_ATTRIBUTES);
	Oa.ObjectName = &tempPath;
	Oa.RootDirectory = NULL;
	Oa.SecurityDescriptor = NULL;
	Oa.SecurityQualityOfService = NULL;

	status=ZwOpenDirectoryObject(&DirectoryHandle, DIRECTORY_QUERY, &Oa);
	if (!NT_SUCCESS(status))
	{
		DbgPrint("ZwOpenDirectoryObject fail =%x", status);
		return;
	}
	int Count = 26;
	int Index = 0;
	memset(g_DosPath, 0, sizeof(g_DosPath));
	do
	{
		RtlZeroMemory(&DosPath, sizeof(UNICODE_STRING));
		WCHAR tempName[3] = { 0, ':','\0' };
		tempName[0] = A;
		RtlInitUnicodeString(&tempPath, tempName);
	//	InitializeObjectAttributes(&Oa, &tempPath, OBJ_CASE_INSENSITIVE, DirectoryHandle, NULL);
		Oa.Attributes = OBJ_CASE_INSENSITIVE;
		Oa.Length = sizeof(OBJECT_ATTRIBUTES);
		Oa.ObjectName = &tempPath;
		Oa.RootDirectory = DirectoryHandle;
		Oa.SecurityDescriptor = NULL;
		Oa.SecurityQualityOfService = NULL;
		status = ZwOpenSymbolicLinkObject(&LinkHanlde,0x1 , &Oa);
		if (!NT_SUCCESS(status))
		{
			DbgPrint("ZwOpenSymbolicLinkObject fail =%x", status);
			goto Error0x34;
		}

		DosPath.Buffer = g_DosPath[Index];
		DosPath.MaximumLength = 0x35;
		status=ZwQuerySymbolicLinkObject(LinkHanlde, &DosPath, &Ret);
		if (!NT_SUCCESS(status))
		{
			DbgPrint("ZwQuerySymbolicLinkObject fail =%x", status);
		}
		NtClose(LinkHanlde);
	Error0x34:
		DbgPrint("%wc = %ws ", A, DosPath.Buffer);
		A += 1;
		Index++;
	} while (--Count);

	NtClose(DirectoryHandle);
	return;
}

//�豸·��ת����·��
BOOLEAN TransformName(PUNICODE_STRING CompaletePath,PWCH Path)
{
	BOOLEAN Ret = 0;
	WCHAR A = 'A';
	if (IsEmptyUnicode(CompaletePath))
	{
		DbgPrint("Name is Empty\r\n");
		return 0;
	}
	for (int i = 0; i < 26; i++)
	{
		if (IsEmptyWchar(g_DosPath[i]))
			continue;

		if (!wcsncmp(g_DosPath[i], CompaletePath->Buffer, wcslen(g_DosPath[i])))
		{
			ULONG CharLen = wcslen(g_DosPath[i]);
			A =(WCHAR)((int)A+ i);
			Path[0] = A;
			Path[1] = ':';
			/*	//�˺�����Bug  ���ָ��+1
			wcsncpy_s(&PathBuffer[2],
				wcslen(CompaletePath->Buffer +CharLen),
				CompaletePath->Buffer + CharLen-1, 
				wcslen(CompaletePath->Buffer + CharLen));
			1*/
			wcsncpy(&Path[2],
				CompaletePath->Buffer + CharLen,
				wcslen(CompaletePath->Buffer + CharLen));
		
			Ret = TRUE;
			DbgPrint("Path = %ws\r\n", Path);
			break;
		}
	}
	return Ret;
}

//�����̽ṹ��Ϣ
BOOLEAN InitFullProcInfo(PEPROCESS ProcBlock)
{
	NTSTATUS Status = STATUS_SUCCESS;
	PUNICODE_STRING PathName;
	PDefProcessStruct TempProcessStruct,pIdel;
	KIRQL OldIrql;
	//�����ڴ�
	TempProcessStruct=
		(PDefProcessStruct)ExAllocatePoolWithTag(NonPagedPool, sizeof(DefProcessStruct), MEM_PROC);
	RtlZeroMemory(TempProcessStruct, sizeof(DefProcessStruct));

	TempProcessStruct->eProcess = ProcBlock;
	TempProcessStruct->Pid = (ULONG)PsGetProcessId(ProcBlock);	//��ȡ����ID
	if (TempProcessStruct->Pid <= 4)
	{	//����system,idle���������⴦��
		//����Ӧ�����ж�ϵͳ�汾,�˴�����֧��Win7
		CHAR tempbuffer[0xf] = {0,};
		TempProcessStruct->NameOffsets = 0;
		strncpy(tempbuffer,
			(CHAR*)ProcBlock + 0x16c,
			strlen((CHAR*)ProcBlock + 0x16c));
		RtlMultiByteToUnicodeN(TempProcessStruct->Path, 256, NULL, tempbuffer, strlen(tempbuffer));
	}
	else
	{
		Status = SeLocateProcessImageName(ProcBlock, &PathName);

		if (!TransformName(PathName, TempProcessStruct->Path))		//ʧ���򷵻�
			return FALSE;

		TempProcessStruct->NameOffsets =
			(wcsrchr(TempProcessStruct->Path, '\\') - TempProcessStruct->Path + 1);
	}

	if (!NT_SUCCESS(Status))
	{
		DbgPrint("SeLocateProcessImageName %0x - Pid = %d\r\n", 
			Status, (ULONG)PsGetProcessId(ProcBlock));
		return FALSE;
	}

	ExAcquireSpinLock(&g_LockProcessLisk, &OldIrql);
	ActiveProcessLinksNumber++;
		//Idel ���̵�PEPROCESS�洢�������������һ��Ԫ��
		pIdel = (PDefProcessStruct)g_ProcessSingleHead.Next;
		if (pIdel->eProcess)
		{
			((PDefProcessStruct)pIdel->eProcess)->NextList = TempProcessStruct;
			pIdel->eProcess = (PEPROCESS)TempProcessStruct;
		}
		else
		{
			//��һ������
			pIdel->NextList = TempProcessStruct;
			pIdel->eProcess = TempProcessStruct;
		}

	ExReleaseSpinLock(&g_LockProcessLisk, OldIrql);
	
	return TRUE;
}

void FreeProcInfo(PSINGLE_LIST_ENTRY Freelist)
{
	
	PDefProcessStruct TempProc0,TempProc1;
	TempProc0 = (PDefProcessStruct)Freelist->Next;
	while (TempProc0)
	{
		TempProc1 = TempProc0->NextList;
		ExFreePool(TempProc0);
		TempProc0 = TempProc1;
	}
	return;
}

void ProcessNotifyEvent(
	IN OUT PEPROCESS Procstruct,
	IN HANDLE ProcessId,
	IN OPTIONAL PPS_CREATE_NOTIFY_INFO CreateInfo)
{
//	UNREFERENCED_PARAMETER(ProcessId);
	KIRQL OldIrql;
	PDefProcessStruct TempProc, ExitProc;
	
	//����Ϊ���������߼��ͷ������ڴ�
	if (CreateInfo==NULL)	//��CreateInfoΪ��ʱΪ��������
	{
		ExAcquireSpinLock(&g_LockProcessLisk, &OldIrql);

		TempProc = (PDefProcessStruct)g_ProcessSingleHead.Next;

		//��һ����Idel ��Ӧ�ûᱻ����
		while (TempProc)
		{
			if (TempProc->NextList&&TempProc->NextList->eProcess == (PVOID)Procstruct)
			{
				ExitProc = TempProc->NextList;
				TempProc->NextList = ExitProc->NextList;

				if (!TempProc->NextList)
					((PDefProcessStruct)g_ProcessSingleHead.Next)->eProcess = (PEPROCESS)TempProc;	//����������һ��Ԫ��ɾ����Ҫ����Idel

				KdPrint(("Exit Process Name=%d \r\n", ExitProc->Pid));
				ExFreePool(ExitProc);
				break;
			}
			TempProc = TempProc->NextList;
		}
		
		if (!TempProc)
		{
			DbgPrint(("Not Found PID = %d EPROCESS= 0x%x \r\n", ProcessId, (PVOID)Procstruct));
			ExReleaseSpinLock(&g_LockProcessLisk, OldIrql);
			return;
		}
		ActiveProcessLinksNumber--;

		/*

		BOOLEAN HeadTail=TRUE;
		ULONG i = 0;
		ProcArray = ExAllocatePoolWithTag(NonPagedPool, sizeof(ULONG)*ActiveProcessLinksNumber, MEM_PROC);
		TempProc = (PDefProcessStruct)g_ProcessSingleHead.Next;
		for (; i < ActiveProcessLinksNumber; i++)
		{
			ProcArray[i] = TempProc;
			if (TempProc)
				TempProc = TempProc->NextList;
		}
		i = 0;


		TempProc = ProcArray[i];
		while (TempProc)
		{
			if (TempProc->eProcess == Procstruct)
				break;
			i++;
			TempProc = ProcArray[i];
		}
		if (!TempProc)
		{
			KdPrint(("Not Found PID\r\n"));
			ExReleaseSpinLock(&g_LockProcessLisk, OldIrql);
			return;
		}

		if (i == 0)
		{
			g_ProcessSingleHead.Next = (PSINGLE_LIST_ENTRY)ProcArray[1];
			HeadTail = FALSE;
		}
		else if (ProcArray[i]->NextList==NULL )
		{
			ProcArray[i - 1]->NextList = NULL;
			HeadTail = FALSE;
		}

		if (HeadTail)
			ProcArray[i - 1]->NextList = ProcArray[i]->NextList;

		ExFreePool(ProcArray[i]);
		ExFreePool(ProcArray);
		ActiveProcessLinksNumber--;
		*/
		//�ͷ����������¼�

		ExReleaseSpinLock(&g_LockProcessLisk, OldIrql);
	}
	else
	{
		//����Ϊ���������߼����ѽ��̽ṹ��������
		//��������Ϣ�����ⲻӦ�ü�������������
		InitFullProcInfo(Procstruct);
	}

	return;
}

//��ȡCpuʹ����
float GetCpuRate(PDefProcessStruct ProcList,LARGE_INTEGER SystemTotal)
{
	NTSTATUS status;
	OBJECT_ATTRIBUTES Oa;
	CLIENT_ID	Client_id;
	HANDLE hProcess;
	KERNEL_USER_TIMES TimeStruct;
	ULONG ret_len;
//	KIRQL irql;
	__int64 KernelUserTotal;		//�з���
	double runtime_deviation;		//��������ƫ��
	double systemtime_deviation;	//ϵͳʱ��ƫ��
	//��ȫ���
	if (!MmIsAddressValid(ProcList))
		return 0;

	if (ProcessorNumber == 0)
		ProcessorNumber = KeQueryActiveProcessorCount(NULL);

	if (ProcList->Pid == 0)
		return 0;

	Client_id.UniqueProcess = (HANDLE)ProcList->Pid;
	Client_id.UniqueThread = 0;
	
	InitializeObjectAttributes(&Oa, NULL, OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE, NULL, NULL);
//	irql = 0;
//	KeLowerIrql(irql);

	status = ObOpenObjectByPointer(
		ProcList->eProcess, 
		OBJ_KERNEL_HANDLE,
		NULL ,
		0 ,
		*PsProcessType ,
		KernelMode , 
		&hProcess);
	if (!NT_SUCCESS(status))
	{
		KdPrint(("NtOpenProcess fail, Status=%x pid=%d", status,ProcList->Pid));
		return 0;
	}
	NtQueryInformationProcess(hProcess, ProcessTimes, &TimeStruct, sizeof(KERNEL_USER_TIMES), &ret_len);
	ZwClose(hProcess);
//	irql = 2;
//	KeRaiseIrql(irql, &irql);
	KernelUserTotal =  TimeStruct.KernelTime.QuadPart + TimeStruct.UserTime.QuadPart; // /10000
	KernelUserTotal /= 10000;
	if (ProcList->Cpu.last_system_time == 0 || ProcList->Cpu.last_runtime_time == 0)
	{
		ProcList->Cpu.last_system_time = SystemTotal.LowPart;
		ProcList->Cpu.last_runtime_time = KernelUserTotal;
		return 0;
	}
	systemtime_deviation = (double)(SystemTotal.LowPart - ProcList->Cpu.last_system_time);
	runtime_deviation = (double)(KernelUserTotal - ProcList->Cpu.last_runtime_time);
	if (systemtime_deviation == 0)
		return 0;

	ProcList->Cpu.CpuRate = (float)(runtime_deviation * 100 / systemtime_deviation / ProcessorNumber);// -0.5;
	ProcList->Cpu.last_system_time = SystemTotal.LowPart;
	ProcList->Cpu.last_runtime_time = KernelUserTotal;
	return ProcList->Cpu.CpuRate;
}

void GetCpuRateThread(void *x)
{
	UNREFERENCED_PARAMETER(x);
	LARGE_INTEGER delayTime;
	PDefProcessStruct TempProcInfoList,IdleProc;
	float CpuRate;
	KIRQL OldIrql;
//	LARGE_INTEGER SystemTotal;	//��1601������ʱ��
	UNICODE_STRING Routine;
	RtlInitUnicodeString(&Routine, L"NtQueryInformationProcess");
	NtQueryInformationProcess = (pfnNtQueryInformationProcess)MmGetSystemRoutineAddress(&Routine);
	LARGE_INTEGER TickTime;
	ULONG TimeIncrement;
	TimeIncrement = KeQueryTimeIncrement();		//��ȡ��100����Ϊ��λ��һ���δ���ֵ�Ĵ�С��0x26161
	TempProcInfoList = (PDefProcessStruct)g_ProcessSingleHead.Next;
	while (1)
	{
		if (TempProcInfoList->Pid == 0)
		{
			IdleProc = TempProcInfoList;
			break;
		}
		TempProcInfoList = TempProcInfoList->NextList;
	}
	
	while (bGetCpuRateThreadSwitch)
	{
		CpuRate = 0;
		KeAcquireSpinLock(&g_LockProcessLisk, &OldIrql);
		
		TempProcInfoList = (PDefProcessStruct)g_ProcessSingleHead.Next;
		KeQueryTickCount(&TickTime);			//�Եδ���Ϊ��λ��ֵ
		TickTime.QuadPart *= TimeIncrement;
		TickTime.QuadPart /= 10000;
	//	KeQuerySystemTime(&SystemTotal);
		//ȫ����������������Ӧ�üӰ���
		for (; TempProcInfoList != NULL;)
		{
			float ret_f;
			ret_f = GetCpuRate(TempProcInfoList, TickTime);
			CpuRate += ret_f;
			TempProcInfoList = TempProcInfoList->NextList;
		}
		KeReleaseSpinLock(&g_LockProcessLisk, OldIrql);
		IdleProc->Cpu.CpuRate = (float)100 - CpuRate;
		delayTime.QuadPart = DELAY_ONE_MILLISECOND * 1000; //һ��
		KeDelayExecutionThread(KernelMode, FALSE, &delayTime);
	}
	PsTerminateSystemThread(STATUS_SUCCESS);
	return;
}

unsigned int InitProcessList()
{
	ActiveProcessLinksNumber = 0;
	//MmProcessLiskȫ����������Idle����Eprocess��
	//�������Լ�����һ��Idle��Ϣ
	KIRQL OldIrql;
	PDefProcessStruct IdleProc;
	IdleProc = (PDefProcessStruct)ExAllocatePoolWithTag(NonPagedPool, sizeof(DefProcessStruct), MEM_PROC);
	memset(IdleProc, 0, sizeof(DefProcessStruct));
	IdleProc->Pid = 0;
	IdleProc->eProcess = NULL;
	IdleProc->NameOffsets = 0;
	wcscpy(IdleProc->Path, L"Idle");

	ExAcquireSpinLock(&g_LockProcessLisk, &OldIrql);
	ActiveProcessLinksNumber++;
	g_ProcessSingleHead.Next = (PSINGLE_LIST_ENTRY)IdleProc;
	ExReleaseSpinLock(&g_LockProcessLisk, OldIrql);


	PLIST_ENTRY TempList;
	for (TempList = PsActiveProcessHead->Flink; TempList != PsActiveProcessHead; TempList = TempList->Flink)
	{
		PEPROCESS TempProcess;
		//�������̣� �����ڵ�Ϊ����ƫ�� ActiveProcessLinks ������ȥƫ�Ƶó���ͷ
		TempProcess = (PEPROCESS)((PUCHAR)TempList - dwProcLinkOffer);
		InitFullProcInfo(TempProcess);
	}
	return ActiveProcessLinksNumber;
}


void InitProcOffset()
{
	//��ȡEPROCESS �ṹ��ʼ���������ڵ�ƫ��
	ULONG Offset;
	PEPROCESS proc;

	Offset = (ULONG)PsActiveProcessHead->Flink;	//����ڵ�Ӧ��Ϊsystem����ID Ϊ4�Ľڵ��ַ
	PsLookupProcessByProcessId((HANDLE)4, &proc);

	dwProcLinkOffer = Offset - ((ULONG)proc);
}