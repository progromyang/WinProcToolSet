#include<ntifs.h>
#include"GetHnadle.h"
#include"Port.h"
#include"KeyBoardFilter.h"
#include"StructAlgorithm.h"
#include"GlobalVariable.h"
#include"FindFunction.h"
#include"HookSSDT.h"


NTSTATUS DriverEntry(
	IN OUT PDRIVER_OBJECT	DriverObject,
	IN PUNICODE_STRING		RegistryPath);

VOID DriverUnload(IN PDRIVER_OBJECT DriverObject);

//Ԥ����
#pragma alloc_text(INIT,DriverEntry)
#pragma alloc_text(PAGE,DriverUnload)




VOID
DriverUnload(IN PDRIVER_OBJECT DriverObject)
{
	LARGE_INTEGER Delay_time;
	Delay_time.QuadPart = DELAY_ONE_MILLISECOND * 5000;
	PAGED_CODE();
	NTSTATUS Status = STATUS_SUCCESS;
	bGetCpuRateThreadSwitch = FALSE;
	ZwWaitForSingleObject(hGetCpuRateThread, FALSE, &Delay_time);

	//�ж��Ƿ�ж�ؼ��̹��ˣ�
	if (bKeyBoardFilter)
	{//û��ж�ؽ�ж��
		bWhile = FALSE;
		ZwWaitForSingleObject(hKeyBoard, FALSE, &Delay_time);
		c2pUnload(DriverObject);
	}
	IoDeleteDevice(g_cdo);
	g_cdo = NULL;
	DbgPrint("Global Control Device Object =%x.", g_cdo);
	DbgPrint("Name= %ws \r\n", cdo_name.Buffer);
	Status=IoDeleteSymbolicLink(&syb_name);
	if (Status)
	{
		DbgPrint("DeleteSymbolic fail=%x", Status);
	}
	else
	{
		DbgPrint("DeleteSymbolic Success!. %ws",syb_name.Buffer);
	}
	FreeProcInfo(&g_ProcessSingleHead);
	PsSetCreateProcessNotifyRoutineEx((PCREATE_PROCESS_NOTIFY_ROUTINE_EX)ProcessNotifyEvent, TRUE); //�Ƴ�֪ͨ
//	FreeProcInfo(&g_ProcessSingleHead);
	UNREFERENCED_PARAMETER(DriverObject);
	
	if (bHookWMware)
		UnCheckVMware();
	DbgPrint("DriverUnload");
	return;
}

NTSTATUS DrvCreateAndClose(IN PDEVICE_OBJECT Dev, IN PIRP irp)
{
	PIO_STACK_LOCATION irpsp = IoGetCurrentIrpStackLocation(irp);
	NTSTATUS status = STATUS_SUCCESS;
	ULONG ret_len = 0;
	while (Dev == g_cdo)
	{
		if (irpsp->MajorFunction == IRP_MJ_CREATE || irpsp->MajorFunction == IRP_MJ_CLOSE)
		{
			// ���ɺ͹ر��������һ�ɼ򵥵ط��سɹ��Ϳ���
			// �ˡ��������ۺ�ʱ�򿪺͹رն����Գɹ���
			//break;
			irp->IoStatus.Information = ret_len;
			irp->IoStatus.Status = status;
			IoCompleteRequest(irp, IO_NO_INCREMENT);
			return status;
		}
	}
	return status;
}

NTSTATUS DrvControlIoDevice(IN PDEVICE_OBJECT Dev, IN PIRP irp)
{
	PAGED_CODE();
	PIO_STACK_LOCATION irpsp = IoGetCurrentIrpStackLocation(irp);
	NTSTATUS status = STATUS_SUCCESS;
	ULONG ret_len = 0;
	LARGE_INTEGER Time;
	LIST_ENTRY HandleList;
	PLIST_ENTRY TempHandle = NULL;
	while (g_cdo == Dev)
	{
		if (irpsp->MajorFunction == IRP_MJ_DEVICE_CONTROL)
		{
			//����DeviceIoControl
			PVOID Buffer = irp->AssociatedIrp.SystemBuffer;
			ULONG outlen = irpsp->Parameters.DeviceIoControl.OutputBufferLength;
			ULONG inlen = irpsp->Parameters.DeviceIoControl.InputBufferLength;
			static KEYBOARD pKey;
			
			switch (irpsp->Parameters.DeviceIoControl.IoControlCode)
			{
			case UK_QURYPORTINFO:
				EnumPort(NULL, 0, Buffer, outlen, &ret_len);
				break;

			case UK_PROCESSINFORMATION:
				if (inlen)
				{
					*(ULONG*)Buffer = ActiveProcessLinksNumber;
					ret_len = outlen;
					break;
				}
				else
				{
					PAGED_CODE();
					KIRQL OldIrql;
					ExAcquireSpinLock(&g_LockProcessLisk, &OldIrql);
					PDefProcessStruct Processstruct = (PDefProcessStruct)g_ProcessSingleHead.Next;
					int i = ActiveProcessLinksNumber;
					while (i)
					{
						//һ��Ҫ�����Ч��
						if (!Processstruct)
							break;

							memcpy(Buffer, (PVOID)Processstruct, sizeof(DefProcessStruct));
							Buffer = (PUCHAR)Buffer + sizeof(DefProcessStruct);
							Processstruct = Processstruct->NextList;
							i--;
						
					}
					ExReleaseSpinLock(&g_LockProcessLisk, OldIrql);
					ret_len = outlen;
					break;
				}
				break;

			case UK_KEYBOARD:
				memcpy(&pKey, Buffer, sizeof(KEYBOARD));
				switch (pKey.Id)
				{
				case IDOK:
					bKeyBoardFilter = TRUE;
					bWhile = FALSE;
					status=c2pAttachDevices(g_DriverObject, NULL);
					if (NT_SUCCESS(status))
						PsCreateSystemThread(&hKeyBoard,
						0,
						NULL,
						NULL,
						NULL,
						(PKSTART_ROUTINE)KeyBoardThread,
						&pKey.DelayTime);
					else
						KdPrint(("KeyBoardFilter fail %x", status));
					break;
				case IDCANCEL:
					Time.QuadPart = DELAY_ONE_MILLISECOND * 1000;
					bKeyBoardFilter = FALSE;
					if (bWhile)
					{
						bWhile = FALSE;
						KeSetEvent(&hKeyBoradEvent, 0, TRUE);
						//����ȴ��߳̽�������ΪSetEvent�����Ȩ�ޣ�
						//��������û��ռ佫�������ȴ��߳̽���
						ZwWaitForSingleObject(hKeyBoard, FALSE, 0);
					}
					c2pUnload(g_DriverObject);
					break;
				}
				break;
			case UK_PROCPIDLIST:
				ProcPidSort();
				break;

			case UK_HOOKWMWARE:
				CheckVMware();
				KdPrint(("Hook WMware success\r\n"));
				break;

			case UK_QQUERYHANDLE:
				if (outlen == 4)
				{
					ULONG num = *(PULONG)Buffer;
					InitializeListHead(&HandleList);
					status = GetProcessHandleList(num, &HandleList,&num);
					if (NT_SUCCESS(status))
					{
						ret_len = sizeof(ULONG);
						*(ULONG*)Buffer = num;// num;

						while (&HandleList != HandleList.Flink)
						{
							TempHandle = HandleList.Flink;
							RemoveEntryList(TempHandle);
					//		KdPrint(("Head=%x ExFreePool=%x Next=%x \r\n", &HandleList, TempHandle, TempHandle->Flink));
							ExFreePool(TempHandle);
						}
						break;
					}
					else
						KdPrint(("GetProcessHeadList Fail Success=%x", status));

					*(ULONG*)Buffer = 0;
					ret_len = 0;
					break;
				}
				else
				{
					ULONG num=*(PULONG)Buffer;
					InitializeListHead(&HandleList);
					status = GetProcessHandleList(num, &HandleList, &num);
					if (NT_SUCCESS(status))
					{
						ret_len = num*sizeof(HANDLE_OBJ_INFO);

						while (&HandleList!=HandleList.Flink)
						{
							TempHandle = HandleList.Flink;
							RtlCopyMemory(Buffer, TempHandle, sizeof(HANDLE_OBJ_INFO));
							Buffer = (PCHAR)Buffer + sizeof(HANDLE_OBJ_INFO);
					//		KdPrint(("Head=%x ExFreePool=%x Next=%x \r\n", &HandleList, TempHandle, TempHandle->Flink));
							RemoveEntryList(TempHandle);
							ExFreePool(TempHandle);
						}

						break;
					}
					*(ULONG*)Buffer = 0;
					ret_len = 0;
					break;
				}
			}
		}
		break;
	}
	PAGED_CODE();
	irp->IoStatus.Information = ret_len;
	irp->IoStatus.Status = status;
	IoCompleteRequest(irp, IO_NO_INCREMENT);
	return status;
}

NTSTATUS DrvRead(IN PDEVICE_OBJECT Dev, IN PIRP irp)
{
	UNREFERENCED_PARAMETER(irp);
	NTSTATUS Status=STATUS_SUCCESS;
	while (Dev == g_cdo)
	{
		//�����Լ��Ĳ���
		return Status;
	}
	return Status;
}

NTSTATUS DrvWrite(IN PDEVICE_OBJECT Dev, IN PIRP irp)
{
	UNREFERENCED_PARAMETER(irp);
	NTSTATUS Status = STATUS_SUCCESS;
	while (Dev == g_cdo)
	{
		//�����Լ��Ĳ���
		return Status;
	}
	return Status;
}

NTSTATUS DriverEntry(
	IN OUT PDRIVER_OBJECT	DriverObject,
	IN PUNICODE_STRING		RegistryPath)
{
	DbgPrint("Enter Driver,ToolSet\n");
	NTSTATUS Status = STATUS_SUCCESS;
	g_DriverObject = DriverObject;
	UNREFERENCED_PARAMETER(RegistryPath);
	/*
	��ͬ���¼�����Ϊ�ź�״̬ʱ��
	�ȴ��¼����ź�֪ͨ�ĵ���ִ���߳̽����ͷţ�
	�¼����Զ�����Ϊδ�ź�״̬��

	��ͬ���¼���ͬ��֪ͨ�¼������Զ����õġ�
	һ��֪ͨ�¼������ź�״̬��
	�������ָ�״̬��ֱ����ʽ����.*/
	KeInitializeEvent(&ProcstructUpdateEvent, SynchronizationEvent, FALSE);
	KeInitializeSpinLock(&g_LockProcessLisk);
	
	Status=IoCreateDevice(
		DriverObject,
		0,
		&cdo_name,
		FILE_DEVICE_UNKNOWN,
		FILE_DEVICE_SECURE_OPEN,
		FALSE,
		&g_cdo);

	if (!NT_SUCCESS(Status))
	{
		DbgPrint("Create Device Fail! %x\n\rName=%s", Status, cdo_name);
	}
	else
	{
		DbgPrint("Create Device Success %x",g_cdo);
	}

	Status=IoCreateSymbolicLink(&syb_name, &cdo_name);
	if (!NT_SUCCESS(Status))
	{
		//ɾ��������ж����ִ��
		DbgPrint("Create Symbolic Fail");
	}
	else
	{
		DbgPrint("Create Symbolic Success %ws", syb_name.Buffer);
	}

	for (int i = 0; i < IRP_MJ_MAXIMUM_FUNCTION; i++)
	{
		DriverObject->MajorFunction[i] = DispatchGeneral;
	}
	DriverObject->MajorFunction[IRP_MJ_POWER] = c2pPower;
	DriverObject->MajorFunction[IRP_MJ_PNP] = c2pPnp;
	DriverObject->MajorFunction[IRP_MJ_CREATE] = DrvCreateAndClose;
	DriverObject->MajorFunction[IRP_MJ_CLOSE]=DrvCreateAndClose;
	DriverObject->MajorFunction[IRP_MJ_READ] = c2pRead;
	DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = DrvControlIoDevice;
	DriverObject->DriverUnload = DriverUnload;

#if 0
	_asm int 3
#endif
#pragma warning (disable:4055)
	
	Status = PsSetCreateProcessNotifyRoutineEx(ProcessNotifyEvent, TRUE); //���Ƴ�һ�£����ش���Ҳû��ϵ
	Status = PsSetCreateProcessNotifyRoutineEx(ProcessNotifyEvent, FALSE);	//RemoveΪFALSEʱ������֪ͨ
	if (!NT_SUCCESS(Status))
	{
		DbgPrint("CreateNotifyRoutine fail Status=%x", Status);
	}
	//��ʼ��ȫ�ֱ���
	InitDosPath();


	//����ȫ�ֽ�������ͷ,Idleȫ�ֱ���ΪPsIdleProcess.�������ڴ�������
	FindPsActiveProcessHead(&PsActiveProcessHead);

	//�������ļ����Բ���
	//dwProcLinkOffer = 0xB8;
	//2020.11.19���ļ�����
	InitProcOffset();
	
	//2020.�������ʼ���������� ��ʱ֧��win7
	//2020.11.19 ���ļ������κΰ汾
	InitProcessList();


	/*
	PLIST_ENTRY TempAddress;
	TempAddress = PsActiveProcessHead->Flink;
	TempAddress = (PLIST_ENTRY)((PUCHAR)TempAddress->Flink + 0x1A4);
	//EndListӦ��ΪSystemp��MmProcessLinks(��Ծ����)�����ڵ�
	PLIST_ENTRY EndList=TempAddress;
	do
	{
		PEPROCESS TempProcess;
		//EPROCESS+0X25C   MmProcessLinksΪ��Ծ���̵�����
		TempProcess = (PEPROCESS)((PUCHAR)TempAddress - 0x25C);
		InitFullProcInfo(TempProcess,TRUE);
		TempAddress = TempAddress->Flink;
		ActiveProcessLinksNumber++;
	} while (EndList != TempAddress);
	*/
	PsCreateSystemThread(&hGetCpuRateThread, 
		THREAD_ALL_ACCESS, 
		NULL, NtCurrentProcess(), NULL, 
		(PKSTART_ROUTINE)GetCpuRateThread,
		NULL);

	UNICODE_STRING string;
	RtlInitUnicodeString(&string, L"NtQuerySystemInformation");
	NtQuerySystemInformation =(pfnNtQuerySystemInformation) MmGetSystemRoutineAddress(&string);

	RtlInitUnicodeString(&string, L"ZwQueryObject");
	kZwQueryObject = (pfnZwQueryObject)MmGetSystemRoutineAddress(&string);
	RtlInitUnicodeString(&string, L"ZwDuplicateObject");
	kZwDuplicateObject = (pfnZwDuplicateObject)MmGetSystemRoutineAddress(&string);
	RtlInitUnicodeString(&string, L"RtlNtStatusToDosError");
	kRtlNtStatusToDosError = (pfnRtlNtStatusToDosError)MmGetSystemRoutineAddress(&string);
	
	DbgPrint("PsActiveProcessHead = %x. ActiveProcessLinks = %d \r\n",
		PsActiveProcessHead, ActiveProcessLinksNumber);
	return 0;
}