#pragma once
#include<ntddk.h>
#include"typedef.h"

extern SINGLE_LIST_ENTRY	g_ProcessSingleListPid;
extern SINGLE_LIST_ENTRY	g_ProcessSingleHead;
extern KSPIN_LOCK			g_LockProcessLisk;
extern ULONG				ActiveProcessLinksNumber;
KIRQL						OldIrql;
static BOOLEAN				BigPid = FALSE;

void ProcPidSort();
void BinaryQuickSort(ULONG* Array, ULONG Head, ULONG Tail);
