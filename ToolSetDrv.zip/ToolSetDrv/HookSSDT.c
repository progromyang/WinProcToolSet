#include"HookSSDT.h"
extern BOOLEAN				bHookWMware;
pfcNtQuerySystemInformation SystemNtQuerySystemInformation;
pfcZwCreateFile				SystemNtCreateFile;
pfcZwOpenFile				SystemNtOpenFile;


PWCHAR WMwareTool[] = {
	L"vmtoolsd\0",
	L"VGAuthService\0",
	L"vmacthlp\0" };



NTSTATUS MyNtQuerySystemInformation(
	_In_       SYSTEM_INFORMATION_CLASS SystemInformationClass,
	_Inout_    PVOID SystemInformation,
	_In_       ULONG SystemInformationLength,
	_Out_opt_  PULONG ReturnLength
	);

NTSTATUS MyNtCreateFile(
	_Out_     PHANDLE FileHandle,
	_In_      ACCESS_MASK DesiredAccess,
	_In_      POBJECT_ATTRIBUTES ObjectAttributes,
	_Out_     PIO_STATUS_BLOCK IoStatusBlock,
	_In_opt_  PLARGE_INTEGER AllocationSize,
	_In_      ULONG FileAttributes,
	_In_      ULONG ShareAccess,
	_In_      ULONG CreateDisposition,
	_In_      ULONG CreateOptions,
	_In_opt_  PVOID EaBuffer,
	_In_      ULONG EaLength
	);


NTSTATUS MyNtOpenFile(
	_Out_  PHANDLE FileHandle,
	_In_   ACCESS_MASK DesiredAccess,
	_In_   POBJECT_ATTRIBUTES ObjectAttributes,
	_Out_  PIO_STATUS_BLOCK IoStatusBlock,
	_In_   ULONG ShareAccess,
	_In_   ULONG OpenOptions
	);


//Hook ���VMware���йغ���
void CheckVMware()
{
	HideWMware();

	SystemNtCreateFile = (pfcZwCreateFile)KeServiceDescriptorTable->ntoskrnl.ServiceTableBase[0x42];
	off_protect_page();
	KeServiceDescriptorTable->ntoskrnl.ServiceTableBase[0x42] = (ULONG)MyNtCreateFile;
	on_protect_page();


	SystemNtOpenFile = (pfcZwOpenFile)KeServiceDescriptorTable->ntoskrnl.ServiceTableBase[0xB3];
	off_protect_page();
	KeServiceDescriptorTable->ntoskrnl.ServiceTableBase[0xB3] = (ULONG)MyNtOpenFile;
	on_protect_page();


	SystemNtQuerySystemInformation = (pfcNtQuerySystemInformation)KeServiceDescriptorTable->ntoskrnl.ServiceTableBase[0x105];
	off_protect_page();
	KeServiceDescriptorTable->ntoskrnl.ServiceTableBase[0x105] = (ULONG)MyNtQuerySystemInformation;
	on_protect_page();

	bHookWMware = TRUE;
}


void UnCheckVMware()
{
	off_protect_page();
	KeServiceDescriptorTable->ntoskrnl.ServiceTableBase[0x42] = (ULONG)SystemNtCreateFile;
	on_protect_page();

	off_protect_page();
	KeServiceDescriptorTable->ntoskrnl.ServiceTableBase[0xB3] = (ULONG)SystemNtOpenFile;
	on_protect_page();


	off_protect_page();
	KeServiceDescriptorTable->ntoskrnl.ServiceTableBase[0x105] = (ULONG)SystemNtQuerySystemInformation;
	on_protect_page();
	bHookWMware = FALSE;
	TotolRecovery();
}
NTSTATUS MyNtQuerySystemInformation(
	_In_       SYSTEM_INFORMATION_CLASS SystemInformationClass,
	_Inout_    PVOID SystemInformation,
	_In_       ULONG SystemInformationLength,
	_Out_opt_  PULONG ReturnLength
	)
{
	NTSTATUS Status;
	PSYSTEM_FIRMWARE_TABLE_INFORMATION firmware;
	firmware = SystemInformation;
	if (SystemInformationClass == SystemFirmwareTableInformation &&
		firmware->Action == 1)
	{
		CHAR Buffer1[] = { "VMware\0" };

		Status=SystemNtQuerySystemInformation(
			SystemInformationClass,
			SystemInformation,
			SystemInformationLength,
			ReturnLength
			);

		PCHAR WMbuffer;
		WMbuffer = (PCHAR)SystemInformation + sizeof(SYSTEM_FIRMWARE_TABLE_INFORMATION);

		for (ULONG i = 0; i < *ReturnLength; i++)
		{
			if (!_strnicmp(Buffer1, WMbuffer, 5))
			{
				strncpy(WMbuffer, "Intel-", 6);
			}

			if (!_strnicmp(Buffer1, "virtual\0", 7))
			{
				strncpy(WMbuffer, "Intel86", 7);
			}
			WMbuffer++;
		}
		return Status;
	}

	Status = SystemNtQuerySystemInformation(
		SystemInformationClass,
		SystemInformation,
		SystemInformationLength,
		ReturnLength
		);

	return Status;
}


NTSTATUS MyNtCreateFile(
	_Out_     PHANDLE FileHandle,
	_In_      ACCESS_MASK DesiredAccess,
	_In_      POBJECT_ATTRIBUTES ObjectAttributes,
	_Out_     PIO_STATUS_BLOCK IoStatusBlock,
	_In_opt_  PLARGE_INTEGER AllocationSize,
	_In_      ULONG FileAttributes,
	_In_      ULONG ShareAccess,
	_In_      ULONG CreateDisposition,
	_In_      ULONG CreateOptions,
	_In_opt_  PVOID EaBuffer,
	_In_      ULONG EaLength
	)
{
	PWCH	Buffer;
	PWCH	ProbeBuffer;
	WCHAR	WMbuffer[] = { L"wmware-host\0" };
	WCHAR	WMware[] = { L"WMware\0" };

	while (ObjectAttributes->ObjectName&&ObjectAttributes->ObjectName->Length>0)
	{
		ProbeBuffer = ExAllocatePoolWithTag(NonPagedPool, ObjectAttributes->ObjectName->MaximumLength,'WMVM');
		memset(ProbeBuffer, 0, ObjectAttributes->ObjectName->MaximumLength);
		RtlCopyMemory(ProbeBuffer, ObjectAttributes->ObjectName->Buffer, ObjectAttributes->ObjectName->MaximumLength);

			if (wcsstr(ProbeBuffer, WMbuffer))
			{
				Buffer = wcsstr(ProbeBuffer, WMbuffer);
				Buffer += 10;
				if (wcsstr(Buffer, WMware))
				{
					ExFreePool(ProbeBuffer);
					return 0xC0000034;
				}
				break;
			}

			if (wcsstr(ProbeBuffer, WMware))
			{
				ExFreePool(ProbeBuffer);
				return 0xC0000034;
			}
			ExFreePool(ProbeBuffer);
			break;
	}
	return SystemNtCreateFile(FileHandle,
		DesiredAccess,
		ObjectAttributes,
		IoStatusBlock,
		AllocationSize,
		FileAttributes,
		ShareAccess,
		CreateDisposition,
		CreateOptions,
		EaBuffer,
		EaLength);
}

NTSTATUS MyNtOpenFile(
	_Out_  PHANDLE FileHandle,
	_In_   ACCESS_MASK DesiredAccess,
	_In_   POBJECT_ATTRIBUTES ObjectAttributes,
	_Out_  PIO_STATUS_BLOCK IoStatusBlock,
	_In_   ULONG ShareAccess,
	_In_   ULONG OpenOptions
	)
{
	PWCH	Buffer,ProbeBuffer;
	WCHAR	WMbuffer[] = { L"wmware-host\0" };
	WCHAR	WMware[] = { L"WMware\0" };

	while (ObjectAttributes->ObjectName&&ObjectAttributes->ObjectName->Length>0)
	{
		ProbeBuffer = ExAllocatePoolWithTag(NonPagedPool, ObjectAttributes->ObjectName->MaximumLength, 'WMVM');
		memset(ProbeBuffer, 0, ObjectAttributes->ObjectName->MaximumLength);
		RtlCopyMemory(ProbeBuffer, ObjectAttributes->ObjectName->Buffer, ObjectAttributes->ObjectName->MaximumLength);

		if (wcsstr(ProbeBuffer, WMbuffer))
		{
			Buffer = wcsstr(ProbeBuffer, WMbuffer);
			Buffer += 10;
			if (wcsstr(Buffer, WMware))
			{
				ExFreePool(ProbeBuffer);
				return 0xC0000034;
			}
			break;
		}

		if (wcsstr(ProbeBuffer, WMware))
		{
			ExFreePool(ProbeBuffer);
			return 0xC0000034;
		}
		ExFreePool(ProbeBuffer);
		break;
	}
	
	return SystemNtOpenFile(FileHandle,
		DesiredAccess,
		ObjectAttributes,
		IoStatusBlock,
		ShareAccess,
		OpenOptions);
}



void HideWMware()
{
	NTSTATUS status;
	PDefProcessStruct tempProc;
	//һ������4������
	for (int i = 0; i < 3; i++)
	{
		tempProc = (PDefProcessStruct)g_ProcessSingleHead.Next;
		while (tempProc)
		{
			if (wcsstr(tempProc->Path, WMwareTool[i]))
			{
				status=HideProc(tempProc->Pid);
				if (!NT_SUCCESS(status))
				{
					KdPrint(("Process Hide fail Pid=%d", tempProc->Pid));
					break;
				}
			}
			tempProc = tempProc->NextList;
		}
	}
}