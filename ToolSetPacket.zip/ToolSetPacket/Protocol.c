#include"NdisPacket.h"

ULONG	NdisDotSysVersion = 0;
VOID PtBindAdapter(
	OUT PNDIS_STATUS	Status,
	IN NDIS_HANDLE		BindContext,
	IN PNDIS_STRING		DeviceName,
	IN PVOID			SystemSpecific1,
	IN PVOID			SystemSpecific2)
{
	NDIS_HANDLE		ConfigHandle = NULL;
	PNDIS_CONFIGURATION_PARAMETER Param;
	NDIS_STRING		DeviceStr = NDIS_STRING_CONST("UpperBindings");
	NDIS_STRING		NdisVersionStr = NDIS_STRING_CONST("NdisVertion");
	PADAPT			pAdapt = NULL;
	NDIS_STATUS		Sts;
	UINT			MediumIndex;
	ULONG			TotalSize;
	BOOLEAN			NoCleanUpNeeded = FALSE;
	
	UNREFERENCED_PARAMETER(BindContext);
	UNREFERENCED_PARAMETER(SystemSpecific2);
	KdPrint(("===> Protocol BindAdater\n"));
	__asm int 3
	do
	{
		// �������ò����Ի�ȡ���ض�����

		NdisOpenProtocolConfiguration(
			Status,
			&ConfigHandle,
			SystemSpecific1);

		if (*Status != NDIS_STATUS_SUCCESS)
			break;

		if (NdisDotSysVersion == 0)
		{
			NdisReadConfiguration(
				Status,
				&Param,
				ConfigHandle,
				&NdisVersionStr,
				NdisParameterInteger
				);
			if (*Status != NDIS_STATUS_SUCCESS)
				break;

			NdisDotSysVersion = Param->ParameterData.IntegerData;
		}

		NdisReadConfiguration(Status,
			&Param,
			ConfigHandle,
			&DeviceStr,
			NdisParameterString);

		if (*Status != NDIS_STATUS_SUCCESS)
			break;

		//�����������ڴ� �Լ������������ڴ�MaxiumumLength
		TotalSize = sizeof(ADAPT) + Param->ParameterData.StringData.MaximumLength;
		NdisAllocateMemoryWithTag(&pAdapt, TotalSize, TAG);

		if (pAdapt == NULL)
		{
			*Status = NDIS_STATUS_RESOURCES;
			break;
		}

		//Initialize the adapter struct ,

		NdisZeroMemory(pAdapt, TotalSize);
		pAdapt->DeviceName.MaximumLength = Param->ParameterData.StringData.MaximumLength;
		pAdapt->DeviceName.Length = Param->ParameterData.StringData.Length;
		pAdapt->DeviceName.Buffer = (PWCHAR)((ULONG_PTR)pAdapt + sizeof(ADAPT));

		NdisMoveMemory(pAdapt->DeviceName.Buffer,
			Param->ParameterData.StringData.Buffer,
			Param->ParameterData.StringData.MaximumLength);

		NdisInitializeEvent(&pAdapt->Event);
		NdisAllocateSpinLock(&pAdapt->Lock);

		// Allocate a packet pool for sends. We need this to pass sends down.
		// We cannot use the same packet descriptor that came down to our send
		// handler (see also NDIS 5.1 packet stacking).

		NdisAllocatePacketPoolEx(
			Status,
			&pAdapt->SendPacketPoolHandle,
			MIN_PACKET_POOL_SIZE,
			MAX_PACKET_POOL_SIZE - MIN_PACKET_POOL_SIZE,
			sizeof(SEND_RSVD));

		if (*Status != NDIS_STATUS_SUCCESS)
			break;

		//������հ���
		NdisAllocatePacketPoolEx(Status,
			&pAdapt->RecvPacketPoolHandle,
			MIN_PACKET_POOL_SIZE,
			MAX_PACKET_POOL_SIZE - MIN_PACKET_POOL_SIZE,
			PROTOCOL_RESERVED_SIZE_IN_PACKET);



		//���ڴ����������������ɳ�ʼ��
		//����˵���²�NIC
		NdisOpenAdapter(
			Status,
			&Sts,
			&pAdapt->BindingHandle,
			&MediumIndex,
			MediumArray,
			sizeof(MediumArray) / sizeof(NDIS_MEDIUM),
			ProtHandle,
			pAdapt,
			DeviceName,
			0, NULL);

		if (*Status == NDIS_STATUS_PENDING)
		{
			NdisWaitEvent(&pAdapt->Event, 0);
			*Status = pAdapt->Status;
		}
		if (*Status != NDIS_STATUS_SUCCESS)
			break;

		PtReferenceAdapt(pAdapt);

		//���������protocol�ӿ�������miniport��MPInitialize
		*Status = NdisIMInitializeDeviceInstanceEx(
			&DriverHandle,
			&pAdapt->DeviceName,
			pAdapt);

		if (*Status != NDIS_STATUS_SUCCESS)
		{
			if (pAdapt->MiniportIsHalted == TRUE)
				NoCleanUpNeeded = TRUE;
			KdPrint(("BindAdapter: Adapt %p IMInitializeDeivceInstance Error %x\n",pAdapt,*Status));

			//�����ڲ��ж��Ƿ��ͷ���Դ�����ΪTRUE ���Ѿ��ͷ���������Դ
			if (PtDereferenceAdapt(pAdapt))
				pAdapt = NULL;

			break;
		}
		PtDereferenceAdapt(pAdapt);
	} while (FALSE);

	// Close the configuration handle now - see comments above with
	// the call to NdisIMInitializeDeviceInstanceEx.
	if (ConfigHandle != NULL)
		NdisCloseConfiguration(ConfigHandle);

	if ((*Status != NDIS_STATUS_SUCCESS) && (NoCleanUpNeeded == FALSE))
	{
		if (pAdapt != NULL)
		{
			//�ر�֮ǰ�󶨵�MiniPortHandle
			if (pAdapt->BindingHandle != NULL)
			{
				NDIS_STATUS LocalStatus;

				//Close the binding we opened above
				NdisResetEvent(&pAdapt->Event);
				NdisCloseAdapter(&LocalStatus, pAdapt->BindingHandle);
				if (LocalStatus == NDIS_STATUS_PENDING)
				{
					NdisWaitEvent(&pAdapt->Event, 0);
					LocalStatus = pAdapt->Status;
				}
				if (PtDereferenceAdapt(pAdapt))
					pAdapt = NULL;
			}
		}
	}
	KdPrint(("<== Protocol BindAdapter: pAdapt %p,Status %x\r\n", pAdapt, *Status));
}


VOID PtReferenceAdapt(IN PADAPT pAdapt)
{
	NdisAcquireSpinLock(&pAdapt->Lock);
	ASSERT(pAdapt->RefCount >= 0);
	pAdapt->RefCount++;
	NdisReleaseSpinLock(&pAdapt->Lock);
}

BOOLEAN PtDereferenceAdapt(IN PADAPT pAdapt)
{
	NdisAcquireSpinLock(&pAdapt->Lock);
	ASSERT(pAdapt->RefCount > 0);
	pAdapt->RefCount--;

	if (pAdapt->RefCount == 0)
	{
		NdisReleaseSpinLock(&pAdapt->Lock);

		MPFreeAllPacketPools(pAdapt);
		NdisFreeSpinLock(&pAdapt->Lock);
		NdisFreeMemory(pAdapt, 0, 0);
		return TRUE;
	}
	else
		NdisReleaseSpinLock(&pAdapt->Lock);

	return FALSE;
}

//��virtrul miniport �������ݰ���NICʵ��ʱ �첽�ķ�ʽ�ش���ɺ������м��Э��
VOID
PtSendComplete(
IN  NDIS_HANDLE            ProtocolBindingContext,
IN  PNDIS_PACKET           Packet,
IN  NDIS_STATUS            Status
)
{
	PADAPT pAdapt = (PADAPT)ProtocolBindingContext;
	PNDIS_PACKET	Pkt;
	NDIS_HANDLE		PoolHandle;

#ifdef NDIS51
	//Packet Stacking:

	PoolHandle = NdisGetPoolFromPacket(Packet);

	//�жϰ��ǡ������á����ǡ������롱
	if (PoolHandle != pAdapt->SendPacketPoolHandle)
	{
		//������˵�����ǡ������á� ֱ�ӰѰ�����ȥ
		NdisMSendComplete(
			pAdapt->MiniportHandle,
			Packet,
			Status);
	}
	else
#endif
	{
		PSEND_RSVD SendRsvd;
		SendRsvd = (PSEND_RSVD)(Packet->ProtocolReserved);
		Pkt = SendRsvd->OriginalPkt;

#ifndef WIN9X
		//���ϵ�΢�Ͷ˿��������򷵻ص����ݰ��е�ÿ�����ݰ���Ϣ
		//���Ƶ�Ҫ���ظ��ϼ���������������ݰ��С�
		NdisIMCopySendCompletePerPacketInfo(Pkt, Packet);
#endif
		NdisDprFreePacket(Packet);
		NdisMSendComplete(pAdapt->MiniportHandle, Pkt, Status);
	}
	ADAPT_DECR_PENDING_SENDS(pAdapt);
}

NDIS_STATUS
PtReceive(
IN NDIS_HANDLE	ProtocolBindingContext,
IN NDIS_HANDLE	MacReceiveContext,	//�ɵײ�NIC����,��������Packet����
IN PVOID		HeaderBuffer,
IN UINT			HeaderBufferSize,
IN PVOID		LookAheadBuffer,
IN UINT			LookAheadBufferSize,
IN UINT			PacketSize
)
{
	PADAPT			pAdapt = (PADAPT)ProtocolBindingContext;
	PNDIS_PACKET	MyPacket, Packet = NULL;
	NDIS_STATUS		Status = NDIS_STATUS_SUCCESS;
	ULONG			Proc = KeGetCurrentProcessorNumber();		//��ǰ�������ı��

	if ((!pAdapt->MiniportHandle) || (pAdapt->MPDeviceState > NdisDeviceStateD0))
		Status = NDIS_STATUS_FAILURE;
	else do
	{
		// Get packet. if any ,indicated up by the miniport below.
		Packet = NdisGetReceivedPacket(pAdapt->BindingHandle, MacReceiveContext);

		//�������ֵΪ��˵���²㻹û��׼��һ�������İ���
		//�����������Ҫ�����İ������NdisTransData,�粻��Ҫ�����NdisMxxxIndicateReceive 

		if (Packet != NULL)
		{
			//���ﴦ���������ݰ�
			FILTER_STATUS fStatus = AnalysisPacket(Packet, TRUE);

			if (fStatus == STATUS_DROP)
				Status = NDIS_STATUS_FAILURE;
			else if (fStatus == STATUS_REDIRECT)
			{
				//ת�� todo:
			}

			//the miniport below did indicate up a packet.
			//use information from that packet to construct a new packet to indicate up

			//Get a packet off the pool and indicate that up
			//���������NdisAllocatePacket�Կ죬������������Dispatch�жϼ���
			NdisDprAllocatePacket(&Status, &MyPacket, pAdapt->RecvPacketPoolHandle);

			if (Status == NDIS_STATUS_SUCCESS)
			{
				NDIS_PACKET_FIRST_NDIS_BUFFER(MyPacket) = NDIS_PACKET_FIRST_NDIS_BUFFER(Packet);
				NDIS_PACKET_LAST_NDIS_BUFFER(MyPacket) = NDIS_PACKET_LAST_NDIS_BUFFER(Packet);

				//Copy Packet flags
				NdisGetPacketFlags(MyPacket) = NdisGetPacketFlags(Packet);

				//��������Э�����������ݰ��е����ݣ���ǿ�����Ǹ���һ��������
				//������Ϊ�����ڽ��մ������򣨲���ReceivePacket���У����ܴ����ﷵ��ref������
				//NDIS_STATUS_RESOURCE��־����������Դ���š��������������촦�������ݰ�
				//���ǵ�Ŀ����ͬ���������ݰ�����NdisMIndicateReceivePacket����ʱ�������ͷ����ݰ�
				//��������ô˱�־����Ҫ�첽�������ȽϷ�����Ҫ��MPReturnPacket��ȥ��
				NDIS_SET_PACKET_STATUS(MyPacket, NDIS_STATUS_RESOURCES);

				//ͨ������NDIS_STATUS_RESOURCE��
				//���ǻ�֪����ֻҪ��NdisMIndicateReceivePacket�ĵ��÷��أ��Ϳ��Ի��մ����ݰ���

				if (pAdapt->MiniportHandle != NULL)
					NdisMIndicateReceivePacket(pAdapt->BindingHandle, &MyPacket, 1);

				NdisDprFreePacket(MyPacket);
				break;
			}
		}
		else
		{
			// ���������΢�Ͷ˿�ʹ�þ�ʽ�����Ƿ��飩����ָʾ��ʧ��
			//���ﴦ������������
		}

		//������������΢�Ͷ˿�û��ָʾ���ݰ���
		//���������޷��������ݰ�����ʧ��

		//�����־����˵����������NdisMXxxIndicateReceiveϵ�к���,��ɺ��������ж�
		pAdapt->ReceivedIndicationFlags[Proc] = TRUE;
		if (pAdapt->MiniportHandle == NULL)
			break;

		switch (pAdapt->Medium)
		{
		case NdisMedium802_3:
		case NdisMediumWan:
			//�������ϲ�������PtRecevie�����ĵ���
			NdisMEthIndicateReceive(
				pAdapt->MiniportHandle,
				MacReceiveContext,
				HeaderBuffer,
				HeaderBufferSize,
				LookAheadBuffer,
				LookAheadBufferSize,
				PacketSize);;
			break;

		case NdisMedium802_5:
			NdisMTrIndicateReceive(
				pAdapt->MiniportHandle,
				MacReceiveContext,
				HeaderBuffer,
				HeaderBufferSize,
				LookAheadBuffer,
				LookAheadBufferSize,
				PacketSize);
			break;

#if FDDI	//fider distributed data interface
			//Windows Vista,Not Supported
		case NdisMediumFddi:
			NdisMFddiIndicateReceive(pAdapt->MiniportHandle,
				MacReceiveContext,
				HeaderBuffer,
				HeaderBufferSize,
				LookAheadBuffer,
				LookAheadBufferSize,
				PacketSize);
			break;

#endif
		default:
			ASSERT(FALSE);
			break;
		}
	} while (FALSE);
	return Status;
}


INT PtReceivePacket(IN NDIS_HANDLE  ProtocolBindingContext, IN PNDIS_PACKET Packet)
{
	PADAPT pAdapt = (PADAPT)ProtocolBindingContext;
	NDIS_STATUS		Status;
	PNDIS_PACKET	MyPacket;
	BOOLEAN			Remaining;
	FILTER_STATUS	fStatus;

	if ((!pAdapt->MiniportHandle) || (pAdapt->MPDeviceState > NdisDeviceStateD0))
		return 0;

	fStatus = AnalysisPacket(Packet, TRUE);
	if (fStatus == STATUS_DROP)
		return 0;
	else if (fStatus == STATUS_REDIRECT)
	{
		//ת��TODO
	}

#ifdef NDIS51
	//Check if we can reuse the same packet for indicating up se also:PtReceive()
	NdisIMGetCurrentPacketStack(Packet, &Remaining);
	if (Remaining)
	{
		//we can reuse packet ,indicate it up and be done with it
		Status = NDIS_GET_PACKET_STATUS(Packet);
		if (pAdapt->MiniportHandle)
			NdisMIndicateReceivePacket(pAdapt->MiniportHandle, &Packet, 1);

		//����ʹ�ü��������Ϊ0���ʾ���ײ��Ѿ������Լ�������
		//�������<=1,��Ϊһ����������ʾ�ϲ���Ȼռ�ô˰��� 
		//����NdisReturnPackets,������1��MpReturnPacket �ᱻ����
		return ((Status != NDIS_STATUS_RESOURCES) ? 1 : 0);
	}
#endif

	//Get a Packet off the pool and indicate that up
	NdisDprAllocatePacket(
		&Status,
		&MyPacket,
		pAdapt->RecvPacketPoolHandle);

	if (Status == NDIS_STATUS_SUCCESS)
	{
		PRECV_RSVD	RecvRsvd;
		RecvRsvd = (PRECV_RSVD)(MyPacket->MiniportReserved);
		RecvRsvd->OriginalPkt = Packet;

		NDIS_PACKET_FIRST_NDIS_BUFFER(MyPacket) = NDIS_PACKET_FIRST_NDIS_BUFFER(MyPacket);
		NDIS_PACKET_LAST_NDIS_BUFFER(MyPacket) = NDIS_PACKET_LAST_NDIS_BUFFER(MyPacket);

		NDIS_SET_ORIGINAL_PACKET(MyPacket, NDIS_GET_ORIGINAL_PACKET(Packet));

		//Set packet flags
		NdisGetPacketFlags(MyPacket) = NdisGetPacketFlags(Packet);

		Status = NDIS_GET_PACKET_STATUS(Packet);
		NDIS_SET_PACKET_STATUS(MyPacket, Status);
		NDIS_SET_PACKET_HEADER_SIZE(MyPacket, NDIS_GET_PACKET_HEADER_SIZE(Packet));

		if (pAdapt->MiniportHandle != NULL)
			NdisMIndicateReceivePacket(pAdapt->MiniportHandle, &MyPacket, 1);

		if (Status == NDIS_STATUS_RESOURCES)
			NdisDprFreePacket(MyPacket);

		return((Status != NDIS_STATUS_RESOURCES) ? 1 : 0);
	}
	else
	{
		return(0);
	}
}



//�ɵײ�֪ͨ�Ѿ������������ݰ�
VOID
PtReceiveComplete(
IN NDIS_HANDLE        ProtocolBindingContext
)
{
	PADAPT pAdapt = (PADAPT)ProtocolBindingContext;
	ULONG Proc = KeGetCurrentProcessorNumber();

	if ((pAdapt->MiniportHandle != NULL) &&
		(pAdapt->MPDeviceState == NdisDeviceStateD0) &&
		(pAdapt->ReceivedIndicationFlags[Proc]))
	{
		//ѡ�����ʱ�䱻���ã�֪ͨ�ϲ�����PtReceiveComplate
		switch (pAdapt->Medium)
		{
		case NdisMedium802_3:
		case NdisMediumWan:
			NdisMEthIndicateReceiveComplete(pAdapt->MiniportHandle); 
			break;
		case NdisMedium802_5:
			NdisMTrIndicateReceiveComplete(pAdapt->MiniportHandle);
			break;

#if FDDI
		case NdisMediumFddi:
			NdisMFddiIndicateReceiveComplete(pAdapt->MiniportHandle);
			break;
#endif

		default:
			ASSERT(FALSE);
			break;
		}
	}
	pAdapt->ReceivedIndicationFlags[Proc] = FALSE;
}


VOID
PtRequestComplete(
IN  NDIS_HANDLE            ProtocolBindingContext,
IN  PNDIS_REQUEST          NdisRequest,
IN  NDIS_STATUS            Status
)
{
	PADAPT		pAdapt = (PADAPT)ProtocolBindingContext;
	NDIS_OID	Oid = pAdapt->Request.DATA.SET_INFORMATION.Oid;

	//��Ϊout��������δ��ɵ�
	ASSERT(pAdapt->OutstandingRequests == TRUE);
	pAdapt->OutstandingRequests = FALSE;
	//Complete the set or Query,
	//And fill in the buffer for OID_PNP_CAPABILITIES if need be

	switch (NdisRequest->RequestType)
	{
	case NdisRequestQueryInformation:
		ASSERT(Oid != OID_PNP_QUERY_POWER);

		if ((Oid == OID_PNP_CAPABILITIES) && (Status == NDIS_STATUS_SUCCESS))
		{
			MPQueryPNPCapabilities(pAdapt, &Status);
		}
		*pAdapt->BytesReadOrWritten = NdisRequest->DATA.QUERY_INFORMATION.BytesWritten;
		*pAdapt->BytesNeeded = NdisRequest->DATA.QUERY_INFORMATION.BytesNeeded;

		if ((Oid == OID_GEN_MAC_OPTIONS) &&
			(Status == NDIS_STATUS_SUCCESS) &&
			(NdisDotSysVersion >= NDIS_SYS_VERSION_51))
		{
			//�ػ���־
			*(PULONG)NdisRequest->DATA.QUERY_INFORMATION.InformationBuffer &= 
				!NDIS_MAC_OPTION_NO_LOOPBACK;
		}
		NdisMQueryInformationComplete(pAdapt->MiniportHandle, Status);
		break;

	case NdisRequestSetInformation:
		ASSERT(Oid != OID_PNP_SET_POWER);
		*pAdapt->BytesReadOrWritten = NdisRequest->DATA.SET_INFORMATION.BytesRead;
		*pAdapt->BytesNeeded = NdisRequest->DATA.SET_INFORMATION.BytesNeeded;
		NdisMSetInformationComplete(pAdapt->MiniportHandle, Status);
		break;
	}
}

VOID PtUnloadProtocol(VOID)
{
	NDIS_STATUS Status;
	if (ProtHandle != NULL)
	{
		NdisDeregisterProtocol(&Status, ProtHandle);
		ProtHandle = NULL;
	}

	//ɾ��WDM �����豸
	if (g_NdisDeviceObject!=NULL)
	{
		IoDeleteDevice(g_NdisDeviceObject);
		g_NdisDeviceObject = NULL;
	}

	//֮ǰ����û�м������
	if (ControlDeviceObject != NULL)
	{
		IoDeleteDevice(ControlDeviceObject);
		ControlDeviceObject = NULL;
	}
	KdPrint(("PtUnloadProtocol: done!\r\n"));
}


//Э������
VOID PtUnbindAdapter(
	OUT PNDIS_STATUS	Status,
	IN NDIS_HANDLE		ProtocolBindingContext,
	IN NDIS_HANDLE		UnBindContext)
{
	PADAPT pAdapt = (PADAPT)ProtocolBindingContext;
	NDIS_STATUS LocalStatus;
	UNREFERENCED_PARAMETER(UnBindContext);
	KdPrint(("==> PtUnbindAdapt:Aadapt %p\r\n", pAdapt));

	// Set the flag that the miniport below is unbinding, so the request handlers will
	// fail any request comming later
	NdisAcquireSpinLock(&pAdapt->Lock);
	pAdapt->UnBindingInProcess = TRUE;
	if (pAdapt->QueuedRequest == TRUE)
	{
		pAdapt->QueuedRequest = FALSE;
		NdisReleaseSpinLock(&pAdapt->Lock);

		PtRequestComplete(pAdapt,
			&pAdapt->Request,
			NDIS_STATUS_FAILURE);
	}
	else
		NdisReleaseSpinLock(&pAdapt->Lock);

#ifndef WIN9X
	//Check if we had called ndisIMInitializeDeviceInstanceEx and
	//we are awaiting a call to MiniportInitialize
	if (pAdapt->MiniportInitPending == TRUE)
	{
		//Try to cancel the pengding IMinit Process
		LocalStatus = NdisIMCancelInitializeDeviceInstance(
			DriverHandle, &pAdapt->DeviceName);

		if (LocalStatus == NDIS_STATUS_SUCCESS)
		{
			pAdapt->MiniportInitPending = FALSE;
			ASSERT(pAdapt->MiniportHandle == NULL);
		}
		else
		{
			NdisWaitEvent(&pAdapt->MiniportInitEvet, 0);
			ASSERT(pAdapt->MiniportInitPending == FALSE);
		}

	}
#endif

	// Call NDIS to remove our device-instance. We do most of the work
	// inside the HaltHandler.
	//
	// The Handle will be NULL if our miniport Halt Handler has been called or
	// if the IM device was never initialized
	//
	if (pAdapt->MiniportHandle != NULL)
	{
		*Status = NdisIMDeInitializeDeviceInstance(pAdapt->MiniportHandle);
		if (*Status != NDIS_STATUS_SUCCESS)
			*Status = NDIS_STATUS_FAILURE;
	}
	else
	{
		// We need to do some work here. 
		// Close the binding below us 
		// and release the memory allocated.
		if (pAdapt->BindingHandle != NULL)
		{
			NdisResetEvent(&pAdapt->Event);
			NdisCloseAdapter(Status, pAdapt->BindingHandle);
			// Wait for it to complete

			if (*Status == NDIS_STATUS_PENDING)
			{
				NdisWaitEvent(&pAdapt->Event, 0);
				*Status = pAdapt->Status;
			}
		}
		else
		{
			// Both Our MiniportHandle and Binding Handle  should not be NULL.
			*Status = NDIS_STATUS_FAILURE;
			ASSERT(0);
		}
		MPFreeAllPacketPools(pAdapt);
		NdisFreeSpinLock(&pAdapt->Lock);
		NdisFreeMemory(pAdapt, 0, 0);
	}
	DbgPrint("<== PtUnbindAdapter: Adapt %p\n", pAdapt);
}


VOID
PtOpenAdapterComplete(
IN  NDIS_HANDLE             ProtocolBindingContext,
IN  NDIS_STATUS             Status,
IN  NDIS_STATUS             OpenErrorStatus
)
{
	PADAPT pAdapt = (PADAPT)ProtocolBindingContext;
	UNREFERENCED_PARAMETER(OpenErrorStatus);
	DbgPrint("==> PtOpenAdapterComplete: Adapt %p,Status %x\n", pAdapt, Status);
	pAdapt->Status = Status;
	NdisSetEvent(&pAdapt->Event);
}

VOID
PtCloseAdapterComplete(
IN    NDIS_HANDLE            ProtocolBindingContext,
IN    NDIS_STATUS            Status
)
{
	PADAPT pAdapt = (PADAPT)ProtocolBindingContext;
	DbgPrint("CloseAdapterComplete: Adapt %p, Status %x\n", pAdapt, Status);
	pAdapt->Status = Status;
	NdisSetEvent(&pAdapt->Event);
}


VOID
PtResetComplete(
IN  NDIS_HANDLE            ProtocolBindingContext,
IN  NDIS_STATUS            Status
)
{

	UNREFERENCED_PARAMETER(ProtocolBindingContext);
	UNREFERENCED_PARAMETER(Status);
	//
	// We never issue a reset, so we should not be here.
	//
	ASSERT(0);
}


VOID
PtStatusComplete(
IN NDIS_HANDLE            ProtocolBindingContext
)
{
	PADAPT pAdapt = (PADAPT)ProtocolBindingContext;

	// Pass up this indication only if the upper edge miniport is initialized
	// and powered on. Also ignore indications that might be sent by the lower
	// miniport when it isn't at D0.
	if ((pAdapt->MiniportHandle != NULL) &&
		(pAdapt->MPDeviceState == NdisDeviceStateD0) &&
		(pAdapt->PTDeviceState == NdisDeviceStateD0))
	{
		NdisMIndicateStatusComplete(pAdapt->MiniportHandle);
	}
}


VOID
PtStatus(
IN  NDIS_HANDLE         ProtocolBindingContext,
IN  NDIS_STATUS         GeneralStatus,
IN  PVOID               StatusBuffer,
IN  UINT                StatusBufferSize
)
{
	PADAPT pAdapt = (PADAPT)ProtocolBindingContext;

	if ((pAdapt->MiniportHandle != NULL) &&
		(pAdapt->MPDeviceState == NdisDeviceStateD0) &&
		(pAdapt->PTDeviceState == NdisDeviceStateD0))
	{
		if ((GeneralStatus == NDIS_STATUS_MEDIA_CONNECT) ||
			(GeneralStatus == NDIS_STATUS_MEDIA_DISCONNECT))
		{
			pAdapt->LastIndicatedStatus = GeneralStatus;
		}
		NdisMIndicateStatus(
			pAdapt->MiniportHandle,
			GeneralStatus,
			StatusBuffer,
			StatusBufferSize);
	}
	else
	{
		//Save the last indicated media status
		if ((pAdapt->MiniportHandle != NULL) &&
			((GeneralStatus == NDIS_STATUS_MEDIA_CONNECT) ||
			(GeneralStatus == NDIS_STATUS_MEDIA_DISCONNECT)))
		{
			pAdapt->LastIndicatedStatus = GeneralStatus;
		}
	}

}

NDIS_STATUS 
PtPNPHandler(
IN NDIS_HANDLE		ProtocolBindingContext,
IN PNET_PNP_EVENT	pNetPnPEvent)
{
	PADAPT pAdapt = (PADAPT)ProtocolBindingContext;
	NDIS_STATUS Status = NDIS_STATUS_SUCCESS;

	DbgPrint("PtPnPHandler: Adapt %p, Event %d\n", pAdapt, pNetPnPEvent->NetEvent);

	switch (pNetPnPEvent->NetEvent)
	{
	case NetEventSetPower:
		Status = PtPnPNetEventSetPower(pAdapt, pNetPnPEvent);
		break;
	case NetEventReconfigure:
		Status = PtPnPNetEventReconfigure(pAdapt, pNetPnPEvent);
		break;

	default:
#ifdef NDIS51
		if (pAdapt&&pAdapt->MiniportHandle)
		{
			Status = NdisIMNotifyPnPEvent(pAdapt->MiniportHandle, pNetPnPEvent);
		}
#else
		Status = NDIS_STATUS_SUCCESS;
#endif
		break;
	}
	return Status;
}

NDIS_STATUS
PtPnPNetEventReconfigure(
IN PADAPT            pAdapt,
IN PNET_PNP_EVENT    pNetPnPEvent
)
{
	NDIS_STATUS	ReconfigStatus = NDIS_STATUS_SUCCESS;
	NDIS_STATUS	ReturnStatus = NDIS_STATUS_SUCCESS;
	do
	{
		if (pAdapt == NULL)
		{
			NdisReEnumerateProtocolBindings(ProtHandle);
			break;
		}

#ifdef NDIS51
		// Pass on this notification to protocol above before doing anything with it

		if (pAdapt->MiniportHandle)
			ReturnStatus = NdisIMNotifyPnPEvent(pAdapt->MiniportHandle, pNetPnPEvent);
#endif

		ReconfigStatus = NDIS_STATUS_SUCCESS;
	} while (FALSE);
#ifdef NDIS51
	ReconfigStatus = ReturnStatus;
#endif
	return ReconfigStatus;
}

NDIS_STATUS PtPnPNetEventSetPower(
	IN PADAPT pAdapt,
	IN PNET_PNP_EVENT	pNetPnPEvent)
{
	PNDIS_DEVICE_POWER_STATE	pDeviceStatus = (PNDIS_DEVICE_POWER_STATE)(pNetPnPEvent->Buffer);
	NDIS_DEVICE_POWER_STATE		PrevDeviceState = pAdapt->PTDeviceState;
	NDIS_STATUS	Status=STATUS_SUCCESS;
	NDIS_STATUS ReturnStatus=STATUS_SUCCESS;
#ifdef NDIS51
	ULONG PengdingIoCount = 0;
#endif
	//�ҾͲ��Ǻ����ײ��ö����ʲô��
	UNREFERENCED_PARAMETER(PengdingIoCount);

	////Set the internel device state,this blocks all new sends or receives
	NdisAcquireSpinLock(&pAdapt->Lock);
	pAdapt->PTDeviceState = *pDeviceStatus;

	//Check if the miniport below is going to a low power state
	if (pAdapt->PTDeviceState > NdisDeviceStateD0)
	{
		//IF the miniport below is going to stanby.fail all incoming requests
		if (PrevDeviceState == NdisDeviceStateD0)
			pAdapt->StandingBy = TRUE;
		NdisReleaseSpinLock(&pAdapt->Lock);
#ifdef NDIS51
		//Notify upper layer protocol first
		if (pAdapt->MiniportHandle != NULL)
			ReturnStatus = NdisIMNotifyPnPEvent(pAdapt->MiniportHandle, pNetPnPEvent);
#endif

		//wait for out standing send and request to complete
		while (pAdapt->OutstandingSends != 0)
		{
			NdisMSleep(10);
		}

		while (pAdapt->OutstandingRequests == TRUE)
		{
			// sleep till outstanding requests complete
			NdisMSleep(2);
		}

		// If the below miniport is going to low power state, complete the queued request
		NdisAcquireSpinLock(&pAdapt->Lock);
		if (pAdapt->QueuedRequest)
		{
			pAdapt->QueuedRequest = FALSE;
			NdisReleaseSpinLock(&pAdapt->Lock);
			PtRequestComplete(pAdapt, &pAdapt->Request, NDIS_STATUS_FAILURE);
		}
		else
			NdisReleaseSpinLock(&pAdapt->Lock);

		ASSERT(NdisPacketPoolUsage(pAdapt->SendPacketPoolHandle) == 0);
		ASSERT(pAdapt->OutstandingRequests == FALSE);
	}
	else
	{
		// If the physical miniport is powering up (from Low power state to D0), 
		// clear the flag
		if (PrevDeviceState > NdisDeviceStateD0)
			pAdapt->StandingBy = FALSE;

		//the device below is being turned on .if we had a request 
		//pengding,send it down now
		if (pAdapt->QueuedRequest == TRUE)
		{
			pAdapt->QueuedRequest = FALSE;
			pAdapt->OutstandingRequests = TRUE;
			NdisReleaseSpinLock(&pAdapt->Lock);
			NdisRequest(&Status,
				pAdapt->BindingHandle,
				&pAdapt->Request);
			if (Status != NDIS_STATUS_PENDING)
			{
				PtRequestComplete(pAdapt,
					&pAdapt->Request, Status);
			}
		}
		else
			NdisReleaseSpinLock(&pAdapt->Lock);

#ifdef NDIS51
		//pass on this notification to protocol above
		if (pAdapt->MiniportHandle)
			ReturnStatus = NdisIMNotifyPnPEvent(pAdapt->MiniportHandle, pNetPnPEvent);
#endif
	}
	return ReturnStatus;
}


//������˵���²��첽�����Ѿ����
VOID
PtTransferDataComplete(
IN  NDIS_HANDLE         ProtocolBindingContext,
IN  PNDIS_PACKET        Packet,
IN  NDIS_STATUS         Status,
IN  UINT                BytesTransferred
)
{
	PADAPT pAdapt = (PADAPT)ProtocolBindingContext;

	//�������˵��MPTransferData������Pending
	FILTER_STATUS fStatus = AnalysisPacket(Packet, TRUE);
	if (fStatus == STATUS_DROP)
		Status = NDIS_STATUS_FAILURE;//����
	else if (fStatus == STATUS_REDIRECT){
		//ת�� todo
	}

	//�ϲ�����ptTransferDataComplete����˱�����
	if (pAdapt->MiniportHandle)
		NdisMTransferDataComplete(pAdapt->MiniportHandle,
		Packet,
		Status, BytesTransferred);
}