#include"NdisPacket.h"

//��Э���е���NdisIMInitialieDeviceInstanceEx����ת����������ʼ��
NDIS_STATUS MPInitialize(
	OUT PNDIS_STATUS	OpenErrorStatus,
	OUT PUINT			SelectedMediumIndex,
	IN PNDIS_MEDIUM		MediumArray,
	IN UINT				MediumArraySize,
	IN NDIS_HANDLE		MiniportAdapterHandle,
	IN NDIS_HANDLE		WrapperConfigurationContext)
{
	//���￪ʼ�����Լ�����NIC�豸
	UINT i;
	PADAPT pAdapt;
	NDIS_MEDIUM Medium;
	NDIS_STATUS Status;
	UNREFERENCED_PARAMETER(WrapperConfigurationContext);
	__asm int 3
	do
	{
		//���ȼ��������������Ĳ������д洢΢�Ͷ˿ھ��
		pAdapt = NdisIMGetDeviceContext(MiniportAdapterHandle);
		pAdapt->MiniportIsHalted = FALSE;

		KdPrint(("===> Miniport Initialie: Adapt %p \r\n", pAdapt));
		//ͨ�������ǽ������������Ľ������͵���Ϊ����΢�Ͷ˿ڵĽ������͡�
		//���ǣ��������������������ǹ������豸����ô����������802.3�Ľ������͡�
		Medium = pAdapt->Medium;

		if (Medium == NdisMediumWan)
			Medium = NdisMedium802_3;

		for (i = 0; i < MediumArraySize; i++)
		{
			if (MediumArray[i] == Medium)
			{
				*SelectedMediumIndex = i;
				break;
			}
		}

		if (i == MediumArraySize)
		{
			Status = NDIS_STATUS_UNSUPPORTED_MEDIA;
			break;
		}

		//����������������
		NdisMSetAttributesEx(
			MiniportAdapterHandle,
			pAdapt,
			0,
			NDIS_ATTRIBUTE_IGNORE_PACKET_TIMEOUT |
			NDIS_ATTRIBUTE_IGNORE_REQUEST_TIMEOUT |
			NDIS_ATTRIBUTE_INTERMEDIATE_DRIVER|
			NDIS_ATTRIBUTE_DESERIALIZE |
			NDIS_ATTRIBUTE_NO_HALT_ON_SUSPEND, 0);	//0����������ʾ����һ�������Adapt�豸

		pAdapt->MiniportHandle = MiniportAdapterHandle;
		pAdapt->LastIndicatedStatus = NDIS_STATUS_MEDIA_CONNECT;

		// Initialize the power states for both the lower binding (PTDeviceState)
		// and our miniport edge to Powered On.

		pAdapt->MPDeviceState = NdisDeviceStateD0;
		pAdapt->PTDeviceState = NdisDeviceStateD0;

		//Add this adapter to the global padapt list
		NdisAcquireSpinLock(&GlobalLock);
		pAdapt->Next = pAdaptList;
		pAdaptList = pAdapt;
		NdisReleaseSpinLock(&GlobalLock);

		//Create an ioctl interface
		(VOID)PtRegisterDevice();
		Status = NDIS_STATUS_SUCCESS;
	} while (FALSE);

	ASSERT(pAdapt->MiniportInitPending == TRUE);
	pAdapt->MiniportInitPending = FALSE;
	NdisSetEvent(&pAdapt->MiniportInitEvet);
	if (Status == NDIS_STATUS_SUCCESS)
		PtReferenceAdapt(pAdapt);

	KdPrint(("<== Miniport Initialize: Adapt %p,Status %x\r\n", pAdapt,Status));
	*OpenErrorStatus = Status;
	return Status;
}

//�м�� vitrual miniport
VOID MPSendPackets(
	IN NDIS_HANDLE		MiniportAdapterContext,
	IN PPNDIS_PACKET	PacketArray,
	IN UINT				NumberkOfPackets)
{
	PADAPT		pAdapt = (PADAPT)MiniportAdapterContext;
	FILTER_STATUS	fStatus;
	NDIS_STATUS		Status;
	UINT			i;
	PVOID			MediaSpecificInfo = NULL;
	UINT			MediaSpecificInfoSize = 0;

	for (i = 0; i < NumberkOfPackets; i++)
	{
		PNDIS_PACKET Packet, MyPacket;
		Packet = PacketArray[i];
		fStatus = AnalysisPacket(Packet, FALSE);
		if (fStatus == STATUS_DROP)
		{
			//����������У��κ�һ���������İ������������NdisMSendComplete
			NdisMSendComplete(
				pAdapt->MiniportHandle,
				Packet,
				NDIS_STATUS_FAILURE);
			continue;
		}
		else if (fStatus == STATUS_REDIRECT)
		{
			//ת�� TODO
		}

		//The Driver Should fail the send if the virtual miniport is in low power state

		if (pAdapt->MPDeviceState > NdisDeviceStateD0)
		{
			NdisMSendComplete(
				pAdapt->MiniportHandle,
				Packet,
				NDIS_STATUS_FAILURE);
			continue;
		}

#ifdef NDIS51
		//���￪ʼ�������ϲ㷢���²�������
		//Use NDIS 5.1 Packet Stacking:
		{
			PNDIS_PACKET_STACK	pStack;
			BOOLEAN				Remaining;

			//Packet stacks��check is we can use the same packet for sending down
			pStack = NdisIMGetCurrentPacketStack(Packet, &Remaining);
			//����
			if (Remaining)
			{
				//we can resue packet
				ASSERT(pStack);
				NdisAcquireSpinLock(&pAdapt->Lock);
				if (pAdapt->PTDeviceState > NdisDeviceStateD0)
				{
					NdisReleaseSpinLock(&pAdapt->Lock);
					NdisMSendComplete(pAdapt->MiniportHandle, Packet, NDIS_STATUS_FAILURE);
				}
				else
				{
					pAdapt->OutstandingSends++;
					NdisReleaseSpinLock(&pAdapt->Lock);
					NdisSend(&Status, pAdapt->BindingHandle, Packet);
					if (Status != NDIS_STATUS_PENDING)
					{
						NdisMSendComplete(pAdapt->MiniportHandle, Packet, Status);
						ADAPT_DECR_PENDING_SENDS(pAdapt);
					}
				}
				continue;
			}
		}
#endif
		//������
		do{
			NdisAcquireSpinLock(&pAdapt->Lock);
			//if the below miniport is going to low power state ,stop sending dow any packet

			if (pAdapt->PTDeviceState > NdisDeviceStateD0)
			{
				NdisReleaseSpinLock(&pAdapt->Lock);
				Status = NDIS_STATUS_FAILURE;
				break;
			}
			pAdapt->OutstandingSends++;
			NdisReleaseSpinLock(&pAdapt->Lock);
			NdisAllocatePacket(&Status, &MyPacket, pAdapt->SendPacketPoolHandle);
			if (Status == NDIS_STATUS_SUCCESS)
			{
				PSEND_RSVD SendRsvd;
				SendRsvd = (PSEND_RSVD)(MyPacket->ProtocolReserved);
				SendRsvd->OriginalPkt = Packet;

				NdisGetPacketFlags(MyPacket) = NdisGetPacketFlags(Packet);
				NDIS_PACKET_FIRST_NDIS_BUFFER(MyPacket) = NDIS_PACKET_FIRST_NDIS_BUFFER(Packet);
				NDIS_PACKET_FIRST_NDIS_BUFFER(MyPacket) = NDIS_PACKET_FIRST_NDIS_BUFFER(Packet);

				/***************����ʡȥ9x�Ĵ���*****************/


				//���ϲ����������͵����ݰ��е�ÿ�����ݰ���Ϣ���Ƶ�һ�������ݰ��У�
				//�����ݰ������·��͵��ϵ͵�΢�Ͷ˿���������
				NdisIMCopySendPerPacketInfo(MyPacket, Packet);

				NDIS_GET_PACKET_MEDIA_SPECIFIC_INFO(
					Packet,
					&MediaSpecificInfo,
					&MediaSpecificInfoSize);

				if (MediaSpecificInfo || MediaSpecificInfoSize)
					NDIS_SET_PACKET_MEDIA_SPECIFIC_INFO(
					MyPacket,
					MediaSpecificInfo,
					MediaSpecificInfoSize);
				NdisSend(&Status, pAdapt->BindingHandle, MyPacket);

				if (Status != NDIS_STATUS_PENDING)
				{
					//���ϵ�΢�Ͷ˿��������򷵻ص����ݰ��е�ÿ�����ݰ���Ϣ
					//���Ƶ�Ҫ���ظ��ϼ���������������ݰ��С�
					NdisIMCopySendCompletePerPacketInfo(Packet, MyPacket);
					NdisFreePacket(MyPacket);
					ADAPT_DECR_PENDING_SENDS(pAdapt);
				}
			}
			else
				ADAPT_DECR_PENDING_SENDS(pAdapt);
		} while (FALSE);

		if (Status != NDIS_STATUS_PENDING)
			NdisMSendComplete(pAdapt->MiniportHandle, Packet, Status);
	}
}



//���ϲ�Э����������NdisReturnPacket���˻ص�������
VOID MPReturnPacket(
	IN NDIS_HANDLE		MiniportAdapterContext,
	IN PNDIS_PACKET		Packet)
{
	PADAPT pAdapt = (PADAPT)MiniportAdapterContext;

	
#ifdef NDIS51
	//�ж��Ƿ���������
	if (NdisGetPoolFromPacket(Packet) != pAdapt->RecvPacketPoolHandle)
	{
		NdisReturnPackets(&Packet, 1);
	}
	else
#endif
	{
		PNDIS_PACKET	SysPacket;	//����İ�Ϊϵͳ��PacketΪ���Ǵ�pool����İ�
		PRECV_RSVD		RecvRsvd;

		RecvRsvd = (PRECV_RSVD)(Packet->MiniportReserved);
		SysPacket = RecvRsvd->OriginalPkt;

		NdisFreePacket(Packet);
		NdisReturnPackets(&SysPacket, 1);
	}

}

//OID ָ������������Ķ����ʶ����ָ�롣��ֵ��OID_XXX����
NDIS_STATUS MPQueryInformation(
	IN NDIS_HANDLE		MiniportAdapterContext,
	IN NDIS_OID			Oid,
	IN PVOID			InformationBuffer,
	IN ULONG			InformationBufferLength,
	OUT PULONG			BytesWritten,
	OUT PULONG			BytesNeeded
	)
{
	PADAPT pAdapt = (PADAPT)MiniportAdapterContext;
	NDIS_STATUS Status = NDIS_STATUS_FAILURE;
	do
	{
		if (Oid == OID_PNP_QUERY_POWER)
		{
			Status = NDIS_STATUS_SUCCESS;
			break;
		}
		if (Oid == OID_GEN_SUPPORTED_GUIDS)
		{
			Status = NDIS_STATUS_NOT_SUPPORTED;		//��֧��
			break;
		}

		if (Oid == OID_TCP_TASK_OFFLOAD)
		{
			//ʧ�����-���-�����������ִ�е�����ת�����ܻ���Žϵ͵���������ж��TCP�����������
		}

		NdisAcquireSpinLock(&pAdapt->Lock);
		if (pAdapt->UnBindingInProcess == TRUE)
		{
			NdisReleaseSpinLock(&pAdapt->Lock);
			Status = NDIS_STATUS_FAILURE;
			break;
		}
		NdisReleaseSpinLock(&pAdapt->Lock);
		//All other queries are failed, if the miniport is not at D0
		if (pAdapt->MPDeviceState > NdisDeviceStateD0)
		{
			Status = NDIS_STATUS_FAILURE;
			break;
		}

		pAdapt->Request.RequestType = NdisRequestQueryInformation;
		pAdapt->Request.DATA.QUERY_INFORMATION.Oid = Oid;
		pAdapt->Request.DATA.QUERY_INFORMATION.InformationBuffer = InformationBuffer;
		pAdapt->Request.DATA.QUERY_INFORMATION.InformationBufferLength = InformationBufferLength;
		pAdapt->BytesNeeded = BytesNeeded;
		pAdapt->BytesReadOrWritten = BytesWritten;

		//if the miniport below is binding,fail the request
		NdisAcquireSpinLock(&pAdapt->Lock);
		if (pAdapt->UnBindingInProcess == TRUE)
		{
			NdisReleaseSpinLock(&pAdapt->Lock);
			Status = NDIS_STATUS_FAILURE;
			break;
		}

		//if the protocol device state is off,mark this request as being pended.
		//We queue this until the device state is back to D0
		if ((pAdapt->PTDeviceState > NdisDeviceStateD0) &&
			(pAdapt->StandingBy == FALSE))
		{
			pAdapt->QueuedRequest = TRUE;
			NdisReleaseSpinLock(&pAdapt->Lock);
			Status = NDIS_STATUS_PENDING;
			break;
		}

		//this is in the process of powering down the system, always fail the request
		if (pAdapt->StandingBy == TRUE)
		{
			NdisReleaseSpinLock(&pAdapt->Lock);
			Status = NDIS_STATUS_FAILURE;
			break;
		}
		pAdapt->OutstandingRequests = TRUE;
		NdisReleaseSpinLock(&pAdapt->Lock);

		//default case,most requests will be passed to the miniport below
		NdisRequest(&Status,
			pAdapt->BindingHandle,
			&pAdapt->Request);

		if (Status != NDIS_STATUS_PENDING)
		{
			PtRequestComplete(pAdapt, &pAdapt->Request, Status);
			Status = NDIS_STATUS_PENDING;
		}
	} while (FALSE);

	return Status;
}

VOID MPQueryPNPCapabilities(
	IN OUT PADAPT pAdapt,
	OUT PNDIS_STATUS pStatus)
{
	PNDIS_PNP_CAPABILITIES pPNPCapabilities;
	PNDIS_PM_WAKE_UP_CAPABILITIES pPMstruct;

	if (pAdapt->Request.DATA.QUERY_INFORMATION.InformationBufferLength >= sizeof(NDIS_PNP_CAPABILITIES))
	{
		pPNPCapabilities =
			(PNDIS_PNP_CAPABILITIES)(pAdapt->Request.DATA.QUERY_INFORMATION.InformationBuffer);

		//the following fields must be overwritten by an IM Driver.
		pPMstruct = &pPNPCapabilities->WakeUpCapabilities;
		pPMstruct->MinMagicPacketWakeUp = NdisDeviceStateUnspecified;
		pPMstruct->MinPatternWakeUp = NdisDeviceStateUnspecified;
		pPMstruct->MinLinkChangeWakeUp = NdisDeviceStateUnspecified;

		*pAdapt->BytesReadOrWritten = sizeof(NDIS_PNP_CAPABILITIES);
		*pAdapt->BytesNeeded = 0;

		//Setting our internal flags
		//Default Device is ON
		pAdapt->MPDeviceState = NdisDeviceStateD0;
		pAdapt->PTDeviceState = NdisDeviceStateD0;

		*pStatus = NDIS_STATUS_SUCCESS;
	}
	else
	{
		*pAdapt->BytesNeeded = sizeof(NDIS_PNP_CAPABILITIES);
		*pStatus = NDIS_STATUS_SUCCESS;
	}
}


VOID MPFreeAllPacketPools(
	IN PADAPT pAdapt)
{
	if (pAdapt->RecvPacketPoolHandle != NULL)
	{
		NdisFreePacketPool(pAdapt->ReceivedIndicationFlags);
		pAdapt->RecvPacketPoolHandle = NULL;
	}

	if (pAdapt->SendPacketPoolHandle != NULL)
	{
		NdisFreePacketPool(pAdapt->SendPacketPoolHandle);
		pAdapt->SendPacketPoolHandle = NULL;
	}
}



NDIS_STATUS MPSetInformation(
	IN NDIS_HANDLE		MiniportAdaptContext,
	IN NDIS_OID			Oid,
	__in_bcount(InformationBufferLength)IN PVOID InformationBuffer,
	IN ULONG			InformationBufferLength,
	OUT PULONG			BytesRead,
	OUT PULONG			BytesNeeded)
{
	PADAPT pAdapt = (PADAPT)MiniportAdaptContext;
	NDIS_STATUS Status;
	Status = NDIS_STATUS_FAILURE;

	do
	{
		// 
		if (Oid == OID_PNP_SET_POWER)
		{
			MPProcessSetPowerOid(
				&Status,
				pAdapt,
				InformationBuffer,
				InformationBufferLength,
				BytesRead,
				BytesNeeded);
			break;
		}

		//if the miniport below is unbinding,fail the request
		NdisAcquireSpinLock(&pAdapt->Lock);

		if (pAdapt->UnBindingInProcess == TRUE)
		{
			NdisReleaseSpinLock(&pAdapt->Lock);
			Status = NDIS_STATUS_FAILURE;
			break;
		}
		NdisReleaseSpinLock(&pAdapt->Lock);

		//���΢�Ͷ˿ڲ���D0������ת��������D0���豸״̬��
		//����������Set Information���󶼽�ʧ�ܡ�
		if (pAdapt->MPDeviceState > NdisDeviceStateD0)
		{
			Status = NDIS_STATUS_FAILURE;
			break;
		}

		//Set up the request and return the result
		pAdapt->Request.RequestType = NdisRequestSetInformation;
		pAdapt->Request.DATA.SET_INFORMATION.Oid = Oid;
		pAdapt->Request.DATA.SET_INFORMATION.InformationBuffer = InformationBuffer;
		pAdapt->Request.DATA.SET_INFORMATION.InformationBufferLength = InformationBufferLength;
		pAdapt->BytesNeeded = BytesNeeded;
		pAdapt->BytesReadOrWritten = BytesRead;

		//if the miniport below is unbinding,fail the request
		NdisAcquireSpinLock(&pAdapt->Lock);
		if (pAdapt->UnBindingInProcess == TRUE)
		{
			NdisReleaseSpinLock(&pAdapt->Lock);
			Status = NDIS_STATUS_SUCCESS;
			break;
		}

		// If the device below is at a low power state, we cannot send it the
		// request now, and must pend it.

		if ((pAdapt->PTDeviceState > NdisDeviceStateD0) &&
			(pAdapt->StandingBy == FALSE))
		{
			pAdapt->QueuedRequest = TRUE;
			NdisReleaseSpinLock(&pAdapt->Lock);
			Status = NDIS_STATUS_SUCCESS;
			break;
		}

		// This is in the process of powering down the system, always fail the request

		if (pAdapt->StandingBy == TRUE)
		{
			NdisReleaseSpinLock(&pAdapt->Lock);
			Status = NDIS_STATUS_SUCCESS;
			break;
		}
		//����²�˿����󱻹���ΪTRUE
		pAdapt->OutstandingRequests = TRUE;

		NdisReleaseSpinLock(&pAdapt->Lock);

		NdisRequest(&Status, pAdapt->BindingHandle, &pAdapt->Request);
		if (Status != NDIS_STATUS_PENDING)
		{
			*BytesRead = pAdapt->Request.DATA.SET_INFORMATION.BytesRead;
			*BytesNeeded = pAdapt->Request.DATA.SET_INFORMATION.BytesNeeded;
			pAdapt->OutstandingRequests = FALSE;
		}
	} while (FALSE);
	return Status;
}


VOID MPProcessSetPowerOid(
	IN OUT PNDIS_STATUS		pNdisStatus,
	IN PADAPT				pAdapt,
	__in_bcount(InformationBufferLength) IN PVOID InformationBuffer,
	IN ULONG				InformationBufferLength,
	OUT PULONG				BytesRead,
	OUT PULONG				BytesNeeded)
{
	NDIS_DEVICE_POWER_STATE NewDeviceState;
	KdPrint(("==> MPProcessSetPowerOid: Adapt %p\r\n", pAdapt));
	ASSERT(InformationBuffer != NULL);
	*pNdisStatus = NDIS_STATUS_FAILURE;

	do
	{
		//Check For invalid length
		if (InformationBufferLength < sizeof(NDIS_DEVICE_POWER_STATE))
		{
			*pNdisStatus = NDIS_STATUS_INVALID_LENGTH;
			break;
		}

		NewDeviceState = (*(PNDIS_DEVICE_POWER_STATE)InformationBuffer);

		//Check for invalid device state

		if ((pAdapt->MPDeviceState > NdisDeviceStateD0) && 
			(NewDeviceState != NdisDeviceStateD0))
		{
			//If the moniport is in a non-D0 State, the miniport can only receive a set power to D0
			ASSERT(!(pAdapt->MPDeviceState > NdisDeviceStateD0) &&
				(NewDeviceState != NdisDeviceStateD0));
			*pNdisStatus = NDIS_STATUS_FAILURE;
			break;
		}

		// Is the miniport transitioning from an On (D0) state to an Low Power State (>D0)
		// If so, then set the StandingBy Flag - (Block all incoming requests)
		if (pAdapt->MPDeviceState == NdisDeviceStateD0&&NewDeviceState > NdisDeviceStateD0)
		{
			pAdapt->StandingBy = TRUE;
		}


		// If the miniport is transitioning from a low power state to ON (D0), then clear the StandingBy flag
		// All incoming requests will be pended until the physical miniport turns ON.
		//

		if (pAdapt->MPDeviceState > NdisDeviceStateD0&&NewDeviceState == NdisDeviceStateD0)
		{
			pAdapt->StandingBy = FALSE;
		}

		// Now update the state in the pAdapt structure;
		pAdapt->MPDeviceState = NewDeviceState;
		*pNdisStatus = NDIS_STATUS_SUCCESS;
	} while (FALSE);
	
	if (*pNdisStatus == NDIS_STATUS_SUCCESS)
	{
		// the miniport reume from low power state
		if (pAdapt->StandingBy == FALSE)
		{
			//If we need to indicate the media connect state
			if (pAdapt->LastIndicatedStatus != pAdapt->LatestUnIndicateStatus)
			{
				if (pAdapt->MiniportHandle != NULL)
				{
					NdisMIndicateStatus(pAdapt->MiniportHandle,
						pAdapt->LatestUnIndicateStatus,
						(PVOID)NULL, 0);
					NdisMIndicateStatusComplete(pAdapt->MiniportHandle);
					pAdapt->LastIndicatedStatus = pAdapt->LatestUnIndicateStatus;
				}
			}
		}
		else
		{
			//Initialize LatestUnIndicatedState
			pAdapt->LatestUnIndicateStatus = pAdapt->LastIndicatedStatus;
		}
		*BytesRead = sizeof(NDIS_DEVICE_POWER_STATE);
		*BytesNeeded = 0;
	}
	else
	{
		*BytesRead = 0;
		*BytesNeeded = sizeof(NDIS_DEVICE_POWER_STATE);
	}
}

VOID
MPHalt(
IN NDIS_HANDLE                MiniportAdapterContext
)
{
	__asm int 3
	PADAPT pAdapt = (PADAPT)MiniportAdapterContext;
	NDIS_STATUS Status;
	PADAPT *pCursor;

	KdPrint(("==> MiniportHalt: Adapt %p \r\n", pAdapt));

	pAdapt->MiniportHandle = NULL;
	pAdapt->MiniportIsHalted = TRUE;

	//Remove this adapter from the global list
	NdisAcquireSpinLock(&GlobalLock);

	for (pCursor = &pAdaptList; pCursor != NULL; pCursor = &(*pCursor)->Next)
	{
		if (*pCursor == pAdapt)
		{
			*pCursor = pAdapt->Next;
			break;
		}
	}
	NdisReleaseSpinLock(&GlobalLock);

	//Delete the ioctl interface that was created when the miniport was created.

	(VOID)PtDeregisterDevice();

	//if we have a valid bind, close the miniport below the protocol
#pragma prefast(suppress: __WARNING_DEREF_NULL_PTR, "pAdapt cannot be NULL")
	if (pAdapt->BindingHandle != NULL)
	{
		//close The binding below,and wait for it to complete
		NdisResetEvent(&pAdapt->Event);
		NdisCloseAdapter(&Status, pAdapt->BindingHandle);
		if (Status == NDIS_STATUS_PENDING)
		{
			NdisWaitEvent(&pAdapt->Event, 0);
			Status = pAdapt->Status;
		}
		ASSERT(Status == NDIS_STATUS_SUCCESS);
		pAdapt->BindingHandle = NULL;
		PtDereferenceAdapt(pAdapt);
	}
	if (PtDereferenceAdapt(pAdapt))
		pAdapt = NULL;
	KdPrint(("MiniportHaltL pAdapt:%p\r\b", pAdapt));
}

NDIS_STATUS
PtDeregisterDevice(
VOID
)
{
	NDIS_STATUS Status = NDIS_STATUS_SUCCESS;
	KdPrint(("==>DeregisterDevice\r\n"));
	NdisAcquireSpinLock(&GlobalLock);

	ASSERT(MiniportConut > 0);
	--MiniportConut;
	if (0 == MiniportConut)
	{
		ASSERT(ControlDeviceState == PS_DEVICE_STATE_READY);

		ControlDeviceState = PS_DEVICE_STATE_DELETING;
		NdisReleaseSpinLock(&GlobalLock);
		if (NdisDeviceHandle != NULL)
		{
			Status = NdisMDeregisterDevice(NdisDeviceHandle);
			NdisDeviceHandle = NULL;
		}
		NdisAcquireSpinLock(&GlobalLock);
		ControlDeviceState = PS_DEVICE_STATE_READY;
	}
	NdisReleaseSpinLock(&GlobalLock);

	KdPrint(("DeregisterDevice:%x\r\n", Status));
	return Status;
}


NDIS_STATUS
MPTransferData(
OUT PNDIS_PACKET            Packet,
OUT PUINT                   BytesTransferred,
IN NDIS_HANDLE              MiniportAdapterContext,
IN NDIS_HANDLE              MiniportReceiveContext,
IN UINT                     ByteOffset,
IN UINT                     BytesToTransfer
)
{
	PADAPT pAdapt = (PADAPT)MiniportAdapterContext;
	NDIS_STATUS Status;

	//return. if this device is off

	if (IsIMDeviceStateOn(pAdapt) == FALSE)
	{
		return NDIS_STATUS_FAILURE;
	}
	NdisTransferData(
		&Status,
		pAdapt->BindingHandle,
		MiniportReceiveContext,
		ByteOffset,
		BytesToTransfer,
		Packet,
		BytesTransferred);
	if (NDIS_STATUS_SUCCESS == Status)
	{
		//�Ѿ���ȫ���ݺ��ˣ���һ�������� NDIS Pakcet
		FILTER_STATUS fStatus = AnalysisPacket(Packet, TRUE);
		if (fStatus == STATUS_DROP)
		{
			Status = NDIS_STATUS_FAILURE;		//����
		}
		else if (fStatus == STATUS_REDIRECT)
		{
			//ת������
			//TODO
		}
	}
	return Status;
}



#ifdef NDIS51_MINIPORT
VOID
MPCancelSendPackets(
IN NDIS_HANDLE            MiniportAdapterContext,
IN PVOID                  CancelId
)
{
	PADAPT pAdapt = (PADAPT)MiniportAdapterContext;
	NdisCancelSendPackets(pAdapt->BindingHandle, CancelId);
	return;
}


VOID
MPDevicePnPEvent(
IN NDIS_HANDLE              MiniportAdapterContext,
IN NDIS_DEVICE_PNP_EVENT    DevicePnPEvent,
IN PVOID                    InformationBuffer,
IN ULONG                    InformationBufferLength
)
/*++

Routine Description:

This handler is called to notify us of PnP events directed to
our miniport device object.

Arguments:

MiniportAdapterContext    - pointer to ADAPT structure
DevicePnPEvent - the event
InformationBuffer - Points to additional event-specific information
InformationBufferLength - length of above

Return Value:

None
--*/
{
	// TBD - add code/comments about processing this.

	UNREFERENCED_PARAMETER(MiniportAdapterContext);
	UNREFERENCED_PARAMETER(DevicePnPEvent);
	UNREFERENCED_PARAMETER(InformationBuffer);
	UNREFERENCED_PARAMETER(InformationBufferLength);

	return;
}

VOID
MPAdapterShutdown(
IN NDIS_HANDLE                MiniportAdapterContext
)
/*++

Routine Description:

This handler is called to notify us of an impending system shutdown.

Arguments:

MiniportAdapterContext    - pointer to ADAPT structure

Return Value:

None
--*/
{
	UNREFERENCED_PARAMETER(MiniportAdapterContext);

	return;
}
#endif