#pragma once
#include<winnt.h>
/*1
typedef struct _PROCESSINFOLIST
{
	LIST_ENTRY		NextInfo;
	unsigned int	Pid;
	wchar_t			Name[260];
	struct _Cpu
	{
		float			CpuRate;
		//��һ�ε�ʱ��
		__int64 last_time;
		__int64 last_system_time;
	}Cpu;
}PROCESSINFOLIST, *PPROCESSINFOLIST;
1*/
typedef struct _DefProcessStruct
{

	struct _DefProcessStruct	*NextList;
	PVOID				eProcess;
	unsigned int		Pid;	//_EPROCESS+0xB4
	struct _Cpu
	{
		float			CpuRate = 0;
		//��һ�ε�ʱ��
		__int64 last_time;
		__int64 last_system_time;
	}Cpu;
	ULONG				NameOffsets;  //Path+NameOffsets=Name;
	WCHAR				Path[256];
}DefProcessStruct, *PDefProcessStruct;
