#pragma once
#include<Windows.h>
#include<process.h>
#include"ProcessInfoList.h"
#include"RaisePower.h"
extern PDefProcessStruct g_ProcstructLink;
//ʱ��ת��
static __int64 file_time_utc(const FILETIME* ftime)
{
	LARGE_INTEGER li;
	li.LowPart = ftime->dwLowDateTime;
	li.HighPart = ftime->dwHighDateTime;
	return li.QuadPart;

	/*msdn���鲻Ҫ��FILETIME�ṹ��ȥ��Ӽ���ȡ���ʱ�� 
	�Ȱ�FILETIME�ĸ�λ�͵�λ�ֱ𿽱���ULARGE_INTEGER �ṹ�壬 
	Ȼ����ULARGE_INTEGER ��QuadPart ��Ա�����������㣬��󿽱� 
	��λ�͵�λ��FILETIME 
	��Ҫ��FILETIME*ת����ULARGE_INTEGER*��_int64*�����ͣ���Ϊ��64λWindows�������λ�쳣 
*/
}

//���cpu�ĺ���
static int get_processor_number()
{
	SYSTEM_INFO info;
	GetSystemInfo(&info);
	return (int)info.dwNumberOfProcessors;
}

//��ȡ����cpuռ��
int GetCpuRate(PDefProcessStruct Proclist)
{
	//cpu����
	static int processor_cont = -1;


	FILETIME now;
	FILETIME Creation_time;
	FILETIME exit_time;
	FILETIME kernel_time;
	FILETIME user_time;
	__int64 system_time;
	__int64 time;
	__int64 system_time_delta;
	__int64 time_delta;

	if (processor_cont == -1)
		processor_cont = get_processor_number();

	//��ȡ�����Ǵ�1601��1��1�յ�Ŀǰ����������
	GetSystemTimeAsFileTime(&now);
//	RaiseDebugPrivilege(TRUE);
	HANDLE hProcess=NULL;
	hProcess= OpenProcess(PROCESS_ALL_ACCESS, false, Proclist->Pid);
	if (!GetProcessTimes(hProcess, &Creation_time, &exit_time, &kernel_time, &user_time))
		return 0;
	system_time = (file_time_utc(&kernel_time) + file_time_utc(&user_time)) / processor_cont;
	time = file_time_utc(&now);

	
	if ((Proclist->Cpu.last_system_time == 0 || Proclist->Cpu.last_time == 0))
	{
		
		Proclist->Cpu.last_system_time = system_time;
		Proclist->Cpu.last_time = time;
		return 0;
	}
	system_time_delta = system_time - Proclist->Cpu.last_system_time;

	time_delta = time - Proclist->Cpu.last_time;

	if (time_delta == 0)
		return 0;
	float tempsystime, temptime;
	tempsystime = system_time_delta;
	temptime = time_delta;

	Proclist->Cpu.CpuRate = (float)((tempsystime * 100 + temptime / 2) / temptime) - 0.5;
	Proclist->Cpu.last_system_time = system_time;
	Proclist->Cpu.last_time = time;


	CloseHandle(hProcess);
//	RaiseDebugPrivilege(FALSE);
	return 1;

}


void GetCpuRateThread(void *x)
{
	PDefProcessStruct TempProcInfoList;
	while (1)
	{
		TempProcInfoList = g_ProcstructLink;

		for (; TempProcInfoList!=NULL;)
		{
			GetCpuRate(TempProcInfoList);
			TempProcInfoList = TempProcInfoList->NextList;
		}

		Sleep(1000);
	}

	_endthread();
}


//˫����biemap
void DoubleBuffer(HDC hdc, int cxClient,int cyClient)
{
	HDC DC = CreateCompatibleDC(NULL);
	HBITMAP hBitmap = CreateCompatibleBitmap(hdc, cxClient, cyClient);
	HGDIOBJ oldBitmap = SelectObject(DC, hBitmap);
	BitBlt(DC, 0, 0, cxClient, cyClient, NULL, 0, 0, WHITENESS);	//��ʼ��һ��DC

	//�滭DC

	BitBlt(hdc, 0, 0, cxClient, cxClient, DC, 0, 0, SRCCOPY);


	DeleteDC(DC);
	DeleteObject(hBitmap);
}