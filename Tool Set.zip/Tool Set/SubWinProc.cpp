#include"SubWinProc.h"
#include"NdisLoad.h"
#pragma comment (lib,"Ws2_32.lib")
#include<TlHelp32.h>

void InitTextEdit(HWND hwnd, int iNumber)
{
	for (int i =0; i < iNumber; i++)
	{
		SetDlgItemTextA(hwnd, IDC_STATIC1 + i, "");
	}
	return;
}
DLGPROC CALLBACK TabProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	static ULONG Number;
	TCHAR buffer[0x3f];
	PULONG pointer;
	switch (msg)
	{
	case WM_INITDIALOG:
		Number = lparam;
		TCITEM control;
		memset(&control, 0, sizeof(TCITEM));
		control.mask = TCIF_TEXT;
		control.pszText = L"Performance";
		SendDlgItemMessage(hwnd, IDC_TAB1, TCM_INSERTITEM, 0, (LPARAM)&control);
		control.pszText = L"Process Memory";
		SendDlgItemMessage(hwnd, IDC_TAB1, TCM_INSERTITEM, 1, (LPARAM)&control);

		InitTextEdit(hwnd, 13);
		PERFORMACE_INFORMATION Perstruct;
		Perstruct.cb = sizeof(PERFORMACE_INFORMATION);
		GetPerformanceInfo(&Perstruct, sizeof(PERFORMACE_INFORMATION));
		pointer = (PULONG)&Perstruct;
		pointer++;
		for (int i = 0; i < 13; i++)
		{
			wsprintf(buffer, L"%ws : %d", Performance[i], *pointer);
			SetDlgItemText(hwnd, IDC_STATIC1 + i, buffer);
			pointer++;
		}

		PDefProcessStruct Proc;
		Proc = g_ProcstructLink;
		for (ULONG i = 0; i < Number; i++)
		{
			Proc = Proc->NextList;
		}
		wsprintf(buffer, L"%ws : %d", Proc->Path + Proc->NameOffsets, Proc->Pid);
		SetWindowText(hwnd, buffer);
		break;

	case WM_NOTIFY:
		switch (((LPNMHDR)lparam)->code)
		{
		case TCN_SELCHANGE:
			int Wini;
			Wini = SendMessage(GetDlgItem(hwnd, IDC_TAB1), TCM_GETCURSEL, 0, 0);
			switch (Wini)
			{
			case WIN_PERFORMANCE:
				InitTextEdit(hwnd, 13);
				PERFORMACE_INFORMATION Perstruct;
				Perstruct.cb = sizeof(PERFORMACE_INFORMATION);
				GetPerformanceInfo(&Perstruct, sizeof(PERFORMACE_INFORMATION));
				pointer = (PULONG)&Perstruct;
				pointer++;
				for (int i = 0; i < 13; i++)
				{
					wsprintf(buffer, L"%ws : %d", Performance[i], *pointer);
					SetDlgItemText(hwnd, IDC_STATIC1 + i, buffer);
					pointer++;
				}
				break;

			case WIN_MEMORY:
				InitTextEdit(hwnd, 13);
				PROCESS_MEMORY_COUNTERS Memory;
				Memory.cb = sizeof(PROCESS_MEMORY_COUNTERS);
				GetProcessMemoryUse(Number, &Memory);
				pointer = (PULONG)&Memory;
				pointer++;
				for (int i = 0; i < 9; i++)
				{
					wsprintf(buffer, L"%ws : %d B", ProcMemory[i], *pointer);
					SetDlgItemText(hwnd, IDC_STATIC1 + i, buffer);
					pointer++;
				}
				break;
			}
		}
		break;

	case WM_CLOSE:
		EndDialog(hwnd, 0);
		return 0;
	default:
		break;

	}
	return 0;
}

DLGPROC CALLBACK PortProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	static int cxClient, cyClient, cyBoundary = 15;
	static DWORD ret = 0;
	static PCOMMUNICATE_PORT PortInfo = NULL;
	SCROLLINFO ScrInfo;
	HANDLE hFile;
	switch (msg)
	{
	case WM_INITDIALOG:
		SetDlgItemTextA(hwnd, IDC_BUTTON1, "ProcName");
		SetDlgItemTextA(hwnd, IDC_BUTTON2, "Pid");
		SetDlgItemTextA(hwnd, IDC_BUTTON3, "Protocol");
		SetDlgItemTextA(hwnd, IDC_BUTTON4, "LocalAdd");
		SetDlgItemTextA(hwnd, IDC_BUTTON5, "LocalPort");
		SetDlgItemTextA(hwnd, IDC_BUTTON6, "RemoteAdd");
		SetDlgItemTextA(hwnd, IDC_BUTTON7, "RemotePort");
		SetDlgItemTextA(hwnd, IDC_BUTTON8, "State");

		PortInfo = (PCOMMUNICATE_PORT)malloc(sizeof(ULONG) + sizeof(COMMUNICATE_PORT) * 1000);

		hFile=CreateFile(
			szWin32DriverName,
			GENERIC_READ | GENERIC_WRITE,
			FILE_SHARE_READ,
			0, OPEN_EXISTING,
			FILE_ATTRIBUTE_SYSTEM, NULL);
		if (hFile == INVALID_HANDLE_VALUE)
		{
			OutputDebugStringA("CreateFile Open fail (PortInfo).");
			break;
		}
		DeviceIoControl(
			hFile,
			UK_QURYPORTINFO,
			NULL,
			NULL,
			PortInfo,
			sizeof(ULONG) + sizeof(COMMUNICATE_PORT) * 1000,
			&ret,
			NULL);

		CloseHandle(hFile);
		RECT rect;
		GetWindowRect(hwnd, &rect);
		cxClient = rect.right;
		cyClient = rect.bottom;
		
		SetWindowPos(hwnd, 0, 0, 0, cxClient, cyClient, 0);
		MoveWindow(GetDlgItem(hwnd, IDC_BUTTON1), 0, 0, cxClient / 8 + 5, cyBoundary, FALSE);
		MoveWindow(GetDlgItem(hwnd, IDC_BUTTON2), cxClient / 8 + 5, 0, cxClient / 8 - 5, cyBoundary, FALSE);
		MoveWindow(GetDlgItem(hwnd, IDC_BUTTON3), cxClient / 8 * 2, 0, cxClient / 8 - 10, cyBoundary, FALSE);
		MoveWindow(GetDlgItem(hwnd, IDC_BUTTON4), cxClient / 8 * 3 - 10, 0, cxClient / 8 + 5, cyBoundary, FALSE);
		MoveWindow(GetDlgItem(hwnd, IDC_BUTTON5), cxClient / 8 * 4 - 5, 0, cxClient / 8, cyBoundary, FALSE);
		MoveWindow(GetDlgItem(hwnd, IDC_BUTTON6), cxClient / 8 * 5 - 5, 0, cxClient / 8 + 5, cyBoundary, FALSE);
		MoveWindow(GetDlgItem(hwnd, IDC_BUTTON7), cxClient / 8 * 6, 0, cxClient / 8, cyBoundary, FALSE);
		MoveWindow(GetDlgItem(hwnd, IDC_BUTTON8), cxClient / 8 * 7, 0, cxClient / 8, cyBoundary, FALSE);

		ScrInfo.nMin = 0;
		ScrInfo.nMax = PortInfo->nCnt;
		ScrInfo.fMask = SIF_RANGE | SIF_PAGE;
		ScrInfo.cbSize = sizeof(SCROLLINFO);
		ScrInfo.nPage = cyClient / 15;

		SetScrollInfo(hwnd, SB_VERT, &ScrInfo, TRUE);
		break;

	case WM_SIZE:
		break;

	case WM_PAINT:
		if (ret == 0)
		{
			OutputDebugStringA("DeviceIoControl Init fail ret=0");
			break;
		}
		HDC hdc;
		PAINTSTRUCT ps;
		RECT DrawRect;
		int i,j;
		char Buffer[0x2f];
		hdc=BeginPaint(hwnd, &ps);

		//����PortInfo
		PPORT_INFO tempPort;
		tempPort = PortInfo->Ports;
		SetBkMode(hdc, TRANSPARENT);	//�ı����屳��ģʽ
		for (i = 0; (ULONG)i <PortInfo->nCnt; i++)
		{
			DrawRect.left = 3;
			DrawRect.top = cyBoundary + i * 15;
			DrawRect.right = cxClient;
			DrawRect.bottom = cyBoundary + 15 + i * 15;
			PDefProcessStruct tempProc;

			tempProc = g_ProcstructLink;
			for (j = 0; (ULONG)j < g_ProcNumber; j++)
			{
				if (tempPort->nPid == tempProc->Pid)
					break;
				tempProc = tempProc->NextList;
			}
			//ProcName;
			DrawTextW(hdc, &tempProc->Path[tempProc->NameOffsets], -1, &DrawRect, NULL);

			//ProcPid
			memset(Buffer, 0, 0x2f);
			wsprintfA(Buffer, "%d", tempPort->nPid);
			DrawRect.left += cxClient / 8 + 5;
			DrawTextA(hdc, Buffer, -1, &DrawRect, NULL);

			//Protocol
			DrawRect.left += cxClient / 8;
			if (tempPort->nPorttype == enumTcp)
				wsprintfA(Buffer, "%s", szProType[0]);
			else
				wsprintfA(Buffer, "%s", szProType[1]);

			DrawTextA(hdc, Buffer, -1, &DrawRect, NULL);

			//localAdd
			memset(Buffer, 0, 0x2f);
			in_addr add;
			char* szIp;
			add.S_un.S_addr = tempPort->nLocalAddress;
			szIp = inet_ntoa(add);
			DrawRect.left += cxClient / 8  - 10;
			DrawTextA(hdc, szIp, -1, &DrawRect, NULL);
		

			//localport
			DrawRect.left += cxClient / 8 + 5;
			wsprintfA(Buffer, "%d", tempPort->nLocalPort);
			DrawTextA(hdc, Buffer, -1, &DrawRect, NULL);

			//localRemote
			DrawRect.left += cxClient / 8 + 5;
			add.S_un.S_addr = tempPort->nRemoteAddress;
			szIp = inet_ntoa(add);
			DrawTextA(hdc, szIp, -1, &DrawRect, NULL);

			//RemotePor
			DrawRect.left += cxClient / 8;
			wsprintfA(Buffer, "%d", tempPort->nRemotePort);
			DrawTextA(hdc, Buffer, -1, &DrawRect, NULL);

			//State
			DrawRect.left += cxClient / 8;
			wsprintfA(Buffer, "%ws", szConnectStatus[tempPort->nConnectState]);
			DrawTextA(hdc, Buffer, -1, &DrawRect, NULL);

			DrawRect.left = 3;
			DrawRect.top += cyBoundary;
			DrawRect.bottom += cyBoundary;
			tempPort = tempPort++;
		}
		SetBkMode(hdc, OPAQUE);
		//���ƺ���
		for (i = 0; i < cyClient; i += 15);
		{
			MoveToEx(hdc, 0, i, NULL);
			LineTo(hdc, cxClient, i);
		}
		break;

	case WM_CLOSE:
		free(PortInfo);
		PortInfo = NULL;
		EndDialog(hwnd, 0);
		break;
	}
	return 0;
}

DLGPROC CALLBACK SubWinInfo(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
#define id_forTimer			1
	static ULONG Pid;
	static UINT yBorder = 15;								//ÿ�и߶�
	static RECT WinRect, ClientRect, SubWinRect, DrawRect;
	static UINT labelType, labelHand, labelObj,labelName;			//��ť�೤��
	static PHANDLE_OBJ_INFO pHandleList = NULL;
	static PDLL_INFO pDll=NULL;
	/*1
	struct _HANDLE_AND_DLL
	{
		union 
		{
			PHANDLE_OBJ_INFO pHandleList = NULL;
			PVOID	Dll;
		};
	}HandleAndDll;
	1*/
	static UINT HandleNumber;
	static int WheelPos;		//����
	static RECT Fullrect;		//���������
	HWND hParent;
	DWORD x, y;;
	switch (msg)
	{
	case WM_INITDIALOG:
		hParent = GetParent(hwnd);
		GetWindowRect(hParent, &WinRect);
		MoveWindow(hwnd, WinRect.left, WinRect.bottom, WinRect.right, yBorder * 10, FALSE);
		SetTimer(hwnd, id_forTimer, 1000, NULL);


		//����Ҫ���� �ʹ��������¼�һ����

		//������껬������
	case WM_SETTINGCHANGE:
		ULONG ScrollLine;
		SystemParametersInfo(SPI_GETWHEELSCROLLLINES, 0, &ScrollLine, 0);
		if (ScrollLine)
			WheelPos = WHEEL_DELTA / ScrollLine;
		else
			WheelPos = 0;
		return 0;


	case WM_SIZE:
		hParent = GetParent(hwnd);
		GetWindowRect(hParent, &WinRect);
		GetWindowRect(hwnd, &SubWinRect);
		MoveWindow(hwnd, WinRect.left, WinRect.bottom, WinRect.right - WinRect.left, yBorder * 10, TRUE);
		GetClientRect(hwnd, &ClientRect);
		labelType = 150;
		labelHand = 100;
		labelObj = 100;
		labelName = ClientRect.right - (labelType + labelHand + labelObj);
		MoveWindow(GetDlgItem(hwnd, IDC_BUTTON1),
			ClientRect.left,
			ClientRect.top,
			labelType,
			yBorder, TRUE);

		MoveWindow(GetDlgItem(hwnd, IDC_BUTTON2),
			labelType,
			ClientRect.top,
			labelHand,
			yBorder, TRUE);

		MoveWindow(GetDlgItem(hwnd, IDC_BUTTON3),
			labelType + labelHand,
			ClientRect.top,
			labelObj,
			yBorder, TRUE);

		MoveWindow(GetDlgItem(hwnd, IDC_BUTTON4),
			labelType + labelHand + labelObj,
			ClientRect.top,
			labelName,
			yBorder, TRUE);

		InvalidateRect(hwnd, NULL, TRUE);
		break;

	case WM_TIMER:
		switch (wparam)
		{
		case 1:
			InvalidateRect(hwnd, NULL, FALSE);
			break;
		}
		break;

	case WM_VSCROLL:
		ULONG ScrollPos;
		ScrollPos = GetScrollPos(hwnd, SB_VERT);
		switch (LOWORD(wparam))
		{
		case SB_PAGEDOWN:
			ScrollPos += 4;
			ScrollPos = min(HandleNumber, ScrollPos);
			break;

		case SB_LINEDOWN:
			ScrollPos += 1;	//�����׽�min�� �����ִ������+1
			ScrollPos = min(HandleNumber, ScrollPos);
			break;

		case SB_PAGEUP:
			ScrollPos -= 4;
			ScrollPos = max(0, ScrollPos);
			break;

		case SB_LINEUP:
			ScrollPos -= 1;
			ScrollPos = max(0, ScrollPos);
			break;

		case SB_THUMBPOSITION:
		case SB_THUMBTRACK:
			ScrollPos = HIWORD(wparam);
			break;
		}
		SetScrollPos(hwnd, SB_VERT, ScrollPos, TRUE);
		InvalidateRect(hwnd, NULL, FALSE);
		break;

	case WM_DATEUPHANDLEINFO:
		PHANDLE_OBJ_INFO pHandleInfo;
		DWORD Ret, Retnum;
		SCROLLINFO si;
		HANDLE hFile;

		//�ı䰴ť����
		if (bHandleAndDll)
		{
			SetWindowText(GetDlgItem(hwnd, IDC_BUTTON1), TEXT("TypeName"));
			SetWindowText(GetDlgItem(hwnd, IDC_BUTTON2), TEXT("Handle"));
			SetWindowText(GetDlgItem(hwnd, IDC_BUTTON3), TEXT("Object"));
			SetWindowText(GetDlgItem(hwnd, IDC_BUTTON4), TEXT("Path"));
		}
		else
		{
			SetWindowText(GetDlgItem(hwnd, IDC_BUTTON1), TEXT("ModuleName"));
			SetWindowText(GetDlgItem(hwnd, IDC_BUTTON2), TEXT("Size"));
			SetWindowText(GetDlgItem(hwnd, IDC_BUTTON3), TEXT("BaseAddre"));
			SetWindowText(GetDlgItem(hwnd, IDC_BUTTON4), TEXT("Path"));
		}
		
		//���wparamΪ1 ��ʾ������pid
		if (wparam!=1)
			Pid = (ULONG)lparam;

		if (bHandleAndDll)
		{
			if (pHandleList != NULL)
				VirtualFree(pHandleList, NULL, MEM_RELEASE);


			hFile = CreateFile(
				szWin32DriverName,
				GENERIC_READ | GENERIC_WRITE,
				FILE_SHARE_READ | FILE_SHARE_WRITE,
				NULL, OPEN_EXISTING, FILE_ATTRIBUTE_SYSTEM, NULL);
			if (hFile == INVALID_HANDLE_VALUE)
			{
				OutputDebugStringA("Subwin CreateFile fail");
				return 0;
			}
			DeviceIoControl(
				hFile,
				UK_QQUERYHANDLE,
				&Pid,
				sizeof(Pid),
				&Retnum,
				sizeof(DWORD),
				&Ret, NULL);
			if (Retnum == 0)
			{
				OutputDebugStringA("DeviceIoComtrol fail\r\n");
				return 0;
			}
			Ret = 0;

			pHandleInfo = (PHANDLE_OBJ_INFO)VirtualAlloc(
				NULL,
				(Retnum + 5)*sizeof(HANDLE_OBJ_INFO),
				MEM_COMMIT,
				PAGE_READWRITE);
			if (pHandleInfo == NULL)
			{
				char buff[0xff];
				wsprintfA(buff, "VritualAlloc fail Error=%d \r\n", GetLastError());
				OutputDebugStringA(buff);
				return 0;
			}
			//˯�߷�ֹDeviceIoControlʧ��
			Sleep(500);
			DeviceIoControl(
				hFile,
				UK_QQUERYHANDLE,
				&Pid,
				sizeof(Pid),
				pHandleInfo,
				sizeof(HANDLE_OBJ_INFO)*(Retnum + 5),
				&Ret, NULL);

			if (Ret == 0)
			{
				VirtualFree(pHandleInfo, NULL, MEM_RELEASE);

				OutputDebugStringA("get handleInfo fail");
				return 0;
			}

			HandleNumber = Retnum + 5;
			pHandleList = pHandleInfo;
			//��ȡ����Handle��Ϣ֮��Ӧ����Ӧ�ò㴦���������ӣ���������Ͳ������ˣ���Ϊ�����������ڴ��
		}
		else
		{
			TCHAR temp1[0x20];
			while (pDll != NULL)
			{
				if (pDll->Next != NULL)
				{
					PDLL_INFO temp;
					temp = pDll->Next;
					VirtualFree(pDll, NULL, MEM_RELEASE);
					pDll = temp;
				}
				else
				{
					VirtualFree(pDll, NULL, MEM_RELEASE);
					pDll = NULL;
				}
			}
			Retnum = NULL;
			MODULEENTRY32 modulelist;
			modulelist.dwSize = sizeof(MODULEENTRY32);
			hFile = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, Pid);
			if (hFile == INVALID_HANDLE_VALUE)
			{
				wsprintf(temp1, L"CreateToolHelp fail,LastError=%d", GetLastError());
				OutputDebugString(temp1);
				return 0;
			}

			if (!Module32First(hFile, &modulelist))
			{
				wsprintf(temp1, L"ModuleFirst fail,LastError=%d", GetLastError());
				OutputDebugString(temp1);
				CloseHandle(hFile);
				return 0;
			}
			pDll=(PDLL_INFO)VirtualAlloc(NULL, sizeof(DLL_INFO), MEM_COMMIT, PAGE_READWRITE);
			memset(pDll, 0, sizeof(DLL_INFO));
			pDll->hModule = modulelist.hModule;
			pDll->modBaseAddr = modulelist.modBaseAddr;
			pDll->modBaseSize = modulelist.modBaseSize;
			wcsncpy(pDll->szModule, modulelist.szModule, 0x40);
			wcsncpy(pDll->szExePath, modulelist.szExePath, MAX_PATH);
			Retnum++;
			PDLL_INFO LastDll;
			LastDll = pDll;
			while (Module32Next(hFile, &modulelist))
			{
				LastDll->Next = (PDLL_INFO)VirtualAlloc(
					NULL, 
					sizeof(DLL_INFO), 
					MEM_COMMIT, 
					PAGE_READWRITE);

				LastDll = LastDll->Next;
				memset(LastDll, 0, sizeof(DLL_INFO));
				LastDll->hModule = modulelist.hModule;
				LastDll->modBaseAddr = modulelist.modBaseAddr;
				LastDll->modBaseSize = modulelist.modBaseSize;
				wcsncpy(LastDll->szModule, modulelist.szModule, 0x40);
				wcsncpy(LastDll->szExePath, modulelist.szExePath, MAX_PATH);
				Retnum++;
			}
			HandleNumber = Retnum ;
			wsprintf(temp1, L"ModuleNumber=%d \r\n", Retnum);
			OutputDebugString(temp1);
			CloseHandle(hFile);
		}

		//���ù�������Ϣ
		si.nMin = 0;
		si.nMax = Retnum;
		si.fMask = SIF_PAGE | SIF_RANGE;
		si.nPage = (ClientRect.bottom - yBorder * 2) / yBorder;
		si.cbSize = sizeof(SCROLLINFO);
		SetScrollInfo(hwnd, SB_VERT, &si, TRUE);
		break;

	case WM_PAINT:
		HDC Dc, ComplateDc;
		HBITMAP ComBit;
		PERFORMANCE_INFORMATION info;
		WCHAR buffer[0xff];
		PAINTSTRUCT Ps;
		UINT iPos;
		HBRUSH brush, oldbrush;

		info.cb = sizeof(PERFORMANCE_INFORMATION);
		GetPerformanceInfo(&info, sizeof(PERFORMACE_INFORMATION));

		Dc = BeginPaint(hwnd, &Ps);
		ComplateDc = CreateCompatibleDC(Dc);
		ComBit = CreateCompatibleBitmap(Dc, ClientRect.right, ClientRect.bottom-yBorder);
		SelectObject(ComplateDc, ComBit);
//		BitBlt(Dc, 0, yBorder, ClientRect.right, ClientRect.bottom-yBorder, NULL, 0, 0, WHITENESS)



		SetBkMode(ComplateDc, TRANSPARENT);
		SetTextColor(ComplateDc, RGB(199, 79, 40));
		SelectObject(ComplateDc, GetStockObject(10));

		brush = CreateSolidBrush(RGB(225, 225, 225));			//��������������ˢ
		SelectObject(ComplateDc, brush);
		Rectangle(ComplateDc, Fullrect.left, Fullrect.top, Fullrect.right, Fullrect.bottom);
		DeleteObject(brush);

		//��ʾHandle��Ϣ
		iPos = GetScrollPos(hwnd, SB_VERT);


		if (bHandleAndDll)
		{
			//������ʾ�ڴ�����
			PHANDLE_OBJ_INFO Date;
			if (pHandleList != NULL)
			{
				Date = (PHANDLE_OBJ_INFO)((PCHAR)pHandleList + iPos*sizeof(HANDLE_OBJ_INFO));
				for (DWORD i = 0; i < ClientRect.bottom - yBorder * 2; i += yBorder)
				{

					wsprintf(buffer, L"%ws", Date->TypeName);
					TextOut(ComplateDc, 3, i, buffer, wcslen(buffer));

					wsprintf(buffer, L"%#x", Date->Handle);
					TextOut(ComplateDc, labelType + 3, i, buffer, wcslen(buffer));

					wsprintf(buffer, L"%#x", Date->Object);
					TextOut(ComplateDc, labelType + labelHand + 3, i, buffer, wcslen(buffer));

					wsprintf(buffer, L"%ws", wcschr(Date->Name, '\\'));
					TextOut(ComplateDc, labelType + labelHand + labelObj + 3, i, buffer, wcslen(buffer));

					//Ӧ�ò�û�и����� ������ƫ�Ʋ�����һ���ṹ��
					Date = (PHANDLE_OBJ_INFO)((PCHAR)Date + sizeof(HANDLE_OBJ_INFO));
				}
			}
		}
		else
		{
			if (pDll != NULL)
			{
				PDLL_INFO Date;
				Date = pDll;
				
				for (UINT i = 0; i < iPos; i++)
				{
					Date = Date->Next;
				}
				//����dll
				for (DWORD i = 0; i < ClientRect.bottom - yBorder * 2; i += yBorder)
				{
					if (Date != NULL)
					{
						wsprintf(buffer, L"%ws", Date->szModule);	//moduleName
						TextOut(ComplateDc, 3, i, buffer, wcslen(buffer));

						wsprintf(buffer, L"%#x", Date->modBaseSize);
						TextOut(ComplateDc, labelType + 3, i, buffer, wcslen(buffer));

						wsprintf(buffer, L"%#x", Date->modBaseAddr);
						TextOut(ComplateDc, labelType + labelHand + 3, i, buffer, wcslen(buffer));

						wsprintf(buffer, L"%ws", Date->szExePath);
						TextOut(ComplateDc, labelType + labelHand + labelObj + 3, i, buffer, wcslen(buffer));

						Date = Date->Next;
					}
				}
			}
		}

		wsprintf(buffer,
			L"������:%d  |  PageSize:%d B  |  �ύ(MB) %d/%d  |  ��ҳ/�Ƿ�ҳ(MB): %d/%d  |  ���ÿռ�/�ܿռ�(MB):%d/%d \0",
			info.ProcessCount,
			info.PageSize,
			info.CommitTotal*info.PageSize / 1024 / 1024,
			info.CommitLimit*info.PageSize / 1024 / 1024,
			info.KernelPaged*info.PageSize / 1024 / 1024,
			info.KernelNonpaged*info.PageSize / 1024 / 1024,
			info.PhysicalAvailable*info.PageSize / 1024 / 1024,
			info.PhysicalTotal*info.PageSize / 1024 / 1024
			);


		brush = CreateSolidBrush(RGB(20, 20, 20));
		oldbrush = (HBRUSH)SelectObject(ComplateDc, brush);
		Rectangle(ComplateDc, 0, ClientRect.bottom - yBorder * 2, ClientRect.right, ClientRect.bottom - yBorder);
		TextOut(ComplateDc, 0, ClientRect.bottom-yBorder*2, buffer, wcslen(buffer));
		SetBkMode(ComplateDc, OPAQUE);

		BitBlt(Dc,
			0,
			yBorder,
			ClientRect.right,
			ClientRect.bottom,
			ComplateDc, 0, 0, SRCCOPY);

		DeleteDC(ComplateDc);
		DeleteObject(ComBit);
		EndPaint(hwnd, &Ps);
		DeleteObject(SelectObject(ComplateDc, oldbrush));

		break;

	case WM_LBUTTONUP:
		x = LOWORD(lparam);
		y = HIWORD(lparam);
		
		Fullrect.left = ClientRect.left;
		Fullrect.right = ClientRect.right;
		Fullrect.top = y / 15 * 15 - yBorder;
		Fullrect.bottom = Fullrect.top + 15;
		InvalidateRect(hwnd, NULL, FALSE);
		break;
		//�������¼�

	case WM_LBUTTONDBLCLK:

		if (bHandleAndDll)
		{
			struct Index_point
			{
				DWORD Index;
				PVOID Info;
			}tempstruct;

			y = HIWORD(lparam);
			x = y / 15 - 1;
			iPos = GetScrollPos(hwnd, SB_VERT);
			iPos += x;

			tempstruct.Index = iPos;
			tempstruct.Info = pHandleList;
			DialogBoxParam((HINSTANCE)GetWindowLong(hwnd, GWL_HINSTANCE), MAKEINTRESOURCE(IDD_SubInfoSub), hwnd, (DLGPROC)SubWinSub, (LPARAM)&tempstruct);
		}
		break;
	case WM_MOUSEWHEEL:
		static int temp;
		if (WheelPos == 0)
			break;

		temp += (short)HIWORD(wparam);	//120 or -120
		while (temp >= WheelPos)
		{
			SendMessage(hwnd, WM_VSCROLL, SB_LINEUP, 0);
			temp -= WheelPos;
		}
		while (temp <= -WheelPos)
		{
			SendMessage(hwnd, WM_VSCROLL, SB_LINEDOWN, 0);
			temp += WheelPos;
		}
		return 0;

	case WM_CLOSE:
		if (pHandleList)
			VirtualFree(pHandleList, NULL, MEM_RELEASE);
		EndDialog(hwnd, 0);
		return 0;
	}
	return 0;
}

DLGPROC CALLBACK SubWinSub(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	static DWORD Index;
	static PHANDLE_OBJ_INFO pHandleList;
	WCHAR buffer[0xff];
	
	switch (msg)
	{
	case WM_INITDIALOG:
		Index = *(PULONG)lparam;
		pHandleList = (PHANDLE_OBJ_INFO)(*(PULONG)(lparam + 4));

		pHandleList = (PHANDLE_OBJ_INFO)((PCHAR)pHandleList + Index*sizeof(HANDLE_OBJ_INFO));

		wsprintf(buffer, L"NonPagePoolUsage: %d", pHandleList->NonPagedPoolUsage); //2
		SetWindowText(GetDlgItem(hwnd, IDC_STATIC2), buffer);

		wsprintf(buffer, L"PagePoolUsage: %d", pHandleList->PagedPoolUsage);
		SetWindowText(GetDlgItem(hwnd, IDC_STATIC3), buffer);

		wsprintf(buffer, L"ReferenceCount: %d", pHandleList->ReferenceCount);
		SetWindowText(GetDlgItem(hwnd, IDC_STATIC4), buffer);

		wsprintf(buffer, L"HandleCount: %d", pHandleList->HandleCount);
		SetWindowText(GetDlgItem(hwnd, IDC_STATIC5), buffer);

		wsprintf(buffer, L"Object: %#x", pHandleList->Object);		//6
		SetWindowText(GetDlgItem(hwnd, IDC_STATIC6), buffer);

		wsprintf(buffer, L"Handle: %#x", pHandleList->Handle);
		SetWindowText(GetDlgItem(hwnd, IDC_STATIC7), buffer);

		wsprintf(buffer, L"TypeIndex: %d", pHandleList->TypeIndex);
		SetWindowText(GetDlgItem(hwnd, IDC_STATIC8), buffer);

		wsprintf(buffer, L"Flags: %d", pHandleList->Flags);
		SetWindowText(GetDlgItem(hwnd, IDC_STATIC9), buffer);

		wsprintf(buffer, L"Name: %ws", pHandleList->Name);
		SetWindowText(GetDlgItem(hwnd, IDC_EDIT1), buffer);
		break;


	case WM_CLOSE:
		EndDialog(hwnd, 0);
		break;
	}
	return 0;
}

#define PACKET_START	1
#define PACKET_STOP		2

PTHREAD_START_ROUTINE GetPacketThread(void* param)
{
	OutputDebugStringA("Get DataPacket thread Start");
	while (TRUE)
	{
		Sleep(1000);
	}
	return 0;
}


DLGPROC CALLBACK PacketFilterWin(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	static HANDLE hFile;
	RECT RectClient;
	DWORD State;
	static HANDLE hThread;

	WCHAR szEndPath[MAX_PATH] = { 0 };
	switch (msg)
	{
	case WM_INITDIALOG:
		GetClientRect(hwnd, &RectClient);
		MoveWindow(GetDlgItem(hwnd, IDC_EDIT1), 0, 0, RectClient.right, RectClient.bottom / 2 - 10, FALSE);
		MoveWindow(GetDlgItem(hwnd, IDC_EDIT2), 0, RectClient.bottom / 2, RectClient.right, RectClient.bottom / 2 - 10, FALSE);
		NdisRaiseDriverPrivilege(TRUE);		//��Ȩ
		wcscpy_s(szEndPath, szDriverExePath);


		WCHAR szDriver[MAX_PATH];
		wsprintf(szDriver, L"\\\\.\\%s\0", szNdisDriverName);	//R3�����ļ�·��

			//�ж��Ƿ����ļ������û���Ǿʹ��������ļ�
			hFile = CreateFile(szDriver, GENERIC_READ, 0, 0, OPEN_EXISTING, 0, 0);
			if (hFile == INVALID_HANDLE_VALUE)
			{
				DWORD dwError = GetLastError();
				if (dwError != ERROR_INVALID_PARAMETER)	//���ǲ�������ʼ����sys
				{
				WhileLoadDriver:

					if (!NdisReleaseDriver(szEndPath, szNdisDriverName))		//��дsys�ļ�
					{
						OutputDebugString(L"Ndis ReleaseDriver error\r\n");
					}

					if (NdisLoadDriver(szEndPath, szNdisDriverName))			//����ע�������������
					{
						wsprintf(szDriver, L"\\\\.\\%s\0", szNdisDriverName);
						HANDLE hDriver = CreateFile(szDriver, GENERIC_READ | GENERIC_WRITE, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_SYSTEM, 0);
						if (hDriver != INVALID_HANDLE_VALUE)
						{
							wcsncat_s(szWin32DriverName,
								0x20 - wcslen(szWin32DriverName),
								szNdisDriverName,
								wcslen(szNdisDriverName));

							CloseHandle(hDriver);
						}
						else
						{
							ULONG Error = GetLastError();
							NdisUnLoadDriver(szEndPath, szNdisDriverName);	//��ʱʧ�ܣ�ж������
						}
					}
					else
					{
						NdisUnLoadDriver(szEndPath, szNdisDriverName);		//����ʱʧ�ܣ�ж������
					}
					NdisDeleteDriverFile(szEndPath, szNdisDriverName);		//ɾ�������ļ�

				}
			}
			else
			{
				//����Ѿ����ڣ���ô���Դ���������汾�ŵȡ��ж��Ƿ�Ҫ���¼���
				if (0)	//�����ǲ���Ҫ���ص����
				{
					OutputDebugString(TEXT("Open Driver Success"));
				}
				else
				{
					//��������Ҫ���ص����
					CloseHandle(hFile);
					goto WhileLoadDriver; //������ת�����س���
				}
			}


		NdisRaiseDriverPrivilege(FALSE);
		break;

	case WM_MOVE:
		GetClientRect(hwnd, &RectClient);
		MoveWindow(GetDlgItem(hwnd, IDC_EDIT1), 0, 0, RectClient.right, RectClient.bottom / 2 - 10, FALSE);
		MoveWindow(GetDlgItem(hwnd, IDC_EDIT2), 0, RectClient.bottom / 2, RectClient.right, RectClient.bottom / 2 - 10, FALSE);
		break;

	case WM_PAINT:

		break;
	case WM_CLOSE:
		NdisRaiseDriverPrivilege(TRUE);		//��Ȩ
		NdisReleaseDriver(szDriverExePath, szNdisDriverName);
		NdisUnLoadDriver(szDriverExePath, szNdisDriverName);
		NdisDeleteDriverFile(szDriverExePath, szNdisDriverName);
		NdisRaiseDriverPrivilege(FALSE);
		EndDialog(hwnd, 0);
		break;
	}

	return 0;
}