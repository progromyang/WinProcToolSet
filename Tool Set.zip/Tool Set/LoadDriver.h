#pragma once
#include"RaisePower.h"
#include"GlobleVariable.h"
#include<string.h>
#include"FunctionTypedef.h"
#include"NdisLoad.h"
#include<Shlwapi.h>

#pragma comment(lib,"Shlwapi.lib")
void DeleteDriverFile(PWCHAR, PWCHAR);
PWCHAR GetRandDriverName(PWCHAR, PWCHAR);
void UnLoadDriver(PWCHAR, PWCHAR);



//ע�������������
BOOL LoadDriver(PWCHAR szPath, PWCHAR szDriverName)
{
	ULONG status;
	WCHAR TempBuffer[MAX_PATH];
	BOOL bLoadDriverOk = FALSE;
	WCHAR szNtdll[] = { L"ntdll.dll\0" };
	HMODULE hNtdll = GetModuleHandle(szNtdll);

	if (hNtdll == NULL)
	{
		return bLoadDriverOk;
	}

	CHAR szZwLoadDriver[] = { "ZwLoadDriver\0" };

	pfnZwLoadDriver ZwLoadDriver = (pfnZwLoadDriver)GetProcAddress(hNtdll, szZwLoadDriver);
	pfnRtlAnsiStringToUnicodeString RtlAnsiStringToUnicodeString =
		(pfnRtlAnsiStringToUnicodeString)GetProcAddress(hNtdll, "RtlAnsiStringToUnicodeString");
	pfnRtlFreeUnicodeString RtlFreeUnicodeString = 
		(pfnRtlFreeUnicodeString)GetProcAddress(hNtdll, "RtlFreeUnicodeString");
	pfnRtlUnicodeString RtlUnicodeString =
		(pfnRtlUnicodeString)GetProcAddress(hNtdll, "RtlInitUnicodeString");


	if (ZwLoadDriver == NULL)
	{
		OutputDebugStringA("GetAddress(ZwLoadDriver) Error");
		return bLoadDriverOk;
	}
	if (RtlAnsiStringToUnicodeString == NULL)
	{
		OutputDebugStringA("GetAddress(RtlAnsiStringToUnicodeString) Error");
		return bLoadDriverOk;
	}
	if (RtlUnicodeString == NULL)
	{
		OutputDebugStringA("GetAddress(RtlUnicodeString) Error");
		return bLoadDriverOk;
	}

	WCHAR szDriverPath[MAX_PATH];
	wsprintf(szDriverPath, L"\\??\\%s\\%s.sys\0", szPath, szDriverName);

	WCHAR szKey[MAX_PATH];
	wsprintf(szKey, L"System\\CurrentControlSet\\Services\\%s", szDriverName);
	HKEY hKey;

	if (RegCreateKey(HKEY_LOCAL_MACHINE, szKey, &hKey) != ERROR_SUCCESS)
	{
		return bLoadDriverOk;
	}
	
	wsprintf(TempBuffer, L"ZwLoadDriver: 0x%08X\r\n", ZwLoadDriver);
	OutputDebugString(TempBuffer);
	DWORD Data = 1;
	DWORD StartType = 3;	//�ֶ�
	WCHAR szType[] = { L"Type\0" };
	WCHAR szErrorControl[] = { L"ErrorControl\0" };
	WCHAR szStart[] = { L"Start\0" };
	WCHAR szImagePath[] = { L"ImagePath\0" };
	
	RegSetValueEx(hKey, szType, 0, REG_DWORD, (BYTE*)&Data, sizeof(DWORD));
	RegSetValueEx(hKey, szErrorControl, 0, REG_DWORD, (BYTE*)&Data, sizeof(DWORD));
	//0,��������������������,1�����ɲ���ϵͳ��I/O��ϵͳ���أ��ں˳�ʼ��ʱ��
	//2�����������������,3�ֶ���4 ����
	RegSetValueEx(hKey, szStart, 0, REG_DWORD, (BYTE*)&StartType, sizeof(DWORD));
	RegSetValueEx(hKey, szImagePath, 0, REG_SZ, (BYTE*)szDriverPath, wcslen(szDriverPath)*sizeof(WCHAR));
	RegCloseKey(hKey);

	WCHAR szKeyTemp[MAX_PATH];
	wsprintf(szKeyTemp, L"\\Registry\\Machine\\System\\CurrentControlSet\\Services\\%s\0", szDriverName);
	//sprintf_s(szKeyTemp, "\\Registry\\Machine\\System\\CurrentControlSet\\Services\\ToolSet\0");//, szDriverName);
	UNICODE_STRING	unDriverPath;
	//memset(&unDriverPath, 0, sizeof(UNICODE_STRING));
	RtlUnicodeString(&unDriverPath, szKeyTemp);

//	ANSI_STRING		ansiDriverPath;
//	ansiDriverPath.Buffer = szKeyTemp;
//	ansiDriverPath.Length = strlen(szKeyTemp);
//	ansiDriverPath.MaximumLength = ansiDriverPath.Length;
//	RtlAnsiStringToUnicodeString(&unDriverPath, &ansiDriverPath, 1);
	
	
	
	//��������
	if (IsWow32)
	{
		Wow64EnableWow64FsRedirection(FALSE);
		status = ZwLoadDriver(&unDriverPath);
		Wow64EnableWow64FsRedirection(TRUE);
	}
	else
	{
		status = ZwLoadDriver(&unDriverPath);
	}
//	RtlFreeUnicodeString(&unDriverPath);

	wsprintf(TempBuffer, L"ZwLoadDriver status 0x%08X\r\n", status);
	OutputDebugString(TempBuffer);
	
	if (!status)
	{
		bLoadDriverOk = TRUE;
	}
	else if (STATUS_INVALID_DISPOSITION == status)
	{
		MessageBox(NULL,
			L"Your system has just installed the windows updates, \r\nplease reboot your system at frist.",
			szDriverName,
			MB_OK | MB_ICONINFORMATION);

		DeleteFile(szDriverPath);

		ExitProcess(0);
	}
	WCHAR szEnmu[MAX_PATH];
	wcscpy_s(szEnmu, szKey);
	wcscat_s(szEnmu, L"\\Enum\0");
	RegDeleteKey(HKEY_LOCAL_MACHINE, szEnmu);

	WCHAR szSecurity[MAX_PATH];
	wcscpy_s(szSecurity, szKey);
	wcscat_s(szSecurity, L"\\Security\0");
	RegDeleteKey(HKEY_LOCAL_MACHINE, szSecurity);

	RegDeleteKey(HKEY_LOCAL_MACHINE, szKey);

	return bLoadDriverOk;
}

//��̬����sys�ļ�
BOOL ReleaseDriver(LPWSTR szPath, LPWSTR szDriverName)
{
	HANDLE hFile = INVALID_HANDLE_VALUE;
	BOOL ret = FALSE;

	//���Ϊ��
	if (!wcslen(szPath) || !wcslen(szDriverName))
	{
		OutputDebugStringA("empty Path or Name\r\n");
		return ret;
	}
	WCHAR szComplatePath[MAX_PATH];
	wsprintf(szComplatePath, L"%s\\%s.sys\0", szPath, szDriverName);
	if (IsWow32)
	{
		Wow64EnableWow64FsRedirection(FALSE);		//�����ض���
		DeleteFile(szComplatePath);

		hFile = CreateFile(szComplatePath,
			GENERIC_WRITE,
			FILE_SHARE_READ,
			NULL,
			CREATE_ALWAYS,
			FILE_ATTRIBUTE_NORMAL,
			NULL);
		Wow64EnableWow64FsRedirection(TRUE);
	}
	else
	{
		DeleteFile(szComplatePath);

		hFile = CreateFile(szComplatePath,
			GENERIC_WRITE,
			FILE_SHARE_READ,
			NULL,
			CREATE_ALWAYS,
			FILE_ATTRIBUTE_NORMAL|FILE_ATTRIBUTE_SYSTEM|FILE_ATTRIBUTE_HIDDEN
			,
			NULL);
	}



	if (hFile != INVALID_HANDLE_VALUE)
	{
		WCHAR szLog[MAX_PATH];
		wsprintf(szLog, L"CreateFile: %s Success\r\n", szDriverName);
		OutputDebugString(szLog);

		//���￪ʼ����������Դ .sys
		HRSRC hRsc = FindResource(NULL, MAKEINTRESOURCE(IDR_DRIVER), L"KERNEL\0");	//��sys��ΪKERNEL�������Դ
		if (hRsc)
		{
			DWORD dwResSize = SizeofResource(NULL, hRsc);	//��Դ��С
			if (dwResSize > 0)
			{
				HGLOBAL hResData = LoadResource(NULL, hRsc);
				if (hResData != NULL)
				{
					LPVOID lpResrouceData = LockResource(hResData);
					if (lpResrouceData != NULL)
					{
						PVOID pBuffer = malloc(dwResSize);
						if (pBuffer)
						{
							memset(pBuffer, 0, dwResSize);
							memcpy(pBuffer, lpResrouceData, dwResSize);

							//DecryptResource ���԰�sysд�ɼ��ܵģ�������Խ���

							DWORD dwRet;
							if (WriteFile(hFile, pBuffer, dwResSize, &dwRet, NULL))
							{
								ret = TRUE;
							}
							free(pBuffer);			//�ͷ�
							pBuffer = NULL;
						}
						FreeResource(hResData);		//Ҫ�ǵ��ͷ���Դ
					}
				}
			}
		}
		else
		{
			OutputDebugStringA("Find Resource fail\r\n");
		}
	}
	if (hFile != INVALID_HANDLE_VALUE)
	{
		CloseHandle(hFile);
	}
	if (!ret)
	{
		if (IsWow32)
		{
			Wow64EnableWow64FsRedirection(FALSE);
			DeleteFile(szComplatePath);
			Wow64EnableWow64FsRedirection(TRUE);
		}
		else
		{
			DeleteFile(szComplatePath);
		}
	}
	return ret;
}

//����·��֮�����LoadDriver
BOOL StartDriver()
{
	BOOL bRet = FALSE;

	if (!GetModuleFileName(NULL, szDriverExePath, MAX_PATH))
	{
		return FALSE;
	}

	//����������
	WCHAR *szProcName = wcsrchr(szDriverExePath, '\\');

	PWCHAR szDir = wcschr(szDriverExePath, '\\');
	szDir++;
	WCHAR szEndPath[MAX_PATH] = { 0 };

	if (0)//GetDriveType(szDir) != DRIVE_FIXED)
	{
		WCHAR szDest[MAX_PATH] = { 0 };
		GetSystemDirectory(szDest, MAX_PATH);
		ULONG nSysDir = wcslen(szDest);
		WCHAR szDrivers[] = { L"\\drivers\0" };
		wcsncat_s(szDest, szDrivers, MAX_PATH - nSysDir);
		wcscpy_s(szEndPath, szDest);

	}
	else
	{
		if (szProcName)
			*szProcName = L'\0';

		wcscpy_s(szEndPath, szDriverExePath);
	}


	//���������������
	/*
	if (szProcName)
	{
		WCHAR *szDriverNameExt = szProcName + 1;
		WCHAR *szDriverNameTemp = wcschr(szDriverNameExt, '.');
		if (szDriverNameTemp)
			*szDriverNameTemp = 0;

		DWORD dwLen = wcslen(szDriverNameExt);
		if (dwLen > 0 && dwLen < 0x20)
		{
			memset(szDriverName, 0, 0x20 * sizeof(WCHAR));
			wcsncpy_s(szDriverName, 0x20, szDriverNameExt, 0x20 - 1);
		}
	}
	*/
	WCHAR szDriver[MAX_PATH];
	wsprintf(szDriver, L"\\\\.\\%s\0", szDriverName);	//R3�����ļ�·��

	//�ж��Ƿ����ļ������û���Ǿʹ��������ļ�
	HANDLE hFile = CreateFile(szDriver, GENERIC_READ, 0, 0, OPEN_EXISTING, 0, 0);
	if (hFile == INVALID_HANDLE_VALUE)
	{	
		DWORD dwError = GetLastError();
		if (dwError != ERROR_INVALID_PARAMETER)	//���ǲ�������ʼ����sys
		{
		WhileLoadDriver:

				if (!ReleaseDriver(szEndPath, szDriverName))		//��дsys�ļ�
				{
					OutputDebugString(L"ReleaseDriver error\r\n");
					return bRet;
				}

				if (LoadDriver(szEndPath, szDriverName))			//����ע�������������
				{
					wsprintf(szDriver, L"\\\\.\\%s\0", szDriverName);
					HANDLE hDriver = CreateFile(szDriver, GENERIC_READ|GENERIC_WRITE, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_SYSTEM, 0);
					if (hDriver != INVALID_HANDLE_VALUE)
					{
						wcsncat_s(szWin32DriverName,
							0x20 - wcslen(szWin32DriverName),
							szDriverName,
							wcslen(szDriverName));
						
						bRet = TRUE;
						CloseHandle(hDriver);
					}
					else
					{
						ULONG Error = GetLastError();
						UnLoadDriver(szEndPath, szDriverName);	//��ʱʧ�ܣ�ж������
					}
				}
				else
				{
					UnLoadDriver(szEndPath, szDriverName);		//����ʱʧ�ܣ�ж������
				}
				DeleteDriverFile(szEndPath, szDriverName);		//ɾ�������ļ�
				return bRet;

				/*.
				//�ض���
				if (IsWow32)
				{
					Wow64EnableWow64FsRedirection(FALSE);
					DeleteDriverFile(szEndPath, szDriverName);
		//			GetRandDriverName(szEndPath, szDriverName);	//����һ�������ڵ��ļ�·��
					Wow64EnableWow64FsRedirection(TRUE);
				}
				else
				{
					DeleteDriverFile(szEndPath, szDriverName);
					//			GetRandDriverName(szEndPath, szDriverName);	//����һ�������ڵ��ļ�·��
				}
				.*/
		}
	}
	else
	{
		//����Ѿ����ڣ���ô���Դ���������汾�ŵȡ��ж��Ƿ�Ҫ���¼���
		if (0)	//�����ǲ���Ҫ���ص����
		{
			OutputDebugString(TEXT("Open Driver Success"));
		}
		else
		{
			//��������Ҫ���ص����
			CloseHandle(hFile);
			goto WhileLoadDriver; //������ת�����س���
		}
	}

	return bRet;
}



BOOL InitDriver()
{
	BOOL bIsWow64 = FALSE;
//	IsWow64Process(GetCurrentProcess(), &bIsWow64);

	if (bIsWow64)
		OutputDebugString(TEXT("The current version does not support 64 bit Windows.\r\n"));
	else
	{
		//��������ȼ��Windwos�汾������Ƿ��������

		//��Ȩ
		if (!RaiseDebugPrivilege(TRUE) || !RaiseDriverPrivilege(TRUE))
			OutputDebugString(TEXT("Adjust Privilege Error\r\n"));
		else
		{
			//��������
			g_bLoadDriverOK = StartDriver();
			if (!g_bLoadDriverOK)
				MessageBox(NULL, TEXT("Driver Load fail"), TEXT("ERROR"), MB_OK | MB_ICONINFORMATION);
			RaiseDriverPrivilege(FALSE);
		}
		
		//����������سɹ���������Դ���pid�������������Ա������Լ�������Ϣ

	}
	return g_bLoadDriverOK;
}


void DeleteDriverFile(PWCHAR szPath, PWCHAR szDriverName)
{
	if (!wcslen(szPath) || !wcslen(szDriverName))
		return;

	WCHAR szDriverPath[MAX_PATH];
	wsprintf(szDriverPath, L"%s\\%s.sys\0",szPath,szDriverName);
	if (IsWow32)
	{
		Wow64EnableWow64FsRedirection(FALSE);
		if (PathFileExists(szDriverPath))
			DeleteFile(szDriverPath);
		Wow64EnableWow64FsRedirection(TRUE);
	}
	else
	{
		if (PathFileExists(szDriverPath))
			DeleteFile(szDriverPath);
	}

}

PWCHAR GetRandDriverName(PWCHAR szPath, PWCHAR szDriverName)
{
	PWCHAR szResult;
	if (wcslen(szPath) && wcslen(szDriverName))
	{
		Sleep(1);
		ULONG nTickCount = GetTickCount();
		srand(nTickCount);
		WCHAR szMzf[] = { L"minzhenfei\0" };
		UINT nlent = wcslen(szDriverName);
		int nTimes = (rand() & 10) + wcslen(szMzf);
		
		do
		{
			for (UINT i = 0; i < nlent; i++)
			{
				szDriverName[i] = (nTimes + rand()) % 26 + 97;
			}
			szDriverName[nlent] = 0;
			szResult = (PWCHAR)malloc(nlent+sizeof(WCHAR));
			wcscpy_s(szResult, nlent + sizeof(WCHAR), szDriverName);
		} while (PathFileExists(szResult));
	}
	return szResult;
}

void UnLoadDriver(PWCHAR szEndPath, PWCHAR szDriverName)
{
	WCHAR szNtdll[] = { L"ntdll.dll\0" };
	HMODULE hNtdll = GetModuleHandle(szNtdll);


	CHAR szZwUnLoadDriver[] = { "ZwUnloadDriver\0" };

	pfnZwLoadDriver ZwUnLoadDriver = (pfnZwLoadDriver)GetProcAddress(hNtdll, szZwUnLoadDriver);
	pfnRtlAnsiStringToUnicodeString RtlAnsiStringToUnicodeString =
		(pfnRtlAnsiStringToUnicodeString)GetProcAddress(hNtdll, "RtlAnsiStringToUnicodeString");
	pfnRtlFreeUnicodeString RtlFreeUnicodeString =
		(pfnRtlFreeUnicodeString)GetProcAddress(hNtdll, "RtlFreeUnicodeString");
	pfnRtlUnicodeString RtlUnicodeString =
		(pfnRtlUnicodeString)GetProcAddress(hNtdll, "RtlInitUnicodeString");


	WCHAR szKey[MAX_PATH];
	wsprintf(szKey, L"System\\CurrentControlSet\\Services\\%s",szDriverName);
	HKEY hKey;

	if (RegCreateKey(HKEY_LOCAL_MACHINE, szKey, &hKey) != ERROR_SUCCESS)
	{
		OutputDebugString(L"RegCreateKey fail\r\n");
		return;
	}


	DWORD Data = 1;
	WCHAR szType[] = { L"Type\0" };
	WCHAR szErrorControl[] = { L"ErrorControl\0" };
	WCHAR szStart[] = { L"Start\0" };
	WCHAR szImagePath[] = { L"ImagePath\0" };

	WCHAR szDriverPath[MAX_PATH];
	wsprintf(szDriverPath, L"\\??\\%s\\%s.sys\0", szEndPath,szDriverName);

	RegSetValueEx(hKey, szType, 0, REG_DWORD, (BYTE*)&Data, sizeof(DWORD));
	RegSetValueEx(hKey, szErrorControl, 0, REG_DWORD, (BYTE*)&Data, sizeof(DWORD));
	//�ֶ�����
	RegSetValueEx(hKey, szStart, 0, REG_DWORD, (BYTE*)&Data, sizeof(DWORD));
	RegSetValueEx(hKey, szImagePath, 0, REG_SZ, (BYTE*)szDriverPath, wcslen(szDriverPath)*sizeof(WCHAR));
	RegCloseKey(hKey);


	if (ZwUnLoadDriver == NULL || RtlAnsiStringToUnicodeString == NULL ||
		RtlFreeUnicodeString == NULL)
	{
		MessageBox(NULL, TEXT("GetAddress Error"), L"Error", MB_OK);
		return ;
	}
	WCHAR szKeyTemp[MAX_PATH];
//	sprintf_s(szKeyTemp, "\\Registry\\Machine\\System\\CurrentControlSet\\Services\\%s\0",szDriverName);
	wsprintf(szKeyTemp, L"\\Registry\\Machine\\System\\CurrentControlSet\\Services\\%s\0", szDriverName);
	UNICODE_STRING	unDriverPath;
//	ANSI_STRING		ansiDriverPath;

//	ansiDriverPath.Buffer = szKeyTemp;
//	ansiDriverPath.Length = strlen(szKeyTemp);
//	ansiDriverPath.MaximumLength = ansiDriverPath.Length;

//	RtlAnsiStringToUnicodeString(&unDriverPath, &ansiDriverPath, 1);
	ULONG status;
	RtlUnicodeString(&unDriverPath, szKeyTemp);
	status=ZwUnLoadDriver(&unDriverPath);
	if (status)
	{
		wsprintf(szKeyTemp, L"ZwUnloadDriver status= %x\r\n", status);
		OutputDebugString(szKeyTemp);
	}
//	RtlFreeUnicodeString(&unDriverPath);


	WCHAR szEnmu[MAX_PATH];
	wcscpy_s(szEnmu, szKey);
	wcscat_s(szEnmu, L"\\Enum\0");
	RegDeleteKey(HKEY_LOCAL_MACHINE, szEnmu);

	WCHAR szSecurity[MAX_PATH];
	wcscpy_s(szSecurity, szKey);
	wcscat_s(szSecurity, L"\\Security\0");
	RegDeleteKey(HKEY_LOCAL_MACHINE, szSecurity);

	RegDeleteKey(HKEY_LOCAL_MACHINE, szKey);
	return ;
}