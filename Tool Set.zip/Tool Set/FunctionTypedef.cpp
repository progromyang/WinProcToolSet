#include"FunctionTypedef.h"

//�������Ӵ���
//#define UK_PACKET\
//	(ULONG)CTL_CODE(FILE_DEVICE_UNKNOWN,0x903,METHOD_BUFFERED,FILE_WRITE_DATA|FILE_READ_DATA)



void GetProcessInformation()
{
	//	OVERLAPPED ol;
	//	HANDLE hEvent = CreateEvent(NULL, NULL, NULL, NULL);
	//�Ѿ�������100��������Ϣ�ڴ�
	static UINT localNumber = 100;
	HANDLE DriverFile;
	DWORD ProcessNumber, ret_len;
	LPVOID Procstruct;

	DriverFile = CreateFile(szWin32DriverName, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL,
		OPEN_EXISTING, FILE_ATTRIBUTE_SYSTEM, NULL);

	DeviceIoControl(DriverFile,
		UK_PROCESSINFORMATION,
		&ProcessNumber, sizeof(ProcessNumber),
		&ProcessNumber, sizeof(ProcessNumber),
		&ret_len, NULL);

	if (ProcessNumber + 5>localNumber)
	{
		VirtualFree(g_ProcstructLink, 0, MEM_RELEASE);
		//�����5��������Ϣ�ڴ棬�ں˸�����Ϣ�ڴ治�����
		Procstruct = VirtualAlloc(NULL,
			(ProcessNumber + 5)*sizeof(DefProcessStruct),
			MEM_COMMIT,
			PAGE_READWRITE);
		g_ProcstructLink = (PDefProcessStruct)Procstruct;
		localNumber = ProcessNumber + 5;
	}

	g_ProcNumber = ProcessNumber;


	DeviceIoControl(DriverFile,
		UK_PROCESSINFORMATION,
		NULL, NULL,
		(LPVOID)g_ProcstructLink, (ProcessNumber + 5)*sizeof(DefProcessStruct),
		&ret_len, NULL);

	PDefProcessStruct tempProcstruct = (PDefProcessStruct)g_ProcstructLink;

	EnterCriticalSection(&CriticalSec);
	for (ULONG i = 1; i < ProcessNumber; i++)
	{
		tempProcstruct->NextList = (PDefProcessStruct)((PBYTE)tempProcstruct + sizeof(DefProcessStruct));
		tempProcstruct = tempProcstruct->NextList;
	}
	LeaveCriticalSection(&CriticalSec);
	tempProcstruct->NextList = NULL;
	CloseHandle(DriverFile);

	return;
}

BOOL CALLBACK KeyBoark(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	KEYBOARD key;
	HANDLE DriverFile;
	DWORD ret_len;
	switch (msg)
	{
	case WM_INITDIALOG:
		return TRUE;

	case WM_COMMAND:
	{
		switch (LOWORD(wparam))
		{
		case IDOK:
			EnableWindow(GetDlgItem(hwnd, IDCANCEL), TRUE);
			EnableWindow(GetDlgItem(hwnd, IDOK), FALSE);
			key.DelayTime = GetDlgItemInt(hwnd, IDC_KEYBOARD, NULL, FALSE);
			key.Id = 1;
			SetDlgItemTextA(hwnd, IDC_INITSTATUS, "Initialize...");
			DriverFile = CreateFile(szWin32DriverName, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL,
				OPEN_EXISTING, FILE_ATTRIBUTE_SYSTEM, NULL);
			DeviceIoControl(DriverFile, UK_KEYBOARD, &key, sizeof(KEYBOARD), NULL, 0, &ret_len, NULL);
			CloseHandle(DriverFile);
			SetDlgItemTextA(hwnd, IDC_INITSTATUS, "Init Access");
			break;

		case IDCANCEL:
			EnableWindow(GetDlgItem(hwnd, IDCANCEL), FALSE);
			EnableWindow(GetDlgItem(hwnd, IDOK), TRUE);
			key.Id = 2;
			DriverFile = CreateFile(szWin32DriverName, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL,
				OPEN_EXISTING, FILE_ATTRIBUTE_SYSTEM, NULL);
			DeviceIoControl(DriverFile, UK_KEYBOARD, &key, sizeof(KEYBOARD), NULL, 0, &ret_len, NULL);
			CloseHandle(DriverFile);
			SetDlgItemTextA(hwnd, IDC_INITSTATUS, "Cancel");
			break;
		}
		return TRUE;
	}

	case WM_CLOSE:
		//��ȡ��ť״̬
		if (IsWindowEnabled(GetDlgItem(hwnd, IDCANCEL)) == TRUE)
			SendMessage(hwnd, WM_COMMAND, 2, 0);

		EndDialog(hwnd, 0);
		return TRUE;
	}
	return FALSE;
}

//�ҳ������е�N���ṹ��
PDefProcessStruct FindProcNumber(ULONG N)
{
	PDefProcessStruct Proc;
	Proc = g_ProcstructLink;
	for (ULONG i = 0; i < N; i++)
	{
		Proc = Proc->NextList;
	}
	return Proc;
}

unsigned int GetProcessMemoryUse(ULONG N, PPROCESS_MEMORY_COUNTERS Memory)
{
	HANDLE Handle;
	PDefProcessStruct TempProc;
	TempProc = FindProcNumber(N);
	(HANDLE)TempProc->Pid;
	Handle = OpenProcess(PROCESS_ALL_ACCESS, NULL, TempProc->Pid);
	GetProcessMemoryInfo(Handle, Memory, sizeof(PROCESS_MEMORY_COUNTERS));
	CloseHandle(Handle);
	return Memory->cb;
}