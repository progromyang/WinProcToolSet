#pragma once
#include<Windows.h>

BOOL RaiseDebugPrivilege(BOOL bEnable);

BOOL RaiseDriverPrivilege(BOOL bEnable);