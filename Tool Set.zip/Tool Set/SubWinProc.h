#pragma once
#include<Windows.h>
#include<CommCtrl.h>
#include<Psapi.h>
#include"ProcessInfoList.h"
#include"resource.h"

extern BOOL g_bLoadDriverOK;
extern WCHAR szWin32DriverName[0x20];			//����������غ����������·��
extern BOOL IsWow32;							//���л���
extern WCHAR szDriverExePath[MAX_PATH];			//����·��
extern WCHAR szDriverName[0x20];				//��������
extern PDefProcessStruct	g_ProcstructLink;	//��������
extern ULONG				g_ProcNumber;				//��������
extern CRITICAL_SECTION		CriticalSec;				//�ٽ���
extern BOOL bHandleAndDll;
extern WCHAR szNdisDriverName[0x20]; 	//PackFilterDriver

#define WM_DATEUPHANDLEINFO		WM_USER+1
#define MAXNAME		0x20
#define UK_QURYPORTINFO	\
	CTL_CODE(FILE_DEVICE_UNKNOWN,0xA00,METHOD_BUFFERED,FILE_ANY_ACCESS)

#define UK_QQUERYHANDLE	\
	CTL_CODE(FILE_DEVICE_UNKNOWN,0xA01,METHOD_BUFFERED,FILE_ANY_ACCESS)

#define UK_PACKET\
	(ULONG)CTL_CODE(FILE_DEVICE_UNKNOWN,0x903,METHOD_BUFFERED,FILE_WRITE_DATA|FILE_READ_DATA)

extern WCHAR szWin32DriverName[0x20];
extern unsigned int GetProcessMemoryUse(ULONG N, PPROCESS_MEMORY_COUNTERS Memory);
DLGPROC CALLBACK SubWinSub(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
//PacketfilterWindow
DLGPROC CALLBACK PacketFilterWin(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
#define WIN_PERFORMANCE 0
#define WIN_MEMORY		1


static TCHAR Performance[14][0x1f] = {
	L"CommitTotal\0",
	L"CommitLimit\0",
	L"CommitPeak\0",
	L"PhysicalTotal\0",
	L"PhysicalAvailable\0",
	L"SystemCache\0",
	L"KernelTotal\0",
	L"KernelPaged\0",
	L"KernelNonpaged\0",
	L"PageSize\0",
	L"HandleCount\0",
	L"ProcessCount\0",
	L"ThreadCount\0",
	L"\0"
};

static TCHAR ProcMemory[10][0x2f] = {
	L"PageFaultCount\0",
	L"PeakWorkingSetSize\0",
	L"WorkingSetSize\0",
	L"QuotaPeakPagedPoolUsage\0",
	L"QuotaPagedPoolUsage\0",
	L"QuotaPeakNonPagedPoolUsage\0",
	L"QuotaNonPagedPoolUsage\0",
	L"PagefileUsage\0",
	L"PeakPagefileUsage\0",
	L"\0"
};
DLGPROC CALLBACK TabProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);


static WCHAR *szConnectStatus[] = {
	L"UNKNOW",
	L"CLOSED",
	L"LISTENING",
	L"SYN_SENT",
	L"SYN_RECEIVED",
	L"ESTABLISHED",
	L"FIN_WAIT1",
	L"FIN_WAIT2",
	L"CLOSE_WAIT",
	L"CLOSING",
	L"LAST_ACK",
	L"TIME_WAIT",
};

static char* szProType[]={
	"Tcp\0",
	"Udp\0",
};

typedef enum _PORT_TYPE
{
	enumTcp,
	enumUdp,
}PORT_TYPE;

typedef struct _PORT_INFO
{
	PORT_TYPE nPorttype;
	ULONG nConnectState;
	ULONG nLocalAddress;
	ULONG nLocalPort;
	ULONG nRemoteAddress;
	ULONG nRemotePort;
	ULONG nPid;
}PORT_INFO, *PPORT_INFO;

typedef struct _COMMUNICATE_PORT
{
	ULONG nCnt;
	PORT_INFO Ports[1];
}COMMUNICATE_PORT, *PCOMMUNICATE_PORT;

//Handle��Ϣ�ṹ��
typedef struct _HANDLE_OBJ_INFO
{
	LIST_ENTRY List;
	PVOID	Object;
	USHORT	Handle;
	UCHAR	Flags;
	UCHAR	TypeIndex;
	ULONG	HandleCount;
	ULONG	ReferenceCount;
	ULONG	PagedPoolUsage;
	ULONG	NonPagedPoolUsage;
	WCHAR	TypeName[0x40];
	WCHAR	Name[0x200];
}HANDLE_OBJ_INFO, *PHANDLE_OBJ_INFO;

typedef struct _DLL_INFO
{
	_DLL_INFO* Next;
	BYTE    *modBaseAddr;
	DWORD   modBaseSize;
	HMODULE hModule;				//�������̵ľ�� ����BaseAdd��ֵ
	TCHAR   szModule[40];
	TCHAR   szExePath[MAX_PATH];

}DLL_INFO,*PDLL_INFO;

DLGPROC CALLBACK PortProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam);
DLGPROC CALLBACK SubWinInfo(HWND, UINT, WPARAM, LPARAM);

typedef enum _HANDLE_TYPE_INDEX
{
	OB_TYPE_UNKNOWN,
	OB_TYPE_TYPE,
	OB_TYPE_DIRECTORY,
	OB_TYPE_SYMBOLIC_LINK,
	OB_TYPE_TOKEN,
	OB_TYPE_PROCESS,
	OB_TYPE_THREAD,
	OB_TYPE_JOB,
	OB_TYPE_EVENT,
	OB_TYPE_EVENT_PAIR,
	OB_TYPE_MUTANT,
	OB_TYPE_CALLBACK,
	OB_TYPE_SEMAPHORE,
	OB_TYPE_TIMER,
	OB_TYPE_PROFILE,
	OB_TYPE_WINDOW_STATION,
	OB_TYPE_DESKTOP,
	OB_TYPE_SECTION,
	OB_TYPE_KEY,
	OB_TYPE_PORT,
	OB_TYPE_WAITABLE_PORT,
	OB_TYPE_ADAPTER,
	OB_TYPE_CONTROLLER,
	OB_TYPE_DEVICE,
	OB_TYPE_DRIVER,
	OB_TYPE_IO_COMPLETION,
	OB_TYPE_FILE,
	OB_TYPE_GUID
}HANDLE_TYPE_INDEX;

static WCHAR *HandleTypeName[]{
	L"unknown\0",
		L"ObjType\0",
		L"Directory\0",
		L"SymbolicLink\0",		//3
		L"Token\0",
		L"Process\0",
		L"Thread\0",
		L"Job\0",
		L"Debug\0"
		L"Event\0",
		L"EventPair\0",
		L"Mutant\0",
		L"CallBack\0",
		L"Semaphore\0",
		L"Timer\0",
		L"Profile\0",
		L"Keyed_Event"
		L"WindowStation\0",
		L"DeskTop\0",
		L"Section\0",
		L"Key\0",			//20
		L"Port\0",
		L"WaitablePort\0",
		L"Adapter\0",
		L"Controller\0",
		L"Device\0",
		L"Driver\0",
		L"IoCompletion\0",
		L"File\0",			//28
		L"WmiGuid\0",		//29
};

typedef struct _SINGLE_LIST
{
	_SINGLE_LIST *Next;
}SINGLE_LIST,*PSINGLE_LIST;

//Tree struct 
typedef struct _TREESTRUCT
{
	PSINGLE_LIST list;
	HWND staticText;
	BOOL Spread;			//�Ƿ�չ��
	WCHAR Text[MAXNAME];
}TREESTRUCT,*PTREESTRUCT;