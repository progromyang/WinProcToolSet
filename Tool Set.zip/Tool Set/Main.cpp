#include"GetCpuRate.h"
#include"SubWinProc.h"
#include<TlHelp32.h>
#include<tchar.h>
#include<stdio.h>
#include"resource.h"
#include"GlobleVariable.h"
#include"RaisePower.h"

#include"LoadDriver.h"

#include<locale.h>
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

//������Ϣ����
static PLIST_ENTRY ProcInfoList = (PLIST_ENTRY)malloc(sizeof(LIST_ENTRY));


//������
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE ThInstance, PSTR szCmdLin, int iCmdShow)
{
	setlocale(LC_ALL, "chs");
	OSVERSIONINFOA OsVersion;
	OsVersion.dwOSVersionInfoSize = sizeof(OSVERSIONINFOA);
	GetVersionExA(&OsVersion);
//	_asm int 3
	IsWow64Process(GetCurrentProcess(), &IsWow32);
	//�ж��Ƿ�Ϊwin7 32bit
	if (IsWow32 || OsVersion.dwMajorVersion != 6 || OsVersion.dwMinorVersion != 1)
	{
		MessageBox(NULL, TEXT("�˳�����ֻ֧��win7 32bit����"), TEXT("Version Error"), MB_OK);
		return 0;
	}
	if (!InitDriver())
	{
		MessageBox(NULL, TEXT("�������ش���"), TEXT("Error"), MB_OK);
		
		return 0;
	}
	
	HWND hwnd;
	MSG Msg;
	WNDCLASS wndclass;
	ZeroMemory(ProcInfoList, sizeof(LIST_ENTRY));
	ProcInfoList->Flink = ProcInfoList;		//��ʼ����

	static TCHAR szAppName[256] = TEXT("ToolSet");
	
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wndclass.hCursor = LoadCursor(hInstance, IDC_ARROW);
	wndclass.hIcon = LoadIcon(hInstance, IDC_APPSTARTING);
	wndclass.hInstance = hInstance;
	wndclass.lpfnWndProc = WndProc;
	wndclass.lpszClassName = szAppName;
	wndclass.lpszMenuName = NULL;
	wndclass.style = CS_VREDRAW | CS_HREDRAW | CS_DBLCLKS;

	
	RegisterClass(&wndclass);
	hwnd = CreateWindow(szAppName, 
		TEXT("Tool Set"),
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT,
		CW_USEDEFAULT, 
		CW_USEDEFAULT, 
		CW_USEDEFAULT, 
		NULL, 
		LoadMenu(hInstance, MAKEINTRESOURCE(MAIN_MENU)), 
		hInstance, 
		NULL);


	UpdateWindow(hwnd);
	ShowWindow(hwnd, iCmdShow);
	while (GetMessage(&Msg, NULL, 0, 0))
	{
		TranslateMessage(&Msg);
		DispatchMessage(&Msg);

		/*
		if (Msg.message == 512)
		{
			Msg.hwnd = hwnd;
			DispatchMessage(&Msg);  //ʹ�����ڿ��Խ��յ��Ӵ��ڰ�ťMOUSEMOVE�¼�
		}
		*/
	}
	return Msg.wParam;
}


//�����ڹ���
LRESULT CALLBACK WndProc(HWND hwnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	DWORD iret;
	static HINSTANCE hInstance;
	static HWND hSubWinInfo;
	static BOOL MouseEvent=FALSE;
	static int MouseX, MouseY;			//����ƶ�����
#define ID_ProcButton	1
#define ID_PidButton	2
#define ID_Cpubutton	3
#define ID_PathButton	4
#define ID_TotolInfo	5
#define ID_Scroll		10
#define GETCPUTIME		1

	static int BorderLine1 = 200, BorderLine2 = 80, BorderLine3 = 80;		//��ʼ���߽���
	int cxButton, cyButton;		//��굥������
	static int cxProcButton = 200, cyProcButton = 15;	//��ť����
	static RECT ClientRect;
	static RECT ButtonRect;		//��굥������
	HPEN hPen;			//����
	HBRUSH hBrush;				//��ˢ
	HDC hdc;
	PAINTSTRUCT ps;
	static HANDLE SanpshotHandle,hDevice;
	static LOGFONT lf;					//����ṹ
	static HFONT hFont, OldFont;		//������
	static int cxClient, cyClient;		//WM_SIZE
	static HWND ProcButtonhwnd, PidButtonhwnd, CpuButtonhwnd, PathButtonhwnd, TotolTexthwnd;	//��ť���

	static HWND MainVertScrollHnwd;		//���������
	static ULONG ScrollPos;				//���ù�����λ��
	SCROLLINFO si;
	int iVertPos, iHorzPos;				//��ȡ������λ��
//	static UINT ProcessNumber = 0;		//��������
	static int WheelPos;				//��ʼ������
	ULONG tempNumber;
	DWORD iPos;
	static int iSelection = ID_DLL_INFO; //

	switch (Msg)
	{
	case WM_CREATE:
		hInstance = (HINSTANCE)GetWindowLong(hwnd, GWL_HINSTANCE);

		//��ʼ���ٽ�������������Ϊ���������ٽ���
		InitializeCriticalSection(&CriticalSec);
		//������Ϊ������path��ť��С��ȡ�ͻ�����С
		GetClientRect(hwnd, &ClientRect);

		//�����5��������Ϣ�ڴ棬�ں˸�����Ϣ�ڴ治�����
		g_ProcstructLink = (PDefProcessStruct)VirtualAlloc(
			NULL,
			100 * sizeof(DefProcessStruct),
			MEM_COMMIT,
			PAGE_READWRITE);

		//********************��ʼ��������Ϣ����*******************//
		GetProcessInformation();


		//������ȡProcessInfoʱ�ӣ�CpuRate�߳�
		SetTimer(hwnd, GETCPUTIME, 1000, NULL);
//*********************************************

		//������ť����
		
		static LOGFONT lf;
		lf.lfWidth = 6;
		lf.lfHeight = 12;
		lf.lfWeight = 500;
		hFont = CreateFontIndirect(&lf);


		ProcButtonhwnd = CreateWindowA(
			"button", 
			"Process Name",
			WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
			0, 0, cxProcButton, cyProcButton, 
			hwnd, 
			(HMENU)ID_ProcButton, 
			hInstance, NULL);

		SendMessage(ProcButtonhwnd, WM_SETFONT, (WPARAM)hFont, 0);

	
	

		PidButtonhwnd = CreateWindowA("button",
			"Pid",
			WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
			cxProcButton, 0, BorderLine2, cyProcButton,
			hwnd,
			(HMENU)ID_PidButton,
			hInstance, NULL);
		SendMessage(PidButtonhwnd, WM_SETFONT, (WPARAM)hFont, 0);

		CpuButtonhwnd = CreateWindowA("button",
			"Cpu",
			WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
			BorderLine1+BorderLine2, 0, BorderLine3, cyProcButton,
			hwnd,
			(HMENU)ID_Cpubutton,
			hInstance, NULL
			);
		SendMessage(CpuButtonhwnd, WM_SETFONT, (WPARAM)hFont, 0);


		PathButtonhwnd = CreateWindowA("button",
			"Path",
			WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
			BorderLine1 + BorderLine2 + BorderLine3,
			0,
			ClientRect.right - (BorderLine1 + BorderLine2 + BorderLine3), cyProcButton,
			hwnd, (HMENU)ID_PathButton, hInstance, NULL);
		


		SendMessage(PathButtonhwnd, WM_SETFONT, (WPARAM)hFont, 0);


		hSubWinInfo = CreateDialog(
			hInstance,
			MAKEINTRESOURCE(IDD_SubInfo),
			hwnd,
			(DLGPROC)SubWinInfo);
		ShowWindow(hSubWinInfo, SW_SHOWNORMAL);

		SendMessage(hSubWinInfo, WM_SETFONT, (WPARAM)hFont, 0);

		//��ѡmenuѡ��
		CheckMenuItem(GetMenu(hwnd), iSelection, MF_CHECKED);
//*********************************************//
		/*����������
		MainVertScrollHnwd = CreateWindow(
			TEXT("scrollbar"), 
			NULL, 
			WS_CHILD | WS_VISIBLE | WS_TABSTOP | SBS_VERT,
			0, 0, 0, 0, 
			hwnd, 
			(HMENU)ID_Scroll,
			hInstance, 
			NULL);
		*/
//		return 0;	����Create��Ϣʱ˳�㴦��SETTINGCHANGGE��Ϣ

		//������껬������
	case WM_SETTINGCHANGE:
		ULONG ScrollLine;
		SystemParametersInfo(SPI_GETWHEELSCROLLLINES, 0, &ScrollLine, 0);
		if (ScrollLine)
			WheelPos = WHEEL_DELTA / ScrollLine;
		else
			WheelPos = 0;
		return 0;


		//��ȡ�ͻ��Ĵ�С
	case WM_SIZE:
		cxClient = LOWORD(lParam);
		cyClient = HIWORD(lParam);


		si.cbSize = sizeof(si);
		si.fMask = SIF_RANGE | SIF_PAGE;
		si.nMin = 0;
		si.nMax = g_ProcNumber;
		si.nPage = cyClient / 15;
		SetScrollInfo(hwnd, SB_VERT, &si, TRUE);


		si.cbSize = sizeof(si);
		si.fMask = SIF_RANGE;// | SIF_PAGE;
		si.nMin = 0;
		si.nMax = 20;
//		si.nPage = cxClient / 20;
		SetScrollInfo(hwnd, SB_HORZ, &si, TRUE);
		MoveWindow(PathButtonhwnd, 
			BorderLine1 + BorderLine2 + BorderLine3, 0, 
			cxClient - (BorderLine1 + BorderLine2 + BorderLine3), cyProcButton, 
			FALSE);
		SendMessage(hSubWinInfo, WM_SIZE, 0, 0);
		return 0;

	case WM_MOVE:
		SendMessage(hSubWinInfo, WM_SIZE, 0, 0);
		return 0;

	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case ID_HOOK_HOOKWMWARE:
			HANDLE hFile;
			DWORD ret;
			hFile = CreateFile(szWin32DriverName,
				GENERIC_WRITE | GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
				NULL,
				OPEN_EXISTING,
				FILE_ATTRIBUTE_NORMAL | FILE_ATTRIBUTE_SYSTEM,
				NULL);
			if (hFile == INVALID_HANDLE_VALUE)
			{
				OutputDebugStringA("Hook WMware fail , hFile=INVALID");
				return 0;
			}
			if (!DeviceIoControl(hFile, UK_HOOKWMWARE, NULL, NULL, NULL, NULL, &ret, NULL))
			{
				OutputDebugStringA("Hook WMware fail , DeviceIoControl");
				return 0;
			}
			OutputDebugStringA("Hook WMware Success ");
			CloseHandle(hFile);
			break;

		case ID_DLL_HANDLE:
			bHandleAndDll = TRUE;
			CheckMenuItem(GetMenu(hwnd), iSelection, MF_UNCHECKED);
			iSelection = LOWORD(wParam);
			CheckMenuItem(GetMenu(hwnd), iSelection, MF_CHECKED);
			SendMessage(hSubWinInfo, WM_DATEUPHANDLEINFO, 1, 0);		//������Pid�¼�
			break;

		case ID_DLL_INFO:
			bHandleAndDll = FALSE;
			CheckMenuItem(GetMenu(hwnd), iSelection, MF_UNCHECKED);
			iSelection = LOWORD(wParam);
			CheckMenuItem(GetMenu(hwnd), iSelection, MF_CHECKED);
			SendMessage(hSubWinInfo, WM_DATEUPHANDLEINFO, 1, 0);		//������Pid�¼�
			break;
		case ID_AOUT_FILE:
			//���Դ���
			/*1
			hSubWinInfo=CreateDialog(
				hInstance, 
				MAKEINTRESOURCE(IDD_SubInfo), 
				hwnd, 
				(DLGPROC)SubWinInfo);
			ShowWindow(hSubWinInfo, SW_SHOWNORMAL);
	*/
			break;
		case ID_PORTINFO_NETSTAT:
			DialogBox(hInstance, MAKEINTRESOURCE(IDD_PORT), hwnd,(DLGPROC)PortProc );

			break;

		case ID_PACKETFILTER_START:
			DialogBox(hInstance, MAKEINTRESOURCE(IDD_PACKET), hwnd, (DLGPROC)PacketFilterWin);
			break;


		case ID_PathButton:
		case ID_ProcButton:	
		case ID_Cpubutton:
			SetFocus(hwnd);
			break;
		case ID_PidButton:
			//��pid��СΪ��������
			hDevice = CreateFile(szWin32DriverName,
				GENERIC_WRITE | GENERIC_READ, 
				0, NULL,
				OPEN_EXISTING, 
				FILE_ATTRIBUTE_SYSTEM, 
				NULL);
			if (hDevice == INVALID_HANDLE_VALUE)
			{
				OutputDebugStringA("Open Driver Fail");
				return 0;
			}
			if (!DeviceIoControl(hDevice, UK_PROCPIDLIST, NULL, NULL, NULL, NULL, &iret, NULL))
			{
				OutputDebugStringA("DeviceIoControl fail");
				return 0;
			}
			CloseHandle(hDevice);
			SetFocus(hwnd);
			break;

		case ID_KEYBOARD_WHILE:
			//����Ϊ������������
			DialogBox(hInstance, MAKEINTRESOURCE(IDD_KeyBoard), hwnd, KeyBoark);
			break;
		}
		return 0;


	case WM_PAINT:
		//��������
		hdc = BeginPaint(hwnd, &ps);
		SetCursor(LoadCursor(NULL, IDC_ARROW));
		GetClientRect(hwnd, &ClientRect);


		HDC DC;
		HBITMAP hBitmap;
		HGDIOBJ oldBitmap;

		DC=CreateCompatibleDC(NULL);
		hBitmap = CreateCompatibleBitmap(hdc, cxClient, cyClient);
		oldBitmap = SelectObject(DC, hBitmap);

		BitBlt(DC, 0, 0, cxClient, cyClient, NULL, 0, 0, WHITENESS);	//���ǳ�ʼ��һ��DC


		//��굥���¼�������ˢ
		hPen = CreatePen(PS_SOLID, 0, RGB(225, 225, 225));
		SelectObject(DC, hPen);
		hBrush = CreateSolidBrush(RGB(225, 225, 225));			//��������������ˢ
		SelectObject(DC, hBrush);
		Rectangle(DC, 0, ButtonRect.top, ButtonRect.right, ButtonRect.bottom);
		DeleteObject(hBrush);

		SetBkMode(DC, TRANSPARENT);	//�ı����屳��ģʽ

		//�����߼�����ṹ
		lf.lfHeight = 15;
		lf.lfWidth = 7;
		hFont = CreateFontIndirect(&lf);
		OldFont = (HFONT)SelectObject(DC, hFont);


		//��ȡ��ֱ������λ��
		iVertPos = GetScrollPos(hwnd, SB_VERT);
		iVertPos = 0 - iVertPos;
		iHorzPos = GetScrollPos(hwnd, SB_HORZ);
		PDefProcessStruct ProcInfo;
		ProcInfo = g_ProcstructLink;
		for (int i = 0; ProcInfo!=NULL; i += 15)
		{
			MoveToEx(DC, 0, cyProcButton + i, NULL);
			LineTo(DC, ClientRect.right, cyProcButton+i);
			
			//���������ı�
			RECT TextRect;
			TextRect.left = 3;
			TextRect.top = iVertPos * 15 + cyProcButton + i;
			TextRect.right = BorderLine1;
			TextRect.bottom = cyProcButton + i + 15;


			DrawText(DC, ProcInfo->Path+ProcInfo->NameOffsets, -1, &TextRect, NULL);		//��������

			TextRect.left = BorderLine1 + 5;	//PID��ʼ�ڷֽ��߾���
			TextRect.right = BorderLine1 + BorderLine2;

			CHAR szBuffer[260];
			sprintf_s(szBuffer, "%d", ProcInfo->Pid);
			DrawTextA(DC, szBuffer, -1, &TextRect, NULL);			//����PID

			//CpuRate
			TextRect.left = BorderLine1 + BorderLine2 + 5;
			TextRect.right = BorderLine1 + BorderLine2 + BorderLine3;
			sprintf_s(szBuffer, "%0.2f%%", ProcInfo->Cpu.CpuRate);
			DrawTextA(DC,szBuffer, -1, &TextRect, NULL);			//Cpu


			TextRect.left = BorderLine1 + BorderLine2 + BorderLine3 + 5;
			TextRect.right = ClientRect.right;
			DrawText(DC, ProcInfo->Path+iHorzPos, -1, &TextRect, NULL);		//·��
	
			ProcInfo = ProcInfo->NextList;
		}
		SelectObject(DC, OldFont);	//��ԭΪϵͳ����
		DeleteObject(hFont);		//ɾ����������


		//******�ֽ����Լ�����*********
		hPen = CreatePen(PS_SOLID, 0, RGB(0, 0, 0));
		DeleteObject(SelectObject(DC, hPen));

		MoveToEx(DC, BorderLine1, 0, NULL);		//ProcNameBorder
		LineTo(DC, BorderLine1, ClientRect.bottom);


		MoveToEx(DC, BorderLine1 + BorderLine2, 0, NULL);
		LineTo(DC, BorderLine1 + BorderLine2, ClientRect.bottom);

		MoveToEx(DC, BorderLine1 + BorderLine2 + BorderLine3, 0, NULL);
		LineTo(DC, BorderLine1 + BorderLine2 + BorderLine3, ClientRect.bottom);
		//***********************************
	
		SetBkMode(DC, OPAQUE);		//���屳��ģʽ
		BitBlt(hdc, 0, 15, cxClient, cyClient, DC, 0, 15, SRCCOPY);

	
		DeleteDC(DC);
		DeleteObject(hPen);	//ɾ������
		DeleteObject(hBitmap);


		EndPaint(hwnd, &ps);
		return 0;


	case WM_NCMOUSEMOVE:	//�ǿͻ���

		return 0;

	case WM_MOUSEMOVE:		//�ͻ���
		MouseX = LOWORD(lParam);	//x����
		MouseY = HIWORD(lParam);	//y����
		if (BorderLine1 - 10 < MouseX &&MouseX< BorderLine1)
			SetCursor(LoadCursor(NULL, IDC_SIZEWE));
		else
			SetCursor(LoadCursor(NULL, IDC_ARROW));
	
		if (MouseEvent == TRUE)
		{
			BorderLine1 = max(MouseX, 30);
			ClientRect.left = 0;
			ClientRect.top = 0;
			ClientRect.bottom = 15;

			InvalidateRect(hwnd, &ClientRect, TRUE);
			MoveWindow(ProcButtonhwnd, 0, 0, BorderLine1, cyProcButton, FALSE);
			MoveWindow(PidButtonhwnd, BorderLine1, 0, BorderLine2, cyProcButton, FALSE);
			MoveWindow(CpuButtonhwnd, BorderLine1 + BorderLine2, 0, BorderLine3, cyProcButton, FALSE);
			MoveWindow(PathButtonhwnd,
				BorderLine1 + BorderLine2 + BorderLine3, 0,
				ClientRect.right - (BorderLine1 + BorderLine2 + BorderLine3), cyProcButton, 
				FALSE);
		}	
		return 0;


		//˫���¼�
	case WM_LBUTTONDBLCLK:
		MouseX = LOWORD(lParam);	//x����
		MouseY = HIWORD(lParam);	//y����
		iPos = GetScrollPos(hwnd, SB_VERT);
		MouseY -= cyProcButton;
		MouseY /= 15;
		iPos += MouseY;
		DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_TABDIALOG), hwnd, (DLGPROC)TabProc, (LPARAM)iPos);
		break;

	case WM_LBUTTONDOWN:
		MouseX = LOWORD(lParam);	//x����
		MouseY = HIWORD(lParam);	//y����
		if (BorderLine1 - 10 < MouseX &&MouseX < BorderLine1)
			MouseEvent = TRUE;

		return 0;

	case WM_LBUTTONUP:  //�����¼�
		MouseEvent = FALSE;		//��굥���¼� FASLE����Up


		cxButton = LOWORD(lParam);
		cyButton = HIWORD(lParam);

		iPos = GetScrollPos(hwnd, SB_VERT);
		MouseY -= cyProcButton;
		MouseY /= 15;
		iPos += MouseY;

		PDefProcessStruct TempProc;
		TempProc = g_ProcstructLink;

		for (DWORD i = 0; i < iPos; i++)
		{
			TempProc = TempProc->NextList;
		}

		//��ȡHandle��Ϣ�¼�
		SendMessage(hSubWinInfo, WM_DATEUPHANDLEINFO, 0, TempProc->Pid);



		hdc=BeginPaint(hwnd, &ps);
		SelectObject(hdc, GetStockObject(BLACK_BRUSH));
		GetClientRect(hwnd, &ClientRect);

		ButtonRect.left = 0;								//��䱳�����γߴ�
		ButtonRect.top = cyButton / 15 * 15;
		ButtonRect.bottom = cyButton / 15 * 15 + 15;
		ButtonRect.right = ClientRect.right;
		InvalidateRect(hwnd, &ClientRect, FALSE);					//���¿ͻ�����
		EndPaint(hwnd, &ps);
		return 0;

	case WM_HSCROLL:
		ScrollPos = GetScrollPos(hwnd, SB_HORZ);
		tempNumber = 20;
		switch (LOWORD(wParam))
		{
		case SB_PAGEDOWN:
			ScrollPos += 1 * 4;

			ScrollPos = min(tempNumber, ScrollPos);
			break;

		case SB_LINEDOWN:
			ScrollPos += 1;	//�����׽�min�� �����ִ������+1
			ScrollPos = min(tempNumber, ScrollPos);
			break;

		case SB_PAGEUP:
			ScrollPos -= 1 * 4;
			ScrollPos = max(0, ScrollPos);
			break;

		case SB_LINEUP:
			ScrollPos -= 1;
			ScrollPos = max(0, ScrollPos);
			break;

		case SB_THUMBPOSITION:
		case SB_THUMBTRACK:
			ScrollPos = HIWORD(wParam);
			break;
		}
		SetScrollPos(hwnd, SB_HORZ, ScrollPos, TRUE);
		InvalidateRect(hwnd, NULL, FALSE);
		return 0;

	case WM_VSCROLL:
		ScrollPos = GetScrollPos(hwnd, SB_VERT);
		switch (LOWORD(wParam))
		{
		case SB_PAGEDOWN:
			ScrollPos += 4;
			ScrollPos = min(g_ProcNumber, ScrollPos);
			break;

		case SB_LINEDOWN:
			ScrollPos += 1;	//�����׽�min�� �����ִ������+1
			ScrollPos = min(g_ProcNumber, ScrollPos);
			break;

		case SB_PAGEUP:
			ScrollPos -=  4;
			ScrollPos = max(0, ScrollPos);
			break;

		case SB_LINEUP:
			ScrollPos -= 1;
			ScrollPos = max(0, ScrollPos);
			break;

		case SB_THUMBPOSITION:
		case SB_THUMBTRACK:
			ScrollPos = HIWORD(wParam);
			break;
		}
		SetScrollPos(hwnd, SB_VERT, ScrollPos, TRUE);
		InvalidateRect(hwnd, NULL, FALSE);
		return 0;

	case WM_MOUSEWHEEL:
		static int temp;
		if (WheelPos == 0)
			break;

		temp += (short)HIWORD(wParam);	//120 or -120
		while (temp >= WheelPos)
		{
			SendMessage(hwnd, WM_VSCROLL, SB_LINEUP, 0);
			temp -= WheelPos;
		}
		while (temp <= -WheelPos)
		{
			SendMessage(hwnd, WM_VSCROLL, SB_LINEDOWN, 0);
			temp += WheelPos;
		}
		return 0;

	case WM_TIMER:
		switch (wParam)
		{
		case GETCPUTIME:
			si.cbSize = sizeof(si);
			si.fMask = SIF_RANGE | SIF_PAGE;
			si.nMin = 0;
			si.nMax = g_ProcNumber;
			si.nPage = cyClient / 15;
			SetScrollInfo(hwnd, SB_VERT, &si, TRUE);
			GetProcessInformation();
			InvalidateRect(hwnd, NULL, FALSE);
			return 0;
		}
		
		return 0;


	case WM_DESTROY:
		DeleteCriticalSection(&CriticalSec);
		KillTimer(hwnd, GETCPUTIME);
		VirtualFree(g_ProcstructLink, (g_ProcNumber + 5)*sizeof(DefProcessStruct), MEM_DECOMMIT);
		RaiseDriverPrivilege(TRUE);		//��Ȩ
		ReleaseDriver(szDriverExePath, szDriverName);
		UnLoadDriver(szDriverExePath, szDriverName);
		DeleteDriverFile(szDriverExePath, szDriverName);
		PostQuitMessage(0);
		return 0;
	}

	return DefWindowProc(hwnd, Msg, wParam, lParam);
}

